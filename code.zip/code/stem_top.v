`timescale 1ns/1ps
`default_nettype none

module stem_top #(
    parameter integer W     = 64,
    parameter integer H     = 64,
    parameter integer BITS  = 8,
    parameter integer DEPTH = W*H,
    parameter integer AW    = 12,
    parameter        MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stem/000036.mem",

    // 原 deep FIFO 参数保留但不再使用（避免上层约束/脚本依赖）
    parameter integer FIFO_DEPTH = 65536,
    parameter integer FIFO_AFULL = 32768
)(
    input  wire        clk,
    input  wire        rst_n,

    // output wire [23:0] rom_data,
    // output wire [23:0] pool_data,
    // output wire        pool_pulse,
    // output wire        pool_sof_out,
    // output wire        pool_eof_out,

    output wire        stem_pulse,
    output wire [4:0]  stem_och,
    output wire [11:0] stem_pix_idx,
    output wire signed [10:0] stem_data,   // 16 -> 11 (signed)
    output wire        drop_pulse
);
    wire [AW-1:0] rom_addr_q;
    wire          rom_pix_valid;
    wire [23:0]   rom_pix;
    wire          rom_en;
    wire [23:0] rom_data;
    wire [23:0] pool_data;
    wire        pool_pulse;
    wire        pool_sof_out;
    wire        pool_eof_out;
    rom_rgb888_stream #(
        .AW       (AW),
        .DEPTH    (DEPTH),
        .MEM_FILE (MEM_FILE)
    ) u_rom_stream (
        .clk       (clk),
        .rst_n     (rst_n),
        .en        (rom_en),
        .addr_q    (rom_addr_q),
        .pix       (rom_pix),
        .pix_valid (rom_pix_valid)
    );

    //assign rom_data = rom_pix;

    // 由 conv3 输入侧 ready 控制池化输出侧 out_ready（保持你原 gating 思路）
    wire conv3_in_ready_int;
    wire pool_out_ready_gated = conv3_in_ready_int;

    maxpool2x2_romstream_pulse_rv #(
        .W    (W),
        .H    (H),
        .BITS (BITS),
        .AW   (AW)
    ) u_pool (
        .clk           (clk),
        .rst_n         (rst_n),

        .rom_en        (rom_en),
        .rom_addr_q    (rom_addr_q),
        .rom_pix       (rom_pix),
        .rom_pix_valid (rom_pix_valid),

        .out_ready     (pool_out_ready_gated),
        .out_pulse     (pool_pulse),
        .out_data      (pool_data),
        .out_sof       (pool_sof_out),
        .out_eof       (pool_eof_out),

        .drop_pulse    (drop_pulse)
    );

    // ---------------------------
    // conv3 -> pointwise 直连
    // ---------------------------
    wire        conv_pulse;
    wire [5:0]  conv_och;
    wire [11:0] conv_pix_idx;
    wire signed [10:0] conv_data;   // 16 -> 11 (signed)

    wire        pw_allow_start;
    wire        pw_in_ready;

    // conv 输出端 ready：下游 pointwise 只有在 in_ready=1 时才允许 conv “吐出”
    wire conv_out_ready = pw_in_ready;

    conv3x3_fold_act16_rin7_3to64_11b u_conv3 (
        .clk         (clk),
        .rst_n       (rst_n),
        .in_pulse    (pool_pulse),
        .in_data     (pool_data),
        .in_ready    (conv3_in_ready_int),
        .out_ready   (conv_out_ready),
        .out_pulse   (conv_pulse),
        .out_och     (conv_och),
        .out_pix_idx (conv_pix_idx),
        .out_data    (conv_data)
    );

    pointwise1x1_grp8_64to32_11b #(
        .ROM_LAT   (1),
        .USE_RELU  (0),
        .OUT_SHIFT (15)
    ) u_pw (
        .clk         (clk),
        .rst_n       (rst_n),

        .in_pulse    (conv_pulse),
        .in_och      (conv_och),
        .in_pix_idx  (conv_pix_idx),
        .in_data     (conv_data),

        .allow_start (pw_allow_start),
        .in_ready    (pw_in_ready),

        .out_pulse   (stem_pulse),
        .out_och     (stem_och),
        .out_pix_idx (stem_pix_idx),
        .out_data    (stem_data)
    );

endmodule

`default_nettype wire
