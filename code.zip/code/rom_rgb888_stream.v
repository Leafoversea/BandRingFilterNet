module rom_rgb888_stream #(
    parameter integer AW    = 12,
    parameter integer DEPTH = 4096,
    parameter        MEM_FILE = "000036.mem"
)(
    input  wire              clk,
    input  wire              rst_n,
    input  wire              en,
    output reg  [AW-1:0]      addr_q,
    output reg  [23:0]        pix,
    output reg                pix_valid
);
    // [修改重点] 移除 distributed 属性，改为 block。
    // 释放 ~1500 个 LUT，消除 5 级数据选择器延迟，仅消耗 3 个 BRAM
    (* ram_style = "block" *) reg [23:0] mem [0:DEPTH-1];

    initial begin
        $readmemh(MEM_FILE, mem);
    end

    reg [AW-1:0] addr;

    always @(posedge clk) begin
        if (!rst_n) begin
            addr      <= {AW{1'b0}};
            addr_q    <= {AW{1'b0}};
            pix       <= 24'd0;
            pix_valid <= 1'b0;
        end else begin
            pix_valid <= en;
            addr_q    <= addr;
            pix       <= mem[addr]; // BRAM 会自动吸收这个寄存器行为，延迟保持 1 拍不变
            if (en) begin
                if (addr == DEPTH-1)
                    addr <= {AW{1'b0}};
                else
                    addr <= addr + {{(AW-1){1'b0}}, 1'b1};
            end
        end
    end
endmodule