`timescale 1ns/1ps
`default_nettype none

module irfft2_32x32_half_in16_out12_vr #(
    parameter integer H = 32,
    parameter integer W = 32,
    parameter integer C = 32,
    parameter integer IN_DW  = 16,
    parameter integer OUT_DW = 12,

    parameter [9:0] COL_IFFT_SCALE_SCH10 = 10'b0000000000,
    parameter [9:0] ROW_IFFT_SCALE_SCH10 = 10'b1111100001,

    parameter integer OUT_RSHIFT = 0,
    parameter       PY_MODE = 1'b1
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire                 s_valid,
    output wire                 s_ready,
    input  wire [5:0]           s_och,
    input  wire [4:0]           s_ky,
    input  wire [4:0]           s_kx,
    input  wire [IN_DW-1:0]     s_re,
    input  wire [IN_DW-1:0]     s_im,

    output wire                 m_valid,
    input  wire                 m_ready,
    
    output wire [9:0]           m_pix_idx,
    output wire [5:0]           m_och,
    output wire [OUT_DW-1:0]    m_data,
    output wire                 m_last,

    output reg                  busy
);
    localparam integer KXH  = (W/2)+1;   // 17
    localparam integer PIXN = H*W;       // 1024
    localparam integer INN  = H*KXH;     // 544
    localparam integer CDW  = 2*IN_DW;   // 32

    // =========================================================================
    // COL memories (BRAM-friendly)
    // =========================================================================
    (* ram_style="block" *) reg [CDW-1:0] col_mem [0:2047];
    reg        buf_full0, buf_full1;
    reg [5:0]  buf_och0,  buf_och1;

    // =========================================================================
    // COL IFFT 
    // =========================================================================
    reg        col_active;
    reg        col_buf_sel;

    reg [9:0]  col_in_cnt;
    reg [9:0]  col_out_cnt;
    reg [4:0]  ky_in,  kx_in;
    reg [4:0]  ky_out, kx_out;

    wire [15:0] col_ifft_in_re16 = s_re[15:0];
    wire [15:0] col_ifft_in_im16 = s_im[15:0];

    wire        col_ifft_in_ready;
    wire        col_ifft_out_valid;
    wire [15:0] col_ifft_out_re16;
    wire [15:0] col_ifft_out_im16;
    wire        col_ifft_out_last;
    wire        col_ifft_out_ready = 1'b1;

    wire buf0_free = (!buf_full0) && !(col_active && (col_buf_sel == 1'b0));
    wire buf1_free = (!buf_full1) && !(col_active && (col_buf_sel == 1'b1));
    wire have_free_buf = buf0_free || buf1_free;
    wire next_col_buf  = (buf0_free) ? 1'b0 : 1'b1;

    wire col_can_accept = (col_active ? 1'b1 : have_free_buf);
    wire col_ifft_in_valid = col_can_accept && (col_in_cnt < INN) && s_valid;
    wire col_fire_in = col_ifft_in_valid && col_ifft_in_ready;
    wire col_ifft_in_last = (ky_in == (H-1)) ? 1'b1 : 1'b0;

    assign s_ready = col_can_accept && (col_in_cnt < INN) && col_ifft_in_ready;

    ifft32_xfft_axis16_ifft_sep16 #(
        .SCALE_SCH10(COL_IFFT_SCALE_SCH10),
        .CFG_EACH_FRAME(1'b0),
        .PY_MODE(PY_MODE)
    ) u_col_ifft (
        .clk(clk),
        .rst_n(rst_n),
        .in_re(col_ifft_in_re16),
        .in_im(col_ifft_in_im16),
        .in_valid(col_ifft_in_valid),
        .in_ready(col_ifft_in_ready),
        .in_last(col_ifft_in_last),
        .out_re(col_ifft_out_re16),
        .out_im(col_ifft_out_im16),
        .out_valid(col_ifft_out_valid),
        .out_ready(col_ifft_out_ready),
        .out_last(col_ifft_out_last)
    );

    wire [9:0] col_wr_addr10 = (({5'd0,ky_out} << 4) + {5'd0,ky_out}) + {5'd0,kx_out};
    wire [CDW-1:0] col_wr_word = {col_ifft_out_im16, col_ifft_out_re16};

    // =========================================================================
    // ROW side: BRAM Sync-Read Pipeline (Timing Optimized)
    // =========================================================================
    reg        row_active;
    reg        row_buf_sel;
    reg [5:0]  row_och_cur;
    
    reg [4:0]  iss_x;
    reg [10:0] iss_cnt;
    reg [4:0]  row_out_x, row_out_ky;
    reg [10:0] row_out_cnt;

    wire have_full_buf = (buf_full0 || buf_full1);
    wire next_row_buf  = (buf_full0) ? 1'b0 : 1'b1;

    // FIFO2 
    reg [1:0]        fifo_cnt;
    reg [9:0]        f0_pix, f1_pix;
    reg [5:0]        f0_och, f1_och;
    reg [OUT_DW-1:0] f0_dat, f1_dat;
    reg              f0_last, f1_last;

    wire fifo_empty = (fifo_cnt == 2'd0);
    wire fifo_full  = (fifo_cnt == 2'd2);
    assign m_valid   = (fifo_cnt != 2'd0);
    assign m_pix_idx = f0_pix;
    assign m_och     = f0_och;
    assign m_data    = f0_dat;
    assign m_last    = f0_last;

    wire fifo_pop = (fifo_cnt != 2'd0) && m_ready;
    wire fifo_in_ready = !fifo_full;
    wire row_ifft_out_ready = fifo_in_ready && (row_out_cnt < PIXN);

    // -------------------------------------------------------------
    // NEW ELASTIC PIPELINE: Decoupled Address -> BRAM Array Latch -> BRAM Output Reg -> Math
    // -------------------------------------------------------------
    wire row_ifft_in_ready;
    wire p2_ready  = row_ifft_in_ready;
    
    // 引入 p1_reg 这一级握手，强行要求 Vivado 开启 BRAM 内部的输出寄存器 DOB_REG
    reg p2_valid;
    wire p1_reg_ready = (!p2_valid) || p2_ready;

    wire iss_last_in_row = (iss_x == (W-1));
    wire [4:0] nx_iss_x  = iss_last_in_row ? 5'd0 : (iss_x + 5'd1);

    wire row_start = (!row_active) && have_full_buf && fifo_empty;

    // --- TIMING OPTIMIZATION 1: Fully Decoupled Address FSM ---
    reg [9:0] cur_addr;
    reg [9:0] cur_base;
    wire [9:0] issue_addr = row_start ? 10'd0 : cur_addr;
    
    // --- TIMING OPTIMIZATION 2: Look-ahead Metadata Pipeline ---
    reg p1_valid, p1_reg_valid;
    reg p1_is_zero_im, p1_is_neg_im, p1_is_last;
    reg p1_reg_is_zero_im, p1_reg_is_neg_im, p1_reg_is_last;
    reg p2_is_last;
    
    wire p1_ready  = (!p1_reg_valid) || p1_reg_ready;
    wire iss_ready = (!p1_valid) || p1_ready;
    wire issue_en  = row_start || (row_active && iss_ready && (iss_cnt < PIXN));
    wire [4:0] issue_x = row_start ? 5'd0  : nx_iss_x;

    always @(posedge clk) begin
        if (row_start) begin
            cur_addr <= 10'd1;
            cur_base <= 10'd0;
        end else if (issue_en) begin
            if (nx_iss_x == 5'd31) begin
                cur_addr <= cur_base + 10'd17;
                cur_base <= cur_base + 10'd17;
            end else if (nx_iss_x < 5'd16) begin
                cur_addr <= cur_addr + 10'd1;
            end else begin
                cur_addr <= cur_addr - 10'd1;
            end
        end
    end

    wire cur_rd_bank = row_start ? next_row_buf : row_buf_sel;
    wire [10:0] issue_addr_full = {cur_rd_bank, issue_addr};
    wire [10:0] col_wr_addr_full = {col_buf_sel, col_wr_addr10};

    always @(posedge clk) begin
        if (!rst_n) begin
            p1_valid      <= 1'b0;
            p1_reg_valid  <= 1'b0;
            p2_valid      <= 1'b0;
            p1_is_zero_im <= 1'b0;
            p1_is_neg_im  <= 1'b0;
            p1_is_last    <= 1'b0;
            p1_reg_is_zero_im <= 1'b0;
            p1_reg_is_neg_im  <= 1'b0;
            p1_reg_is_last    <= 1'b0;
            p2_is_last    <= 1'b0;
        end else begin
            if (iss_ready) begin
                p1_valid <= issue_en;
                if (issue_en) begin
                    p1_is_zero_im <= (issue_x == 5'd0) || (issue_x == 5'd16);
                    p1_is_neg_im  <= (issue_x > 5'd16);
                    p1_is_last    <= (issue_x == (W-1));
                end
            end
            
            if (p1_ready) begin
                p1_reg_valid <= p1_valid;
                if (p1_valid) begin
                    p1_reg_is_zero_im <= p1_is_zero_im;
                    p1_reg_is_neg_im  <= p1_is_neg_im;
                    p1_reg_is_last    <= p1_is_last;
                end
            end

            if (p1_reg_ready) begin
                p2_valid   <= p1_reg_valid;
                p2_is_last <= p1_reg_is_last;
            end
        end
    end

    // --- TIMING OPTIMIZATION 3: Retimed Arithmetic logic ---
    reg [31:0] p1_data;
    reg [31:0] p1_reg_data; // 这个寄存器将被无缝吸收到 BRAM 内！
    reg [15:0] p2_re;
    reg [15:0] p2_im;

    wire [15:0] raw_im_p1_reg = p1_reg_data[31:16];
    // 移除了紧贴 BRAM 的运算，把它挪到了安全、具有充裕时序的下个时钟节拍
    wire [15:0] pre_add_im_p1_reg  = (p1_reg_is_zero_im ? 16'd0 : raw_im_p1_reg) ^ {16{p1_reg_is_neg_im}};
    wire [15:0] neg_im_p1_reg_comb = pre_add_im_p1_reg + {15'd0, p1_reg_is_neg_im};

    always @(posedge clk) begin
        // Port A: Write
        if (col_active && col_ifft_out_valid) begin
            col_mem[col_wr_addr_full] <= col_wr_word;
        end
        
        // Port B: Read Stage 1 (Infer internal array latch DOA)
        if (issue_en) begin
            p1_data <= col_mem[issue_addr_full];
        end

        // Port B: Read Stage 2 (DOB_REG: Forces BRAM output register, Cuts ~1.5ns off delay!)
        if (p1_ready) begin
            p1_reg_data <= p1_data;
        end

        // Port B: Read Stage 3 (Arithmetic combo to register)
        if (p1_reg_ready) begin
            p2_re <= p1_reg_data[15:0];
            p2_im <= neg_im_p1_reg_comb;
        end
    end

    wire [15:0] row_ifft_in_re16 = p2_re;
    wire [15:0] row_ifft_in_im16 = p2_im;
    wire row_ifft_in_valid = p2_valid;
    wire row_ifft_in_last  = p2_is_last;

    wire row_ifft_out_valid;
    wire [15:0] row_ifft_out_re16;
    wire [15:0] row_ifft_out_im16;
    wire row_ifft_out_last;

    ifft32_xfft_axis16_ifft_sep16 #(
        .SCALE_SCH10(ROW_IFFT_SCALE_SCH10),
        .CFG_EACH_FRAME(1'b0),
        .PY_MODE(PY_MODE)
    ) u_row_ifft (
        .clk(clk),
        .rst_n(rst_n),
        .in_re(row_ifft_in_re16),
        .in_im(row_ifft_in_im16),
        .in_valid(row_ifft_in_valid),
        .in_ready(row_ifft_in_ready),
        .in_last(row_ifft_in_last),
        .out_re(row_ifft_out_re16),
        .out_im(row_ifft_out_im16),
        .out_valid(row_ifft_out_valid),
        .out_ready(row_ifft_out_ready),
        .out_last(row_ifft_out_last)
    );

    wire row_out_fire = row_active && row_ifft_out_valid && fifo_in_ready && (row_out_cnt < PIXN);

    // =========================================================================
    // Main FSM
    // =========================================================================
    wire fifo_push = row_out_fire;

    always @(posedge clk) begin
        if (!rst_n) begin
            buf_full0 <= 1'b0;
            buf_full1 <= 1'b0;
            buf_och0  <= 6'd0; buf_och1  <= 6'd0;

            col_active  <= 1'b0; col_buf_sel <= 1'b0;
            col_in_cnt  <= 10'd0; col_out_cnt <= 10'd0;
            ky_in <= 5'd0; kx_in <= 5'd0;
            ky_out<= 5'd0; kx_out<= 5'd0;

            row_active  <= 1'b0; row_buf_sel <= 1'b0; row_och_cur <= 6'd0;
            iss_x <= 5'd0; iss_cnt <= 11'd0;
            row_out_x <= 5'd0;
            row_out_ky <= 5'd0;
            row_out_cnt <= 11'd0;

            fifo_cnt <= 2'd0;
            f0_pix <= 10'd0; f1_pix <= 10'd0;
            f0_och <= 6'd0;
            f1_och <= 6'd0;
            f0_dat <= {OUT_DW{1'b0}}; f1_dat <= {OUT_DW{1'b0}};
            f0_last <= 1'b0; f1_last <= 1'b0;

            busy <= 1'b0;
        end else begin
            // -------------------------
            // FIFO2 update
            // -------------------------
            begin
                case ({fifo_push, fifo_pop})
                    2'b00: begin end
                    2'b01: begin
                        if (fifo_cnt == 2'd1) begin
                            fifo_cnt <= 2'd0;
                        end else if (fifo_cnt == 2'd2) begin
                            f0_pix  <= f1_pix;
                            f0_och  <= f1_och;
                            f0_dat  <= f1_dat;  f0_last <= f1_last;
                            fifo_cnt <= 2'd1;
                        end
                    end
                    2'b10: begin
                        if (fifo_cnt == 2'd0) begin
                            f0_pix  <= ({5'd0,row_out_ky} << 5) + {5'd0,row_out_x};
                            f0_och  <= row_och_cur;
                            f0_dat  <= row_ifft_out_re16[OUT_DW-1:0];
                            f0_last <= ((row_och_cur == (C-1)) && (row_out_ky == (H-1)) && (row_out_x == (W-1)));
                            fifo_cnt <= 2'd1;
                        end else if (fifo_cnt == 2'd1) begin
                            f1_pix  <= ({5'd0,row_out_ky} << 5) + {5'd0,row_out_x};
                            f1_och  <= row_och_cur;
                            f1_dat  <= row_ifft_out_re16[OUT_DW-1:0];
                            f1_last <= ((row_och_cur == (C-1)) && (row_out_ky == (H-1)) && (row_out_x == (W-1)));
                            fifo_cnt <= 2'd2;
                        end
                    end
                    2'b11: begin
                        if (fifo_cnt == 2'd1) begin
                            f0_pix  <= ({5'd0,row_out_ky} << 5) + {5'd0,row_out_x};
                            f0_och  <= row_och_cur;
                            f0_dat  <= row_ifft_out_re16[OUT_DW-1:0];
                            f0_last <= ((row_och_cur == (C-1)) && (row_out_ky == (H-1)) && (row_out_x == (W-1)));
                            fifo_cnt <= 2'd1;
                        end else begin
                            f0_pix  <= f1_pix;
                            f0_och  <= f1_och;
                            f0_dat  <= f1_dat;  f0_last <= f1_last;

                            f1_pix  <= ({5'd0,row_out_ky} << 5) + {5'd0,row_out_x};
                            f1_och  <= row_och_cur;
                            f1_dat  <= row_ifft_out_re16[OUT_DW-1:0];
                            f1_last <= ((row_och_cur == (C-1)) && (row_out_ky == (H-1)) && (row_out_x == (W-1)));
                            fifo_cnt <= 2'd2;
                        end
                    end
                endcase
            end

            // -------------------------
            // COL control 
            // -------------------------
            if (!col_active) begin
                col_in_cnt  <= 10'd0;
                col_out_cnt <= 10'd0;
                ky_in <= 5'd0; kx_in <= 5'd0; ky_out<= 5'd0; kx_out<= 5'd0;
                if (col_fire_in) begin
                    col_active  <= 1'b1;
                    col_buf_sel <= next_col_buf;
                    if (next_col_buf == 1'b0) buf_och0 <= s_och;
                    else                      buf_och1 <= s_och;
                    ky_in <= (ky_in == (H-1)) ? 5'd0 : (ky_in + 5'd1);
                    if (ky_in == (H-1)) kx_in <= kx_in + 5'd1;
                    col_in_cnt <= 10'd1;
                end
            end else begin
                if (col_fire_in) begin
                    ky_in <= (ky_in == (H-1)) ? 5'd0 : (ky_in + 5'd1);
                    if (ky_in == (H-1)) kx_in <= kx_in + 5'd1;
                    if (col_in_cnt < INN) col_in_cnt <= col_in_cnt + 10'd1;
                end
            end

            if (col_active && col_ifft_out_valid) begin
                ky_out <= (ky_out == (H-1)) ? 5'd0 : (ky_out + 5'd1);
                if (ky_out == (H-1)) kx_out <= kx_out + 5'd1;
                if (col_out_cnt < INN) col_out_cnt <= col_out_cnt + 10'd1;
                if (col_out_cnt == (INN-1)) begin
                    if (col_buf_sel == 1'b0) buf_full0 <= 1'b1;
                    else                     buf_full1 <= 1'b1;
                    col_active <= 1'b0;
                end
            end

            // -------------------------
            // ROW control FSM 
            // -------------------------
            if (row_start) begin
                row_active  <= 1'b1;
                row_buf_sel <= next_row_buf;
                if (next_row_buf == 1'b0) begin
                    row_och_cur <= buf_och0;
                    buf_full0   <= 1'b0;
                end else begin
                    row_och_cur <= buf_och1;
                    buf_full1   <= 1'b0;
                end

                iss_x <= 5'd0;
                iss_cnt <= 11'd1; 
                row_out_x <= 5'd0;
                row_out_ky <= 5'd0; row_out_cnt <= 11'd0;
            end else if (row_active) begin
                
                if (issue_en) begin
                    iss_x <= nx_iss_x;
                    if (iss_cnt < PIXN) iss_cnt <= iss_cnt + 11'd1;
                end

                if (row_out_fire) begin
                    if (row_out_x == (W-1)) begin
                        row_out_x <= 5'd0;
                        if (row_out_ky != (H-1)) row_out_ky <= row_out_ky + 5'd1;
                    end else begin
                        row_out_x <= row_out_x + 5'd1;
                    end
                    if (row_out_cnt < PIXN) row_out_cnt <= row_out_cnt + 11'd1;
                end

                // FSM End Condition
                if ((row_out_cnt == PIXN) && (fifo_cnt == 2'd0)) begin
                    row_active <= 1'b0;
                end
            end

            busy <= col_active || row_active || buf_full0 || buf_full1 || (fifo_cnt != 2'd0);
        end
    end

    wire _unused = &{1'b0, s_ky, s_kx, OUT_RSHIFT[0], row_ifft_out_im16[0], col_ifft_out_last, row_ifft_out_last};
endmodule
`default_nettype wire