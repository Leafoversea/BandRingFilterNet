module skid_buffer #(
    parameter WIDTH = 32
)(
    input  wire             clk,
    input  wire             rst_n,
    input  wire             s_valid,
    output wire             s_ready,
    input  wire [WIDTH-1:0] s_data,
    output wire             m_valid,
    input  wire             m_ready,
    output wire [WIDTH-1:0] m_data
);
    reg             valid_reg;
    reg [WIDTH-1:0] data_reg;
    reg             skid_valid;
    reg [WIDTH-1:0] skid_data;

    always @(posedge clk) begin
        if (!rst_n) begin
            valid_reg  <= 1'b0; data_reg   <= {WIDTH{1'b0}};
            skid_valid <= 1'b0; skid_data  <= {WIDTH{1'b0}};
        end else begin
            if (m_ready) begin
                if (skid_valid) begin valid_reg <= 1'b1; data_reg <= skid_data; skid_valid <= 1'b0; end 
                else            begin valid_reg <= 1'b0; end
            end
            
            if (s_valid && (!skid_valid)) begin
                if (m_ready || !valid_reg) begin valid_reg <= 1'b1; data_reg <= s_data; end 
                else                       begin skid_valid <= 1'b1; skid_data <= s_data; end
            end
        end
    end
    assign s_ready = !skid_valid;
    assign m_valid = valid_reg;
    assign m_data  = data_reg;
endmodule