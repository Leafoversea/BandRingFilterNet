`timescale 1ns/1ps 
`default_nettype none
`timescale 1ns/1ps 
`default_nettype none

module pointwise1x1_grp8_192to64_vr #(
    parameter integer USE_RELU  = 0,
    parameter integer OUT_SHIFT = 12,
    parameter MEM = "",
    parameter BIAS = ""
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_valid,
    output wire        in_ready,
    input  wire [7:0]  in_och,
    input  wire [9:0]  in_pix_idx,
    input  wire signed [12:0] in_data,

    output wire        out_valid,
    input  wire        out_ready,
    output wire [5:0]  out_och,
    output wire [9:0]  out_pix_idx,
    output wire signed [12:0] out_data
);
    localparam integer NUM_IC = 192;
    localparam integer ACC_W  = 48;

    wire        int_valid;
    wire        int_ready;
    reg  [5:0]  int_och;
    reg  [9:0]  int_pix_idx;
    reg  signed [12:0] int_data;

    wire [28:0] skid_in = {int_och, int_pix_idx, int_data};
    wire [28:0] skid_out;

    // 原生内置防滑缓冲，完全斩断反向长组合逻辑
    skid_buffer #(.WIDTH(29)) u_skid (
        .clk(clk), .rst_n(rst_n),
        .s_valid(int_valid), .s_ready(int_ready), .s_data(skid_in),
        .m_valid(out_valid), .m_ready(out_ready), .m_data(skid_out)
    );
    assign out_och     = skid_out[28:23];
    assign out_pix_idx = skid_out[22:13];
    assign out_data    = skid_out[12:0];

    wire int_fire = int_valid && int_ready;

    reg signed [12:0] xbuf [0:NUM_IC-1];
    reg [9:0] pix_lat;
    reg [3:0] state;
    localparam [3:0] S_IDLE    = 4'd0,
                     S_COLLECT = 4'd1,
                     S_WAIT    = 4'd2,
                     S_MAC0    = 4'd3, 
                     S_MAC1    = 4'd4, 
                     S_MAC2    = 4'd5, 
                     S_TREE0   = 4'd6,  
                     S_TREE1   = 4'd7,  
                     S_TREE2   = 4'd8,  
                     S_TREE3   = 4'd9,
                     S_TREE4   = 4'd10,
                     S_FMT     = 4'd11, 
                     S_OUT     = 4'd12;
                     
    reg        ibuf_v;
    reg [7:0]  ibuf_och;
    reg [9:0]  ibuf_pix;
    reg signed [12:0] ibuf_dat;

    wire in_ready_int = (state == S_IDLE) || (state == S_COLLECT);
    wire ibuf_pop     = ibuf_v && in_ready_int;
    assign in_ready   = (!ibuf_v) || ibuf_pop;
    wire ibuf_push    = in_valid && in_ready;
    wire [7:0]        in_och_b     = ibuf_och;
    wire [9:0]        in_pix_idx_b = ibuf_pix;
    wire signed [12:0] in_data_b   = ibuf_dat;
    wire              in_fire      = ibuf_pop;
    
    always @(posedge clk) begin
        if (!rst_n) begin
            ibuf_v   <= 1'b0; ibuf_och <= 8'd0; ibuf_pix <= 10'd0; ibuf_dat <= 13'sd0;
        end else begin
            case ({ibuf_push, ibuf_pop})
                2'b10: begin ibuf_v <= 1'b1; ibuf_och <= in_och; ibuf_pix <= in_pix_idx; ibuf_dat <= in_data; end
                2'b01: ibuf_v <= 1'b0;
                2'b11: begin ibuf_v <= 1'b1; ibuf_och <= in_och; ibuf_pix <= in_pix_idx; ibuf_dat <= in_data; end
                default: ibuf_v <= ibuf_v;
            endcase
        end
    end

    reg [5:0]          och_cur;
    reg signed [31:0]  bias_lat;
    reg signed [ACC_W-1:0] acc_shifted;
    reg signed [ACC_W-1:0] bias_round_reg;
    wire signed [ACC_W-1:0] round_const = (OUT_SHIFT != 0) ? (48'sd1 <<< (OUT_SHIFT - 1)) : 48'sd0;

    (* max_fanout = "16" *) reg [5:0] w_addr;
    (* max_fanout = "16" *) reg [5:0] b_addr;
    wire [3071:0] w_dout;
    wire [5:0]    w_addr_q;
    wire [5:0]    b_addr_q;
    
    proj_gbank64x16_to3072_rom #(.MEM(MEM)) u_w (
        .clk(clk), .addr(w_addr), .addr_q(w_addr_q), .dout(w_dout)
    );
    wire [31:0]        b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;
    proj_bias64_i32_rom #(.BIAS_MEM_FILE(BIAS)) u_b (
        .clk(clk), .addr(b_addr), .addr_q(b_addr_q), .dout(b_dout_u)
    );
    
    wire rom_aligned = (w_addr_q == w_addr) && (b_addr_q == b_addr);

    wire rom_aligned_dup [0:7];
    genvar ra; generate for (ra = 0; ra < 8; ra = ra + 1) begin : gen_ra
        assign rom_aligned_dup[ra] = (w_addr_q == w_addr) && (b_addr_q == b_addr);
    end endgenerate

    wire signed [15:0] w_flat [0:191];
    genvar gi, gj; generate
        for (gi = 0; gi < 24; gi = gi + 1) begin : gen_w_flat
            for (gj = 0; gj < 8; gj = gj + 1) begin : gen_w_flat_inner
                assign w_flat[gi*8 + gj] = w_dout[(23-gi)*128 + gj*16 +: 16];
            end
        end
    endgenerate

    function signed [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x;
        begin sext32_to_acc = {{(ACC_W-32){x[31]}}, x}; end
    endfunction

    // [修复重点] 恢复 keep 属性，让 Vivado 把 MUX 留在 Slice，把寄存器推给 DSP，解决 MUX 超长布线
    (* keep = "true" *) reg signed [12:0] mac_x_reg [0:63];
    (* keep = "true" *) reg signed [15:0] mac_w_reg [0:63];

    reg [3:0] nxt_state;
    always @(*) begin
        nxt_state = state;
        case (state)
            S_IDLE:    if (in_fire && in_och_b == 8'd0) nxt_state = S_COLLECT;
            S_COLLECT: if (in_fire && in_och_b == 8'd191) nxt_state = S_WAIT;
            S_WAIT:    if (rom_aligned) nxt_state = S_MAC0;
            S_MAC0:    nxt_state = S_MAC1;
            S_MAC1:    nxt_state = S_MAC2;
            S_MAC2:    nxt_state = S_TREE0;
            S_TREE0:   nxt_state = S_TREE1;
            S_TREE1:   nxt_state = S_TREE2;
            S_TREE2:   nxt_state = S_TREE3;
            S_TREE3:   nxt_state = S_TREE4;
            S_TREE4:   nxt_state = S_FMT;
            S_FMT:     nxt_state = S_OUT;
            S_OUT:     if (int_fire) begin
                if (och_cur == 6'd63) nxt_state = S_IDLE;
                else nxt_state = S_WAIT;
            end
        endcase
    end

    (* equivalent_register_removal = "no" *) reg clr_acc_q   [0:63];
    (* equivalent_register_removal = "no" *) reg en_mac_q    [0:63];
    (* equivalent_register_removal = "no" *) reg mac_load_en [0:63];
    (* equivalent_register_removal = "no" *) reg [1:0] mac_mux_sel [0:63];
    
    (* equivalent_register_removal = "no" *) reg [3:0] state_dup [0:7];
    wire in_ready_int_dup [0:7];
    wire in_fire_dup      [0:7];
    reg [3:0] nxt_state_dup [0:7];

    genvar xg; generate
        for (xg = 0; xg < 8; xg = xg + 1) begin : gen_ctrl_dup
            assign in_ready_int_dup[xg] = (state_dup[xg] == S_IDLE) || (state_dup[xg] == S_COLLECT);
            assign in_fire_dup[xg]      = ibuf_v && in_ready_int_dup[xg];
            always @(*) begin
                nxt_state_dup[xg] = state_dup[xg];
                case (state_dup[xg])
                    S_IDLE:    if (in_fire_dup[xg] && in_och_b == 8'd0) nxt_state_dup[xg] = S_COLLECT;
                    S_COLLECT: if (in_fire_dup[xg] && in_och_b == 8'd191) nxt_state_dup[xg] = S_WAIT;
                    S_WAIT:    if (rom_aligned_dup[xg]) nxt_state_dup[xg] = S_MAC0;
                    S_MAC0:    nxt_state_dup[xg] = S_MAC1;
                    S_MAC1:    nxt_state_dup[xg] = S_MAC2;
                    S_MAC2:    nxt_state_dup[xg] = S_TREE0;
                    S_TREE0:   nxt_state_dup[xg] = S_TREE1;
                    S_TREE1:   nxt_state_dup[xg] = S_TREE2;
                    S_TREE2:   nxt_state_dup[xg] = S_TREE3;
                    S_TREE3:   nxt_state_dup[xg] = S_TREE4;
                    S_TREE4:   nxt_state_dup[xg] = S_FMT;
                    S_FMT:     nxt_state_dup[xg] = S_OUT;
                    S_OUT:     if (int_fire) begin
                        if (och_cur == 6'd63) nxt_state_dup[xg] = S_IDLE;
                        else nxt_state_dup[xg] = S_WAIT;
                    end
                endcase
            end
        end
    endgenerate

    integer k;
    always @(posedge clk) begin
        if (!rst_n) begin
            for(k=0; k<64; k=k+1) begin clr_acc_q[k]<=0; en_mac_q[k]<=0; mac_load_en[k]<=0; mac_mux_sel[k]<=0; end
            for(k=0; k<8; k=k+1) state_dup[k] <= S_IDLE;
        end else begin
            for(k=0; k<64; k=k+1) begin
                mac_load_en[k] <= (nxt_state_dup[k/8] == S_WAIT) || (nxt_state_dup[k/8] == S_MAC0) || (nxt_state_dup[k/8] == S_MAC1);
                if (nxt_state_dup[k/8] == S_WAIT)      mac_mux_sel[k] <= 2'd0;
                else if (nxt_state_dup[k/8] == S_MAC0) mac_mux_sel[k] <= 2'd1;
                else if (nxt_state_dup[k/8] == S_MAC1) mac_mux_sel[k] <= 2'd2;
                else                                   mac_mux_sel[k] <= 2'd0;
                clr_acc_q[k] <= (nxt_state_dup[k/8] == S_MAC0);
                en_mac_q[k]  <= (nxt_state_dup[k/8] == S_MAC1 || nxt_state_dup[k/8] == S_MAC2);
            end
            for(k=0; k<8; k=k+1) state_dup[k] <= nxt_state_dup[k];
        end
    end

    integer i_xb;
    always @(posedge clk) begin
        for (i_xb = 0; i_xb < 192; i_xb = i_xb + 1) begin
            if (state_dup[i_xb/24] == S_COLLECT) begin
                if (in_fire_dup[i_xb/24] && in_och_b == i_xb) xbuf[i_xb] <= in_data_b;
            end else if (state_dup[i_xb/24] == S_IDLE) begin
                if (in_fire_dup[i_xb/24] && in_och_b == 0 && i_xb == 0) xbuf[0] <= in_data_b;
            end
        end
    end

    integer i;
    always @(posedge clk) begin
        for(i=0; i<64; i=i+1) begin
            if (mac_load_en[i]) begin
                if (mac_mux_sel[i] == 2'd0) begin
                    mac_x_reg[i] <= xbuf[i];
                    mac_w_reg[i] <= w_flat[i];
                end else if (mac_mux_sel[i] == 2'd1) begin
                    mac_x_reg[i] <= xbuf[i+64];
                    mac_w_reg[i] <= w_flat[i+64];
                end else begin
                    mac_x_reg[i] <= xbuf[i+128];
                    mac_w_reg[i] <= w_flat[i+128];
                end
            end
        end
    end

    (* use_dsp = "yes" *) reg signed [31:0] dsp_acc [0:63];
    genvar gm; generate for (gm = 0; gm < 64; gm = gm + 1) begin : gen_mac_dsp
        always @(posedge clk) begin
            if (!rst_n) dsp_acc[gm] <= 32'sd0;
            else if (clr_acc_q[gm]) dsp_acc[gm] <= $signed(mac_x_reg[gm]) * $signed(mac_w_reg[gm]);
            else if (en_mac_q[gm])  dsp_acc[gm] <= dsp_acc[gm] + ($signed(mac_x_reg[gm]) * $signed(mac_w_reg[gm]));
        end
    end endgenerate

    // ==========================================
    // [修复重点] 纯净的二进制二叉树，每个时钟周期绝对只做两两相加
    // ==========================================
    (* use_dsp = "no" *) wire signed [32:0] nxt_tree_32 [0:31]; reg signed [32:0] tree_32 [0:31];
    (* use_dsp = "no" *) wire signed [33:0] nxt_tree_16 [0:15]; reg signed [33:0] tree_16 [0:15];
    (* use_dsp = "no" *) wire signed [34:0] nxt_tree_8 [0:7];   reg signed [34:0] tree_8 [0:7];
    (* use_dsp = "no" *) wire signed [35:0] nxt_tree_4 [0:3];   reg signed [35:0] tree_4 [0:3];
    reg signed [36:0] tree_2 [0:1];

    genvar t32, t16, t8, t4;
    generate
        for(t32=0; t32<32; t32=t32+1) begin : gen_t32
            assign nxt_tree_32[t32] = dsp_acc[t32*2] + dsp_acc[t32*2+1];
        end
        for(t16=0; t16<16; t16=t16+1) begin : gen_t16
            assign nxt_tree_16[t16] = tree_32[t16*2] + tree_32[t16*2+1];
        end
        for(t8=0; t8<8; t8=t8+1) begin : gen_t8
            assign nxt_tree_8[t8]  = tree_16[t8*2] + tree_16[t8*2+1];
        end
        for(t4=0; t4<4; t4=t4+1) begin : gen_t4
            assign nxt_tree_4[t4]  = tree_8[t4*2]  + tree_8[t4*2+1];
        end
    endgenerate
    
    (* use_dsp = "no" *) wire signed [36:0] nxt_tree_2_0 = tree_4[0] + tree_4[1];
    (* use_dsp = "no" *) wire signed [36:0] nxt_tree_2_1 = tree_4[2] + tree_4[3];
    
    function signed [ACC_W-1:0] sext37_to_acc;
        input signed [36:0] x;
        begin sext37_to_acc = {{(ACC_W-37){x[36]}}, x}; end
    endfunction

    (* use_dsp = "no" *) wire signed [ACC_W-1:0] nxt_tree_out = sext37_to_acc(tree_2[0]) + sext37_to_acc(tree_2[1]) + bias_round_reg;
    
    reg int_valid_reg;
    assign int_valid = int_valid_reg;

    always @(posedge clk) begin
        if (!rst_n) begin
            state       <= S_IDLE;
            pix_lat     <= 10'd0; och_cur <= 6'd0; bias_lat <= 32'sd0;
            acc_shifted <= {ACC_W{1'b0}}; bias_round_reg <= {ACC_W{1'b0}};
            w_addr      <= 6'd0; b_addr <= 6'd0;
            int_valid_reg <= 1'b0; int_och <= 6'd0; int_pix_idx <= 10'd0; int_data <= 13'sd0;
            for(i=0; i<32; i=i+1) tree_32[i] <= 33'sd0;
            for(i=0; i<16; i=i+1) tree_16[i] <= 34'sd0;
            for(i=0; i<8;  i=i+1) tree_8[i]  <= 35'sd0;
            for(i=0; i<4;  i=i+1) tree_4[i]  <= 36'sd0;
            tree_2[0] <= 37'sd0; tree_2[1] <= 37'sd0;
        end else begin
            state <= nxt_state;
            case (state)
                S_IDLE: begin
                    int_valid_reg <= 1'b0;
                    if (in_fire && (in_och_b == 8'd0)) pix_lat <= in_pix_idx_b;
                end
                S_COLLECT: begin
                    int_valid_reg <= 1'b0;
                    if (in_fire && (in_och_b == 8'd191)) begin och_cur <= 6'd0; w_addr <= 6'd0; b_addr <= 6'd0; end
                end
                S_WAIT: begin
                    int_valid_reg <= 1'b0;
                    if (rom_aligned) begin 
                        bias_lat <= b_dout;
                        bias_round_reg <= sext32_to_acc(b_dout) + round_const;
                    end
                end
                S_MAC0: int_valid_reg <= 1'b0;
                S_MAC1: int_valid_reg <= 1'b0;
                S_MAC2: int_valid_reg <= 1'b0;
                S_TREE0: begin for (i = 0; i < 32; i = i + 1) tree_32[i] <= nxt_tree_32[i]; end
                S_TREE1: begin for (i = 0; i < 16; i = i + 1) tree_16[i] <= nxt_tree_16[i]; end
                S_TREE2: begin for (i = 0; i < 8; i  = i + 1) tree_8[i]  <= nxt_tree_8[i];  end
                S_TREE3: begin for (i = 0; i < 4; i  = i + 1) tree_4[i]  <= nxt_tree_4[i];  end
                S_TREE4: begin tree_2[0] <= nxt_tree_2_0; tree_2[1] <= nxt_tree_2_1; end
                S_FMT: begin
                    if (OUT_SHIFT != 0) acc_shifted <= nxt_tree_out >>> OUT_SHIFT;
                    else                acc_shifted <= nxt_tree_out;
                end
                S_OUT: begin
                    int_valid_reg   <= 1'b1;
                    int_och         <= och_cur;
                    int_pix_idx     <= pix_lat;
                    if ((USE_RELU != 0) && acc_shifted[ACC_W-1]) int_data <= 13'sd0;
                    else                                         int_data <= acc_shifted[12:0];
                        
                    if (int_fire) begin
                        int_valid_reg <= 1'b0;
                        if (och_cur != 6'd63) begin
                            och_cur <= och_cur + 6'd1;
                            w_addr  <= och_cur + 6'd1;
                            b_addr  <= och_cur + 6'd1;
                        end
                    end
                end
                default: int_valid_reg <= 1'b0;
            endcase
        end
    end
endmodule

// ROM模块代码保持原样
module proj_gbank64x16_to3072_rom #(parameter MEM = "")(
    input  wire          clk, input  wire [5:0]    addr, output reg  [5:0]    addr_q, output reg  [3071:0] dout
);
    (* rom_style = "block" *) reg [3071:0] mem [0:63];
    initial begin $readmemh(MEM, mem); end
    always @(posedge clk) begin dout <= mem[addr]; addr_q <= addr; end
endmodule

module proj_bias64_i32_rom #(parameter BIAS_MEM_FILE = "")(
    input  wire        clk, input  wire [5:0]  addr, output reg  [5:0]  addr_q, output reg  [31:0] dout
);
    (* rom_style = "distributed" *)reg [31:0] mem [0:63];
    initial begin $readmemh(BIAS_MEM_FILE, mem); end
    always @(posedge clk) begin dout <= mem[addr]; addr_q <= addr; end
endmodule
`default_nettype wire