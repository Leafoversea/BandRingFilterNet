`timescale 1ns/1ps
`default_nettype none

module pointwise1x1_grp8_32to96_vr #(
    parameter integer USE_RELU  = 1,
    parameter integer OUT_SHIFT = 15
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_valid,
    output wire        in_ready,
    input  wire [5:0]  in_och,
    input  wire [9:0]  in_pix_idx,
    input  wire signed [12:0] in_data,

    output reg         out_valid,
    input  wire        out_ready,
    output reg  [6:0]  out_och,
    output reg  [9:0]  out_pix_idx,
    output reg  signed [12:0] out_data
);

    localparam integer NUM_IC = 32;
    localparam integer ACC_W  = 40;

    // ============================================================
    // 1) Dual input buffers (ping-pong)
    // ============================================================
    reg signed [12:0] xbuf0 [0:NUM_IC-1];
    reg signed [12:0] xbuf1 [0:NUM_IC-1];
    reg [9:0]         pix0, pix1;

    reg buf_full0, buf_full1;
    reg wr_pref;
    reg wr_active;
    reg wr_sel_lock;

    (* keep = "true", max_fanout = "16" *) reg rd_sel_0;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_1;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_2;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_3;

    wire both_full = buf_full0 && buf_full1;
    assign in_ready = !both_full;
    wire in_fire = in_valid && in_ready;

    wire choose_buf0 = (!buf_full0) && ((wr_pref == 1'b0) || buf_full1);
    wire choose_buf1 = (!buf_full1) && ((wr_pref == 1'b0) || buf_full0);

    task write_xbuf32;
        input sel;
        input [4:0] idx;
        input signed [12:0] val;
        begin
            if (!sel) xbuf0[idx] <= val;
            else      xbuf1[idx] <= val;
        end
    endtask

    wire rd_buf_full = (rd_sel_0 == 1'b0) ? buf_full0 : buf_full1;
    wire other_full  = (rd_sel_0 == 1'b0) ? buf_full1 : buf_full0;
    wire [9:0] rd_pix = (rd_sel_0 == 1'b0) ? pix0 : pix1;

    // ============================================================
    // 2) ROMs
    // ============================================================
    (* keep = "true" *) reg  [6:0] w_addr;
    (* keep = "true" *) reg  [6:0] b_addr;

    wire [127:0] wgb0, wgb1, wgb2, wgb3;
    wire [6:0]   w0_addr_q;
    wire [6:0]   b_addr_q;

    pw_gbank96x16_to128_rom u_w0(
        .clk(clk),
        .addr(w_addr),
        .addr_q(w0_addr_q),
        .dout({wgb0, wgb1, wgb2, wgb3})
    );

    wire [31:0] b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;
    bias96_i32_rom u_b(
        .clk(clk),
        .addr(b_addr),
        .addr_q(b_addr_q),
        .dout(b_dout_u)
    );

    // ============================================================
    // 3) 32-mul + Pipeline Stages
    // ============================================================
    reg        s0_v;
    reg [6:0]  s0_och;
    reg [9:0]  s0_pix;
    reg signed [31:0] s0_bias;
    reg signed [12:0] x_s0 [0:31];
    reg signed [16:0] w_s0 [0:31];

    reg        s1_v;
    reg [6:0]  s1_och;
    reg [9:0]  s1_pix;
    reg signed [31:0] s1_bias;
    (* use_dsp = "yes" *) reg signed [31:0] s1_p [0:31];

    reg        s2_v;
    reg [6:0]  s2_och;
    reg [9:0]  s2_pix;
    reg signed [31:0] s2_bias;
    reg signed [ACC_W-1:0] s2_s [0:15];

    reg        s2b_v;
    reg [6:0]  s2b_och;
    reg [9:0]  s2b_pix;
    reg signed [31:0] s2b_bias;
    reg signed [ACC_W-1:0] s2b_s [0:7];

    reg        s3_v;
    reg [6:0]  s3_och;
    reg [9:0]  s3_pix;
    reg signed [31:0] s3_bias;
    reg signed [ACC_W-1:0] s3_s [0:3];

    reg        s4_v;
    reg [6:0]  s4_och;
    reg [9:0]  s4_pix;
    reg signed [31:0] s4_bias;
    reg signed [ACC_W-1:0] s4_t0, s4_t1;

    reg        s5_v;
    reg [6:0]  s5_och;
    reg [9:0]  s5_pix;
    // ★ TIMING FIX: 强制要求 s5_sum_bias 不使用 DSP，打断 DSP -> SLICE 的严重走线延迟
    (* use_dsp = "no" *) reg signed [ACC_W-1:0] s5_sum_bias;

    reg        s6_v;
    reg [6:0]  s6_och;
    reg [9:0]  s6_pix;
    reg signed [ACC_W-1:0] s6_xs;

    reg skid_full;
    reg [6:0]  skid_och;
    reg [9:0]  skid_pix;
    reg signed [12:0] skid_data;

    wire pipe_en = !skid_full;
    wire s6_rdy  = pipe_en;
    wire s5_rdy  = pipe_en;
    wire s4_rdy  = pipe_en;
    wire s3_rdy  = pipe_en;
    wire s2b_rdy = pipe_en;
    wire s2_rdy  = pipe_en;
    wire s1_rdy  = pipe_en;
    wire s0_rdy  = pipe_en;

    // helpers
    function signed [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x;
        begin
            sext32_to_acc = {{(ACC_W-32){x[31]}}, x};
        end
    endfunction

    wire signed [ACC_W-1:0] round_pos_w = (OUT_SHIFT == 0) ?
        {ACC_W{1'b0}} : ($signed({{(ACC_W-1){1'b0}}, 1'b1}) <<< (OUT_SHIFT-1));
    wire signed [ACC_W-1:0] round_neg_w = (OUT_SHIFT == 0) ?
        {ACC_W{1'b0}} : (round_pos_w - $signed({{(ACC_W-1){1'b0}}, 1'b1}));

    // ★ TIMING FIX: 重构对称舍入加法，利用 A + B + Cin (Cin = ~Sign) 节省LUT层级
    wire s5_sign = s5_sum_bias[ACC_W-1];
    wire signed [ACC_W-1:0] s5_rounded_sum = s5_sum_bias + round_neg_w + {{(ACC_W-1){1'b0}}, ~s5_sign};

    function signed [12:0] sat13_from_acc;
        input signed [ACC_W-1:0] x;
        begin
            if (x[ACC_W-1] == 1'b0) begin
                if (|x[ACC_W-2:12]) sat13_from_acc = 13'sd4095;
                else                sat13_from_acc = x[12:0];
            end else begin
                if (~&x[ACC_W-2:12]) sat13_from_acc = -13'sd4096;
                else                 sat13_from_acc = x[12:0];
            end
        end
    endfunction

    function signed [12:0] relu_sat13_from_acc;
        input signed [ACC_W-1:0] x;
        begin
            if ((USE_RELU != 0) && x[ACC_W-1]) relu_sat13_from_acc = 13'sd0;
            else                               relu_sat13_from_acc = sat13_from_acc(x);
        end
    endfunction

    // ============================================================
    // 4) Issue/Capture control
    // ============================================================
    reg        run;
    reg [6:0]  issue_och;
    reg        issued_all;
    reg        cap_pending;
    reg [6:0]  exp_och;

    wire last_issue = (issue_och == 7'd95);
    wire rom_aligned_exp = (w0_addr_q == exp_och);
    wire will_capture = run && cap_pending && pipe_en && rom_aligned_exp;
    wire can_issue    = run && pipe_en && (!issued_all) && ( (!cap_pending) || will_capture );
    wire can_capture  = will_capture;

    // ★ TIMING FIX: 删除了旧版的 LUT1 fanout 缓冲，因为我们在 S0 修改了捕获策略
    
    // ============================================================
    // 6) Sequential
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            buf_full0   <= 1'b0;
            buf_full1   <= 1'b0;
            wr_pref     <= 1'b0;
            wr_active   <= 1'b0;
            wr_sel_lock <= 1'b0;
            rd_sel_0    <= 1'b0;
            rd_sel_1    <= 1'b0;
            rd_sel_2    <= 1'b0;
            rd_sel_3    <= 1'b0;

            w_addr      <= 7'd0;
            b_addr      <= 7'd0;
            run         <= 1'b0;
            issue_och   <= 7'd0;
            issued_all  <= 1'b0;
            cap_pending <= 1'b0;
            exp_och     <= 7'd0;

            s0_v  <= 1'b0;
            s1_v  <= 1'b0;
            s2_v  <= 1'b0;
            s2b_v <= 1'b0;
            s3_v  <= 1'b0;
            s4_v  <= 1'b0;
            s5_v  <= 1'b0;
            s6_v  <= 1'b0;

            out_valid <= 1'b0;
            skid_full <= 1'b0;
        end else begin
            // ------------------------------------------------------------
            // A) Input collection
            // ------------------------------------------------------------
            if (in_fire) begin
                if (!wr_active && (in_och == 6'd0)) begin
                    if (choose_buf0) begin
                        wr_sel_lock <= 1'b0;
                        wr_active   <= 1'b1;
                        pix0        <= in_pix_idx;
                        xbuf0[0]    <= $signed(in_data);
                    end else if (choose_buf1) begin
                        wr_sel_lock <= 1'b1;
                        wr_active   <= 1'b1;
                        pix1        <= in_pix_idx;
                        xbuf1[0]    <= $signed(in_data);
                    end
                end else if (wr_active && (in_och < 6'd32)) begin
                    write_xbuf32(wr_sel_lock, in_och[4:0], $signed(in_data));
                end

                if (wr_active && (in_och == 6'd31)) begin
                    if (!wr_sel_lock) buf_full0 <= 1'b1;
                    else              buf_full1 <= 1'b1;
                    wr_pref   <= ~wr_sel_lock;
                    wr_active <= 1'b0;
                end
            end

            // ------------------------------------------------------------
            // B) Run Control 
            // ------------------------------------------------------------
            if (!run) begin
                if (!rd_sel_0) begin
                    if (!buf_full0 && buf_full1) begin
                        rd_sel_0 <= 1'b1;
                        rd_sel_1 <= 1'b1; rd_sel_2 <= 1'b1; rd_sel_3 <= 1'b1;
                    end
                end else begin
                    if (!buf_full1 && buf_full0) begin
                        rd_sel_0 <= 1'b0;
                        rd_sel_1 <= 1'b0; rd_sel_2 <= 1'b0; rd_sel_3 <= 1'b0;
                    end
                end

                if (rd_buf_full) begin
                    run         <= 1'b1;
                    issued_all  <= 1'b0;
                    cap_pending <= 1'b0;
                end
            end else begin
                // --------------------------------------------------------
                // C) Issue
                // --------------------------------------------------------
                if (can_issue) begin
                    w_addr  <= issue_och;
                    b_addr  <= issue_och;
                    exp_och <= issue_och;
                    if (last_issue) issued_all <= 1'b1;
                    else            issue_och <= issue_och + 7'd1;
                end else if (issued_all && !cap_pending) begin
                    w_addr    <= 7'd0;
                    b_addr    <= 7'd0;
                    issue_och <= 7'd0;
                    exp_och   <= 7'd0;
                end

                // --------------------------------------------------------
                // D) cap_pending update
                // --------------------------------------------------------
                begin : CAP_UPD
                    reg issued_this;
                    reg captured_this;
                    issued_this   = can_issue;
                    captured_this = can_capture;
                    cap_pending <= (cap_pending && !captured_this) || issued_this;
                end

                // --------------------------------------------------------
                // E & G) S0~S6 Stages 
                // --------------------------------------------------------
                
                // ★ TIMING FIX: 无条件流水线同步推进。移除 `can_capture` 对数据通路的硬门控，
                // 转而让其只驱动 `s0_v`。避免 Vivado 将长路径连接到 DSP CE 引脚上造成高扇出违例。
                if (s0_rdy) begin 
                    s0_v <= can_capture;
                    
                    s0_och  <= exp_och;
                    s0_pix  <= rd_pix; 
                    s0_bias <= b_dout;
                    
                    x_s0[0]  <= rd_sel_0 ? xbuf1[0] : xbuf0[0]; w_s0[0]  <= $signed(wgb0[15:0]);
                    x_s0[1]  <= rd_sel_0 ? xbuf1[1] : xbuf0[1]; w_s0[1]  <= $signed(wgb0[31:16]);
                    x_s0[2]  <= rd_sel_0 ? xbuf1[2] : xbuf0[2]; w_s0[2]  <= $signed(wgb0[47:32]);
                    x_s0[3]  <= rd_sel_0 ? xbuf1[3] : xbuf0[3]; w_s0[3]  <= $signed(wgb0[63:48]);
                    x_s0[4]  <= rd_sel_0 ? xbuf1[4] : xbuf0[4]; w_s0[4]  <= $signed(wgb0[79:64]);
                    x_s0[5]  <= rd_sel_0 ? xbuf1[5] : xbuf0[5]; w_s0[5]  <= $signed(wgb0[95:80]);
                    x_s0[6]  <= rd_sel_0 ? xbuf1[6] : xbuf0[6]; w_s0[6]  <= $signed(wgb0[111:96]);
                    x_s0[7]  <= rd_sel_0 ? xbuf1[7] : xbuf0[7]; w_s0[7]  <= $signed(wgb0[127:112]);

                    x_s0[8]  <= rd_sel_1 ? xbuf1[8] : xbuf0[8];   w_s0[8]  <= $signed(wgb1[15:0]);
                    x_s0[9]  <= rd_sel_1 ? xbuf1[9] : xbuf0[9];   w_s0[9]  <= $signed(wgb1[31:16]);
                    x_s0[10] <= rd_sel_1 ? xbuf1[10]: xbuf0[10];  w_s0[10] <= $signed(wgb1[47:32]);
                    x_s0[11] <= rd_sel_1 ? xbuf1[11]: xbuf0[11];  w_s0[11] <= $signed(wgb1[63:48]);
                    x_s0[12] <= rd_sel_1 ? xbuf1[12]: xbuf0[12];  w_s0[12] <= $signed(wgb1[79:64]);
                    x_s0[13] <= rd_sel_1 ? xbuf1[13]: xbuf0[13];  w_s0[13] <= $signed(wgb1[95:80]);
                    x_s0[14] <= rd_sel_1 ? xbuf1[14]: xbuf0[14];  w_s0[14] <= $signed(wgb1[111:96]);
                    x_s0[15] <= rd_sel_1 ? xbuf1[15]: xbuf0[15];  w_s0[15] <= $signed(wgb1[127:112]);

                    x_s0[16] <= rd_sel_2 ? xbuf1[16]: xbuf0[16];  w_s0[16] <= $signed(wgb2[15:0]);
                    x_s0[17] <= rd_sel_2 ? xbuf1[17]: xbuf0[17];  w_s0[17] <= $signed(wgb2[31:16]);
                    x_s0[18] <= rd_sel_2 ? xbuf1[18]: xbuf0[18];  w_s0[18] <= $signed(wgb2[47:32]);
                    x_s0[19] <= rd_sel_2 ? xbuf1[19]: xbuf0[19];  w_s0[19] <= $signed(wgb2[63:48]);
                    x_s0[20] <= rd_sel_2 ? xbuf1[20]: xbuf0[20];  w_s0[20] <= $signed(wgb2[79:64]);
                    x_s0[21] <= rd_sel_2 ? xbuf1[21]: xbuf0[21];  w_s0[21] <= $signed(wgb2[95:80]);
                    x_s0[22] <= rd_sel_2 ? xbuf1[22]: xbuf0[22];  w_s0[22] <= $signed(wgb2[111:96]);
                    x_s0[23] <= rd_sel_2 ? xbuf1[23]: xbuf0[23];  w_s0[23] <= $signed(wgb2[127:112]);

                    x_s0[24] <= rd_sel_3 ? xbuf1[24]: xbuf0[24];  w_s0[24] <= $signed(wgb3[15:0]);
                    x_s0[25] <= rd_sel_3 ? xbuf1[25]: xbuf0[25];  w_s0[25] <= $signed(wgb3[31:16]);
                    x_s0[26] <= rd_sel_3 ? xbuf1[26]: xbuf0[26];  w_s0[26] <= $signed(wgb3[47:32]);
                    x_s0[27] <= rd_sel_3 ? xbuf1[27]: xbuf0[27];  w_s0[27] <= $signed(wgb3[63:48]);
                    x_s0[28] <= rd_sel_3 ? xbuf1[28]: xbuf0[28];  w_s0[28] <= $signed(wgb3[79:64]);
                    x_s0[29] <= rd_sel_3 ? xbuf1[29]: xbuf0[29];  w_s0[29] <= $signed(wgb3[95:80]);
                    x_s0[30] <= rd_sel_3 ? xbuf1[30]: xbuf0[30];  w_s0[30] <= $signed(wgb3[111:96]);
                    x_s0[31] <= rd_sel_3 ? xbuf1[31]: xbuf0[31];  w_s0[31] <= $signed(wgb3[127:112]);
                end

                if (s1_rdy) begin
                    if (s0_v) begin
                        s1_v <= 1'b1;
                        s1_och <= s0_och; s1_pix <= s0_pix; s1_bias <= s0_bias;
                        s1_p[0]  <= $signed(x_s0[0])  * $signed(w_s0[0]);   s1_p[1]  <= $signed(x_s0[1])  * $signed(w_s0[1]);
                        s1_p[2]  <= $signed(x_s0[2])  * $signed(w_s0[2]);   s1_p[3]  <= $signed(x_s0[3])  * $signed(w_s0[3]);
                        s1_p[4]  <= $signed(x_s0[4])  * $signed(w_s0[4]);   s1_p[5]  <= $signed(x_s0[5])  * $signed(w_s0[5]);
                        s1_p[6]  <= $signed(x_s0[6])  * $signed(w_s0[6]);   s1_p[7]  <= $signed(x_s0[7])  * $signed(w_s0[7]);
                        s1_p[8]  <= $signed(x_s0[8])  * $signed(w_s0[8]);   s1_p[9]  <= $signed(x_s0[9])  * $signed(w_s0[9]);
                        s1_p[10] <= $signed(x_s0[10]) * $signed(w_s0[10]);  s1_p[11] <= $signed(x_s0[11]) * $signed(w_s0[11]);
                        s1_p[12] <= $signed(x_s0[12]) * $signed(w_s0[12]);  s1_p[13] <= $signed(x_s0[13]) * $signed(w_s0[13]);
                        s1_p[14] <= $signed(x_s0[14]) * $signed(w_s0[14]);  s1_p[15] <= $signed(x_s0[15]) * $signed(w_s0[15]);
                        s1_p[16] <= $signed(x_s0[16]) * $signed(w_s0[16]);  s1_p[17] <= $signed(x_s0[17]) * $signed(w_s0[17]);
                        s1_p[18] <= $signed(x_s0[18]) * $signed(w_s0[18]);  s1_p[19] <= $signed(x_s0[19]) * $signed(w_s0[19]);
                        s1_p[20] <= $signed(x_s0[20]) * $signed(w_s0[20]);  s1_p[21] <= $signed(x_s0[21]) * $signed(w_s0[21]);
                        s1_p[22] <= $signed(x_s0[22]) * $signed(w_s0[22]);  s1_p[23] <= $signed(x_s0[23]) * $signed(w_s0[23]);
                        s1_p[24] <= $signed(x_s0[24]) * $signed(w_s0[24]);  s1_p[25] <= $signed(x_s0[25]) * $signed(w_s0[25]);
                        s1_p[26] <= $signed(x_s0[26]) * $signed(w_s0[26]);  s1_p[27] <= $signed(x_s0[27]) * $signed(w_s0[27]);
                        s1_p[28] <= $signed(x_s0[28]) * $signed(w_s0[28]);  s1_p[29] <= $signed(x_s0[29]) * $signed(w_s0[29]);
                        s1_p[30] <= $signed(x_s0[30]) * $signed(w_s0[30]);  s1_p[31] <= $signed(x_s0[31]) * $signed(w_s0[31]);
                    end else s1_v <= 1'b0;
                end

                if (s2_rdy) begin
                    if (s1_v) begin
                        s2_v <= 1'b1;
                        s2_och <= s1_och; s2_pix <= s1_pix; s2_bias <= s1_bias;
                        s2_s[0]  <= sext32_to_acc(s1_p[0])  + sext32_to_acc(s1_p[1]);
                        s2_s[1]  <= sext32_to_acc(s1_p[2])  + sext32_to_acc(s1_p[3]);
                        s2_s[2]  <= sext32_to_acc(s1_p[4])  + sext32_to_acc(s1_p[5]);
                        s2_s[3]  <= sext32_to_acc(s1_p[6])  + sext32_to_acc(s1_p[7]);
                        s2_s[4]  <= sext32_to_acc(s1_p[8])  + sext32_to_acc(s1_p[9]);   s2_s[5]  <= sext32_to_acc(s1_p[10]) + sext32_to_acc(s1_p[11]);
                        s2_s[6]  <= sext32_to_acc(s1_p[12]) + sext32_to_acc(s1_p[13]);  s2_s[7]  <= sext32_to_acc(s1_p[14]) + sext32_to_acc(s1_p[15]);
                        s2_s[8]  <= sext32_to_acc(s1_p[16]) + sext32_to_acc(s1_p[17]);  s2_s[9]  <= sext32_to_acc(s1_p[18]) + sext32_to_acc(s1_p[19]);
                        s2_s[10] <= sext32_to_acc(s1_p[20]) + sext32_to_acc(s1_p[21]);  s2_s[11] <= sext32_to_acc(s1_p[22]) + sext32_to_acc(s1_p[23]);
                        s2_s[12] <= sext32_to_acc(s1_p[24]) + sext32_to_acc(s1_p[25]);  s2_s[13] <= sext32_to_acc(s1_p[26]) + sext32_to_acc(s1_p[27]);
                        s2_s[14] <= sext32_to_acc(s1_p[28]) + sext32_to_acc(s1_p[29]);  s2_s[15] <= sext32_to_acc(s1_p[30]) + sext32_to_acc(s1_p[31]);
                    end else s2_v <= 1'b0;
                end

                if (s2b_rdy) begin
                    if (s2_v) begin
                        s2b_v <= 1'b1;
                        s2b_och <= s2_och; s2b_pix <= s2_pix; s2b_bias <= s2_bias;
                        s2b_s[0] <= s2_s[0]  + s2_s[1];   s2b_s[1] <= s2_s[2]  + s2_s[3];
                        s2b_s[2] <= s2_s[4]  + s2_s[5];   s2b_s[3] <= s2_s[6]  + s2_s[7];
                        s2b_s[4] <= s2_s[8]  + s2_s[9];   s2b_s[5] <= s2_s[10] + s2_s[11];
                        s2b_s[6] <= s2_s[12] + s2_s[13];  s2b_s[7] <= s2_s[14] + s2_s[15];
                    end else s2b_v <= 1'b0;
                end

                if (s3_rdy) begin
                    if (s2b_v) begin
                        s3_v <= 1'b1;
                        s3_och <= s2b_och; s3_pix <= s2b_pix; s3_bias <= s2b_bias;
                        s3_s[0] <= s2b_s[0] + s2b_s[1];  s3_s[1] <= s2b_s[2] + s2b_s[3];
                        s3_s[2] <= s2b_s[4] + s2b_s[5];  s3_s[3] <= s2b_s[6] + s2b_s[7];
                    end else s3_v <= 1'b0;
                end

                if (s4_rdy) begin
                    if (s3_v) begin
                        s4_v <= 1'b1;
                        s4_och <= s3_och; s4_pix <= s3_pix; s4_bias <= s3_bias;
                        s4_t0 <= s3_s[0] + s3_s[1]; s4_t1 <= s3_s[2] + s3_s[3];
                    end else s4_v <= 1'b0;
                end

                if (s5_rdy) begin
                    if (s4_v) begin
                        s5_v <= 1'b1;
                        s5_och <= s4_och; s5_pix <= s4_pix;
                        s5_sum_bias <= (s4_t0 + s4_t1) + sext32_to_acc(s4_bias);
                    end else s5_v <= 1'b0;
                end

                // ★ TIMING FIX: S6 重新实现了对称舍入数学逻辑，并调用优化过的进位加法节点
                if (s6_rdy) begin
                    if (s5_v) begin
                        s6_v <= 1'b1;
                        s6_och <= s5_och; s6_pix <= s5_pix;
                        if (OUT_SHIFT == 0) begin
                            s6_xs <= s5_sum_bias;
                        end else begin
                            s6_xs <= s5_rounded_sum >>> OUT_SHIFT;
                        end
                    end else s6_v <= 1'b0;
                end

                // --------------------------------------------------------
                // F) 输出层 Skid Buffer 直通逻辑
                // --------------------------------------------------------
                if (out_ready || !out_valid) begin
                    if (skid_full) begin
                        out_valid   <= 1'b1;
                        out_och     <= skid_och;
                        out_pix_idx <= skid_pix;
                        out_data    <= skid_data;
                        skid_full   <= 1'b0; 
                    end else if (s6_v) begin
                        out_valid   <= 1'b1;
                        out_och     <= s6_och;
                        out_pix_idx <= s6_pix;
                        out_data    <= relu_sat13_from_acc(s6_xs);
                    end else begin
                        out_valid   <= 1'b0;
                    end
                end else begin
                    if (s6_v && pipe_en) begin
                        skid_full <= 1'b1;
                        skid_och  <= s6_och;
                        skid_pix  <= s6_pix;
                        skid_data <= relu_sat13_from_acc(s6_xs);
                    end
                end

                // --------------------------------------------------------
                // H) End-of-pixel 状态机
                // --------------------------------------------------------
                if (out_valid && out_ready && (out_och == 7'd95)) begin
                    if (rd_sel_0 == 1'b0) buf_full0 <= 1'b0;
                    else                  buf_full1 <= 1'b0;
                    if (other_full) begin
                        rd_sel_0    <= ~rd_sel_0;
                        rd_sel_1    <= ~rd_sel_1;
                        rd_sel_2    <= ~rd_sel_2;
                        rd_sel_3    <= ~rd_sel_3;
                        run         <= 1'b1;
                        issued_all  <= 1'b0;
                    end else begin
                        run         <= 1'b0;
                        issued_all  <= 1'b0;
                        cap_pending <= 1'b0;
                    end
                end
            end // run
        end
    end
endmodule
`default_nettype wire