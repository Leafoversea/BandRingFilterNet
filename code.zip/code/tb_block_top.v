`timescale 1ns / 1ps
module tb_block_top;
// 你可以改成你想要的默认输出路径
localparam PJ_DUMP_PATH  = "E:/region/python/coe/11_project_hw130.txt";
localparam RING_PATH  = "E:/region/python/coe/ring.txt";
localparam DOWN1_PATH = "E:/region/python/coe/tb_out_down1.txt";
localparam DOWN2_PATH = "E:/region/python/coe/tb_out_down2.txt";
localparam ST3= "E:/region/python/coe/project_st3.txt";
reg in_clk;
reg rst_n;
wire        soft_valid;
wire [7:0]  led_out;

initial begin
    in_clk = 1'b0;
    forever #10 in_clk = ~in_clk;
end
initial begin
    rst_n = 1'b0;
    #50;
    rst_n = 1'b1;
end

block_top dut(
    .board_clk(in_clk),
    .board_rst_n(rst_n),
    .soft_valid (soft_valid),
    .led_out   (led_out)
    );
always @(*) begin
    if(led_out!=0)begin
        #2
        $finish;
    end 
end

endmodule
