`timescale 1ns / 1ps

module down2x2s2_grp_param_vr #(
    parameter integer W         = 32,
    parameter integer IC        = 32,
    parameter integer OC        = 48,
    parameter integer ROM_LAT   = 1,
    parameter integer USE_RELU  = 0,
    parameter integer OUT_SHIFT = 15,
    parameter [8*256-1:0] MEM_BASE_PATH = "E:/Desktop/ring2/save_to_FPGA/down"
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_valid,
    output wire        in_ready,
    input  wire [$clog2(IC)-1:0] in_och,
    input  wire [9:0]            in_pix_idx,
    input  wire [12:0]           in_data,

    output reg         out_valid,
    input  wire        out_ready,
    output reg  [$clog2(OC)-1:0] out_och,
    output reg  [9:0]            out_pix_idx,
    output reg  [12:0]           out_data,
    output wire        out_last
);

    localparam PIXMAX = W*W/4;
    assign out_last = (out_och == OC-1) && (out_pix_idx == PIXMAX-1) && out_valid && out_ready;

    // ==========================================
    // 参数与动态位宽计算
    // ==========================================
    localparam integer GROUPS   = IC / 8;
    localparam integer W_DEPTH  = GROUPS * 4 * OC;

    localparam integer IC_W     = $clog2(IC);
    localparam integer OC_W     = $clog2(OC);
    localparam integer GRP_W    = $clog2(GROUPS);
    localparam integer W_ADDR_W = $clog2(W_DEPTH);
    localparam integer X_W      = $clog2(W);

    localparam [GRP_W-1:0]    GRP_MAX = GROUPS - 1;
    localparam [OC_W-1:0]     OC_MAX  = OC - 1;
    localparam [W_ADDR_W-1:0] OC_STEP = OC;
    
    // [优化2]: 预计算四舍五入常数，吸收到偏置累加级
    localparam signed [63:0] ROUND_OFFSET = (OUT_SHIFT != 0) ? (64'sd1 <<< (OUT_SHIFT-1)) : 64'sd0;

    reg [2:0] state;
    localparam [2:0] S_IDLE=3'd0, S_COLLECT=3'd1, S_WAIT=3'd2, S_MAC=3'd3, S_MAC_DRAIN=3'd4, S_OUT=3'd5;

    assign in_ready = (state == S_COLLECT) || ((state == S_IDLE) && (in_och == {IC_W{1'b0}}));
    wire in_fire  = in_valid && in_ready;
    wire out_fire = out_valid && out_ready;

    // ==========================================
    // 动态 X/Y 坐标解析
    // ==========================================
    reg [9:0] pix_lat;
    wire [X_W-1:0] pix_x = pix_lat[X_W-1:0];
    wire [9:0]     pix_y = pix_lat >> X_W;

    wire pix_x_odd = pix_x[0];
    wire pix_y_odd = pix_y[0];

    // ==========================================
    // 通道缓存与 RAM
    // ==========================================
    reg signed [12:0] pix_ch [0:IC-1];

    (* ram_style = "block" *) reg [(GROUPS*104)-1:0] row_even [0:W-1];
    (* ram_style = "block" *) reg [(GROUPS*104)-1:0] row_odd  [0:W-1];

    reg ram_we_d1;
    reg pix_y_odd_d1;
    reg [X_W-1:0] pix_x_d1;
    reg [103:0] gw_arr_d1 [0:GROUPS-1];

    wire [(GROUPS*104)-1:0] pack_word_comb;

    genvar g_idx, k_idx;
    generate
        for (g_idx = 0; g_idx < GROUPS; g_idx = g_idx + 1) begin : GEN_PACK_GRP
            for (k_idx = 0; k_idx < 8; k_idx = k_idx + 1) begin : GEN_PACK_BYTE
                assign pack_word_comb[(g_idx*104) + (k_idx*13) +: 13] =
                    ((g_idx * 8 + k_idx) == (IC - 1)) ? $signed(in_data) : pix_ch[g_idx * 8 + k_idx];
            end
        end
    endgenerate

    wire [(GROUPS*104)-1:0] pack_gw_d1;
    genvar gw_idx;
    generate
        for (gw_idx = 0; gw_idx < GROUPS; gw_idx = gw_idx + 1) begin : GEN_GW_PACK
            assign pack_gw_d1[gw_idx*104 +: 104] = gw_arr_d1[gw_idx];
        end
    endgenerate

    integer i, g;
    always @(posedge clk) begin
        if (ram_we_d1) begin
            if (!pix_y_odd_d1) begin
                row_even[pix_x_d1] <= pack_gw_d1;
            end else begin
                row_odd[pix_x_d1]  <= pack_gw_d1;
            end
        end
    end

    // ==========================================
    // [时序修复核心]: 延迟化窗口加载触发器 (Breaking High Fanout Path)
    // 强制 Vivado 复制这个寄存器来驱动 3328 个 CE 端口
    // ==========================================
    (* max_fanout = "16" *) reg win_load_en;
    reg [X_W-1:0] win_load_x;

    // 窗口缓存
    reg [103:0] win_words [0:31];
    reg [9:0] out_pix_lat;

    reg [OC_W-1:0]  oc_cur;
    reg [1:0]       tap_cur;
    reg [GRP_W-1:0] grp_cur;
    reg signed [31:0] bias_lat;

    reg [OC_W-1:0] w_addr;
    reg [OC_W-1:0] b_addr;
    wire [OC_W-1:0] b_addr_q;
    wire [31:0] b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;

    bias_param_rom #(
        .DEPTH(OC),
        .ADDR_WIDTH(OC_W),
        .MEM_BASE_PATH(MEM_BASE_PATH),
        .FILE_NAME(OC == 64 ? "/bias64_i32.mem" : "/bias48_i32.mem")
    ) u_b (
        .clk(clk),
        .addr(b_addr),
        .addr_q(b_addr_q),
        .dout(b_dout_u)
    );

    wire [4:0] tg_idx = (tap_cur * 8) + grp_cur;

    reg  [W_ADDR_W-1:0] w_all_addr_reg;
    wire [W_ADDR_W-1:0] w_all_addr_q;
    wire [127:0] w_word;

    weight_param_rom #(
        .DEPTH(W_DEPTH),
        .ADDR_WIDTH(W_ADDR_W),
        .MEM_BASE_PATH(MEM_BASE_PATH),
        .FILE_NAME(OC == 64 ? "/w_all_64.mem" : "/w_all_48.mem")
    ) u_w_all (
        .clk(clk),
        .addr(w_all_addr_reg),
        .addr_q(w_all_addr_q),
        .dout(w_word)
    );

    wire [103:0] x_word = win_words[tg_idx];

    // ==========================================
    // 移位截断函数 (只截断，无加法)
    // ==========================================
    function [12:0] shift_sat13;
        input signed [63:0] xr;
        reg signed [63:0] xs;
        begin
            xs = xr >>> OUT_SHIFT;
            if (USE_RELU != 0 && xs[63]) begin
                shift_sat13 = 13'h0000;
            end else begin
                shift_sat13 = xs[12:0];
            end
        end
    endfunction

    wire last_oc = (oc_cur == OC_MAX);
    wire [OC_W-1:0] oc_inc = oc_cur + 1'b1;

    // p1=抓宽字，p2=分lane寄存，p3=乘法，p4=4路加，p5=2路加，p6=1路和，p7=累计，p8=输出
    reg p1_valid, p2_valid, p3_valid, p4_valid, p5_valid, p6_valid, p7_valid, p8_valid;
    reg p1_first, p2_first, p3_first, p4_first, p5_first, p6_first;
    reg p1_last,  p2_last,  p3_last,  p4_last,  p5_last,  p6_last, p7_last, p8_last;

    reg [OC_W-1:0] p1_oc, p2_oc, p3_oc, p4_oc, p5_oc, p6_oc, p7_oc, p8_oc;

    reg [103:0] p1_x_word;
    reg [127:0] p1_w_word;

    (* keep = "true" *) reg signed [12:0] p2_x_lane [0:7];
    (* keep = "true" *) reg signed [15:0] p2_w_lane [0:7];

    (* use_dsp = "yes" *) reg signed [31:0] p3_mult [0:7];

    reg signed [33:0] p4_s0, p4_s1, p4_s2, p4_s3;
    reg signed [34:0] p5_s0, p5_s1;
    reg signed [35:0] p6_mac_sum;
    reg signed [63:0] p7_acc;
    reg [12:0] p8_out_data;

    reg [(GROUPS*104)-1:0] temp_even_m1;
    reg [(GROUPS*104)-1:0] temp_even_p0;
    reg [(GROUPS*104)-1:0] temp_odd_m1;

    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE;
            pix_lat <= 10'd0;
            out_valid <= 1'b0;
            out_och <= {OC_W{1'b0}};
            out_pix_idx <= 10'd0;
            out_data <= 13'd0;
            oc_cur <= {OC_W{1'b0}};
            tap_cur <= 2'd0;
            grp_cur <= {GRP_W{1'b0}};
            bias_lat <= 32'sd0;
            w_addr <= {OC_W{1'b0}};
            b_addr <= {OC_W{1'b0}};
            out_pix_lat <= 10'd0;
            w_all_addr_reg <= {W_ADDR_W{1'b0}};
            ram_we_d1 <= 1'b0;
            pix_y_odd_d1 <= 1'b0;
            pix_x_d1 <= {X_W{1'b0}};
            
            win_load_en <= 1'b0;
            win_load_x  <= {X_W{1'b0}};

            for (i=0; i<GROUPS; i=i+1) gw_arr_d1[i] <= 104'd0;
            for (i=0; i<IC; i=i+1) pix_ch[i] <= 13'sd0;
            for (i=0; i<32; i=i+1) win_words[i] <= 104'd0;

            p1_valid <= 1'b0; p2_valid <= 1'b0; p3_valid <= 1'b0; p4_valid <= 1'b0;
            p5_valid <= 1'b0; p6_valid <= 1'b0; p7_valid <= 1'b0; p8_valid <= 1'b0;

            p1_first <= 1'b0; p2_first <= 1'b0; p3_first <= 1'b0; p4_first <= 1'b0; p5_first <= 1'b0; p6_first <= 1'b0;
            p1_last  <= 1'b0; p2_last  <= 1'b0; p3_last  <= 1'b0; p4_last  <= 1'b0; p5_last  <= 1'b0; p6_last  <= 1'b0; p7_last <= 1'b0; p8_last <= 1'b0;

            p1_oc <= {OC_W{1'b0}}; p2_oc <= {OC_W{1'b0}}; p3_oc <= {OC_W{1'b0}}; p4_oc <= {OC_W{1'b0}};
            p5_oc <= {OC_W{1'b0}}; p6_oc <= {OC_W{1'b0}}; p7_oc <= {OC_W{1'b0}}; p8_oc <= {OC_W{1'b0}};

            p1_x_word <= 104'd0;
            p1_w_word <= 128'd0;

            for (i=0; i<8; i=i+1) begin
                p2_x_lane[i] <= 13'sd0;
                p2_w_lane[i] <= 16'sd0;
                p3_mult[i]   <= 32'sd0;
            end

            p4_s0 <= 34'sd0; p4_s1 <= 34'sd0; p4_s2 <= 34'sd0; p4_s3 <= 34'sd0;
            p5_s0 <= 35'sd0; p5_s1 <= 35'sd0;
            p6_mac_sum <= 36'sd0;
            p7_acc <= 64'sd0;
            p8_out_data <= 13'd0;
        end else begin
            ram_we_d1 <= 1'b0;
            win_load_en <= 1'b0; // Default clear pulse

            // sideband pipeline
            p1_valid <= (state == S_MAC);
            p2_valid <= p1_valid;
            p3_valid <= p2_valid;
            p4_valid <= p3_valid;
            p5_valid <= p4_valid;
            p6_valid <= p5_valid;
            p7_valid <= p6_valid;
            p8_valid <= p7_valid && p7_last;

            p1_first <= (tap_cur == 2'd0) && (grp_cur == {GRP_W{1'b0}});
            p1_last  <= (tap_cur == 2'd3) && (grp_cur == GRP_MAX);
            p1_oc    <= oc_cur;

            p2_first <= p1_first; p2_last <= p1_last; p2_oc <= p1_oc;
            p3_first <= p2_first; p3_last <= p2_last; p3_oc <= p2_oc;
            p4_first <= p3_first; p4_last <= p3_last; p4_oc <= p3_oc;
            p5_first <= p4_first; p5_last <= p4_last; p5_oc <= p4_oc;
            p6_first <= p5_first; p6_last <= p5_last; p6_oc <= p5_oc;
            p7_last  <= p6_last;  p7_oc <= p6_oc;
            p8_last  <= p7_last;  p8_oc <= p7_oc;

            // p1: 抓宽字
            p1_x_word <= x_word;
            p1_w_word <= w_word;

            // p2: lane寄存
            p2_x_lane[0] <= $signed(p1_x_word[12:0]);
            p2_x_lane[1] <= $signed(p1_x_word[25:13]);
            p2_x_lane[2] <= $signed(p1_x_word[38:26]);
            p2_x_lane[3] <= $signed(p1_x_word[51:39]);
            p2_x_lane[4] <= $signed(p1_x_word[64:52]);
            p2_x_lane[5] <= $signed(p1_x_word[77:65]);
            p2_x_lane[6] <= $signed(p1_x_word[90:78]);
            p2_x_lane[7] <= $signed(p1_x_word[103:91]);

            p2_w_lane[0] <= $signed(p1_w_word[15:0]);
            p2_w_lane[1] <= $signed(p1_w_word[31:16]);
            p2_w_lane[2] <= $signed(p1_w_word[47:32]);
            p2_w_lane[3] <= $signed(p1_w_word[63:48]);
            p2_w_lane[4] <= $signed(p1_w_word[79:64]);
            p2_w_lane[5] <= $signed(p1_w_word[95:80]);
            p2_w_lane[6] <= $signed(p1_w_word[111:96]);
            p2_w_lane[7] <= $signed(p1_w_word[127:112]);

            // p3: 乘法
            p3_mult[0] <= p2_x_lane[0] * p2_w_lane[0];
            p3_mult[1] <= p2_x_lane[1] * p2_w_lane[1];
            p3_mult[2] <= p2_x_lane[2] * p2_w_lane[2];
            p3_mult[3] <= p2_x_lane[3] * p2_w_lane[3];
            p3_mult[4] <= p2_x_lane[4] * p2_w_lane[4];
            p3_mult[5] <= p2_x_lane[5] * p2_w_lane[5];
            p3_mult[6] <= p2_x_lane[6] * p2_w_lane[6];
            p3_mult[7] <= p2_x_lane[7] * p2_w_lane[7];

            // p4 / p5 / p6: 加法树
            p4_s0 <= p3_mult[0] + p3_mult[1];
            p4_s1 <= p3_mult[2] + p3_mult[3];
            p4_s2 <= p3_mult[4] + p3_mult[5];
            p4_s3 <= p3_mult[6] + p3_mult[7];

            p5_s0 <= p4_s0 + p4_s1;
            p5_s1 <= p4_s2 + p4_s3;

            p6_mac_sum <= p5_s0 + p5_s1;

            // p7: 累加 (已将原本在 P8 级发生的四舍五入大加法器剥离到这里吸收)
            if (p6_valid) begin
                if (p6_first)
                    p7_acc <= {{28{p6_mac_sum[35]}}, p6_mac_sum} + {{32{bias_lat[31]}}, bias_lat} + ROUND_OFFSET;
                else
                    p7_acc <= p7_acc + {{28{p6_mac_sum[35]}}, p6_mac_sum};
            end

            // p8: 输出截断 (去除了 64 位宽的加法)
            if (p7_valid && p7_last) begin
                p8_out_data <= shift_sat13(p7_acc); 
            end

            // Main FSM
            case (state)
                S_IDLE: begin
                    out_valid <= 1'b0;
                    if (in_fire && (in_och == {IC_W{1'b0}})) begin
                        pix_lat <= in_pix_idx;
                        pix_ch[0] <= $signed(in_data);
                        state <= S_COLLECT;
                    end
                end

                S_COLLECT: begin
                    out_valid <= 1'b0;
                    if (in_fire) begin
                        if (in_och < IC) pix_ch[in_och] <= $signed(in_data);

                        if (in_och == IC - 1) begin
                            ram_we_d1 <= 1'b1;
                            pix_y_odd_d1 <= pix_y_odd;
                            pix_x_d1 <= pix_x;

                            for (g=0; g<GROUPS; g=g+1)
                                gw_arr_d1[g] <= pack_word_comb[g*104 +: 104];

                            if (pix_y_odd && pix_x_odd) begin
                                out_pix_lat <= ((pix_y >> 1) * (W / 2)) + (pix_x >> 1);

                                // [修复]: 不直接读取 MUX 和加载寄存器，而是将加载任务委派给受控的延迟寄存器
                                win_load_en <= 1'b1;
                                win_load_x  <= pix_x;

                                oc_cur <= {OC_W{1'b0}};
                                tap_cur <= 2'd0;
                                grp_cur <= {GRP_W{1'b0}};
                                w_addr <= {OC_W{1'b0}};
                                b_addr <= {OC_W{1'b0}};
                                state <= S_WAIT;
                            end else begin
                                state <= S_IDLE;
                            end
                        end
                    end
                end

                S_WAIT: begin
                    out_valid <= 1'b0;
                    
                    // [修复] 执行被延迟的窗口加载
                    // 使用局部的、已经被限制扇出的独立寄存器 (win_load_en) 作为触发条件
                    // 彻底阻断上一级模块发送的 fifo_empty -> in_valid 信号造成的扇出灾难
                    if (win_load_en) begin
                        temp_even_m1 = row_even[win_load_x-1];
                        temp_even_p0 = row_even[win_load_x];
                        temp_odd_m1  = row_odd[win_load_x-1];

                        for (g=0; g<GROUPS; g=g+1) begin
                            win_words[0  + g] <= temp_even_m1[g*104 +: 104];
                            win_words[8  + g] <= temp_even_p0[g*104 +: 104];
                            win_words[16 + g] <= temp_odd_m1[g*104 +: 104];
                            win_words[24 + g] <= pack_gw_d1[g*104 +: 104];
                        end
                    end

                    if (b_addr_q == b_addr) begin
                        bias_lat <= b_dout;
                        tap_cur <= 2'd0;
                        grp_cur <= {GRP_W{1'b0}};
                        w_all_addr_reg <= {{(W_ADDR_W - OC_W){1'b0}}, w_addr};
                        state <= S_MAC;
                    end
                end

                S_MAC: begin
                    out_valid <= 1'b0;
                    if ((tap_cur == 2'd3) && (grp_cur == GRP_MAX)) begin
                        state <= S_MAC_DRAIN;
                    end else begin
                        w_all_addr_reg <= w_all_addr_reg + OC_STEP;
                        if (grp_cur == GRP_MAX) begin
                            grp_cur <= {GRP_W{1'b0}};
                            tap_cur <= tap_cur + 2'd1;
                        end else begin
                            grp_cur <= grp_cur + 1'b1;
                        end
                    end
                end

                S_MAC_DRAIN: begin
                    if (p8_valid && p8_last) begin
                        out_valid <= 1'b1;
                        out_och <= p8_oc;
                        out_pix_idx <= out_pix_lat;
                        out_data <= p8_out_data;

                        if (!last_oc) begin
                            w_addr <= oc_inc;
                            b_addr <= oc_inc;
                        end
                        state <= S_OUT;
                    end
                end

                S_OUT: begin
                    if (out_fire) begin
                        out_valid <= 1'b0;
                        if (last_oc) begin
                            state <= S_IDLE;
                        end else begin
                            oc_cur <= w_addr;
                            if (b_addr_q == b_addr) begin
                                bias_lat <= b_dout;
                                tap_cur <= 2'd0;
                                grp_cur <= {GRP_W{1'b0}};
                                w_all_addr_reg <= {{(W_ADDR_W - OC_W){1'b0}}, w_addr};
                                state <= S_MAC;
                            end else begin
                                state <= S_WAIT;
                            end
                        end
                    end else begin
                        out_valid <= 1'b1;
                    end
                end

                default: begin
                    state <= S_IDLE;
                    out_valid <= 1'b0;
                end
            endcase
        end
    end

endmodule