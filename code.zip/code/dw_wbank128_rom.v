`timescale 1ns/1ps
`default_nettype none

module dw_wbank128_rom(
    input  wire         clk,
    input  wire [6:0]   addr,
    output reg  [6:0]   addr_q,
    output reg  [511:0] dout
);
    localparam MEM = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/dw5x5_mem/stage1dw.mem";

    reg [511:0] mem [0:95];
    initial begin
       $readmemh(MEM, mem);
    end

    reg [511:0] data_pipe;
    reg [6:0]   addr_pipe;

    always @(posedge clk) begin
            data_pipe <= mem[addr];
            addr_pipe <= addr;
            dout   <= data_pipe;
            addr_q <= addr_pipe;
    end
endmodule

`default_nettype wire
`timescale 1ns/1ps
`default_nettype none

module dw_bias96_i32_rom (
    input  wire        clk,
    input  wire [6:0]  addr,
    output reg  [6:0]  addr_q,
    output reg  [31:0] dout
);
    localparam BIAS_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/dw5x5_mem/dw_b96_i32.mem";

    reg [31:0] mem [0:95];
    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0] data_pipe;
    reg [6:0]  addr_pipe;

    always @(posedge clk) begin
            data_pipe <= mem[addr];
            addr_pipe <= addr;
            dout   <= data_pipe;
            addr_q <= addr_pipe;
    end
endmodule

`default_nettype wire
