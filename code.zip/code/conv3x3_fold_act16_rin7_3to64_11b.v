`timescale 1ns/1ps
`default_nettype none

module conv3x3_fold_act16_rin7_3to64_11b (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_pulse,
    input  wire [23:0] in_data,
    output wire        in_ready,

    input  wire        out_ready,

    output reg         out_pulse,
    output reg  [5:0]  out_och,
    output reg  [11:0] out_pix_idx,
    output reg signed [10:0] out_data
);
    // ============================================================
    // Parameters / localparams
    // ============================================================
    localparam integer IN_W = 32;
    localparam integer IN_H = 32;

    localparam integer MAC_LAT   = 12;
    localparam integer SWEEP_END = 64 + MAC_LAT; // 76

    localparam [1:0] S_NEEDPIX = 2'd0;
    localparam [1:0] S_SWEEP   = 2'd1;
    localparam [1:0] S_DONE    = 2'd2;

    reg [1:0] state;
    // ============================================================
    // Coordinate generation over extended grid: x=0..32, y=0..32
    // ============================================================
    reg [5:0]  x_in;
    reg [5:0]  y_in;
    reg [10:0] real_cnt;

    // ============================================================
    // Line buffers
    // ============================================================
    reg [23:0] lb1 [0:IN_W-1];
    reg [23:0] lb2 [0:IN_W-1];

    // 3x3 window shift regs
    reg [23:0] top2, top1, top0;
    reg [23:0] mid2, mid1, mid0;
    reg [23:0] bot2, bot1, bot0;

    reg        pix_center_valid;
    reg [11:0] pix_cidx;

    reg        pend_valid;
    reg [11:0] pend_idx;
    // ============================================================
    // Center validity/index computed from current (x_in,y_in)
    // ============================================================
    wire center_valid_now = (x_in >= 6'd1) && (x_in <= 6'd32) &&
                            (y_in >= 6'd1) && (y_in <= 6'd32);
    wire [5:0]  cx_now   = x_in - 6'd1;
    wire [5:0]  cy_now   = y_in - 6'd1;
    wire [11:0] cidx_now = {cy_now, 5'b0} + {6'd0, cx_now}; // cy*32 + cx

    // ============================================================
    // Sweep control
    // ============================================================
    reg [7:0] sweep_cycle;
    
    // 优雅补丁：检测到反压时，让生成的地址退回上一拍 (sweep_cycle - 1)
    wire [7:0] target_sweep = stall_all ? (sweep_cycle - 8'd1) : sweep_cycle;
    wire [5:0] och_addr = 
        (state == S_SWEEP && target_sweep <= 8'd63) ? target_sweep[5:0] : 6'd0;

    wire [431:0] wpack;
    wire [5:0]   addr_of_w;
    // weight ROM: 1-cycle latency
    rom64x16_dist_dbg u_w(
        .clk    (clk),
        .addr   (och_addr),
        .addr_q (addr_of_w),
        .dout   (wpack)
    );
    // bias ROM: 1-cycle latency
    wire [5:0]          bias_addr_q;
    wire signed [31:0]  bias_w;

    bias64_i32_rom_dbg #(
        .MEM_FILE("E:/Desktop/ring2/save_to_FPGA/stem/fold_stemconv_mem/bias64_i32.mem")
    ) u_bias (
        .clk     (clk),
        .addr_in (och_addr),
        .addr_q  (bias_addr_q),
        .dout    (bias_w)
    );
    wire st0_v = (state == S_SWEEP) &&
                 (sweep_cycle >= 8'd1) && (sweep_cycle <= 8'd64) &&
                 (pix_center_valid);
    wire in_drain_prefetch = (state == S_SWEEP) &&
                             (sweep_cycle > 8'd64) &&
                             (sweep_cycle <= SWEEP_END[7:0]);
    wire accept_mode = (state == S_NEEDPIX) || (in_drain_prefetch && !pend_valid);
    wire need_ext = accept_mode &&
                    (x_in <= 6'd31) && (y_in <= 6'd31) &&
                    (real_cnt < 11'd1024);
    wire need_int = accept_mode &&
                    ( (y_in <= 6'd31 && x_in == 6'd32) || (y_in == 6'd32) );
    // ============================================================
    // 1-entry skid buffer: hold_* saves one pending output token
    // ============================================================
    reg        hold_v;
    reg [5:0]  hold_och;
    reg [11:0] hold_idx;
    reg signed [10:0] hold_data;
    // --------- Pipeline valids ----------
    reg st1_v, st2a_v, st2b_v, st3_v;
    reg st4a0_v, st4a_v, st4b0_v, st4_v;
    reg st5a_v;
    reg st5_v;
    reg pipe_valid;
    always @(posedge clk) begin
        if (!rst_n) begin
            pipe_valid <= 1'b0;
        end else if (!stall_all) begin
            // 记录下拍流水线里是否存在有效数据
            pipe_valid <= st0_v | st1_v | st2a_v | st2b_v | st3_v |
                          st4a0_v | st4a_v | st4b0_v | st4_v | st5a_v;
        end
    end
    // 优化：彻底消除 stall_all 的高扇出多级逻辑瓶颈。
    // 流水线只在 Skid Buffer（hold_v）被占满且下游无法接收数据（~out_ready）时才需要全局 Stall。
    (* max_fanout = 32 *) wire stall_all = (~out_ready) & (pipe_valid | hold_v);
    
    assign in_ready = need_ext & (~stall_all);
    assign in_ready = need_ext & (~stall_all);

    wire take_ext = need_ext && in_pulse && (~stall_all);
    wire take_int = need_int && (~stall_all);
    wire take_pix = take_ext || take_int;

    wire [23:0] pix_in = take_ext ? in_data : 24'd0;

    reg [5:0] x_next;
    reg [5:0] y_next;
    reg [7:0] sweep_cycle_next;
    always @* begin
        sweep_cycle_next = sweep_cycle;
        if (!stall_all) begin
            case (state)
                S_NEEDPIX: begin
                    if (take_pix && center_valid_now) begin
                        sweep_cycle_next = 8'd0; // entering sweep
                    end
                end
                S_SWEEP: begin
                    if (sweep_cycle == SWEEP_END[7:0]) begin
                        sweep_cycle_next = 8'd0;
                    end else begin
                        sweep_cycle_next = sweep_cycle + 8'd1;
                    end
                end
                default: begin
                    sweep_cycle_next = sweep_cycle;
                end
            endcase
        end
    end

    integer ii;
    // ============================================================
    // Helpers: channel extraction
    // ============================================================
    function [7:0] getR; input [23:0] p; begin getR = p[23:16]; end endfunction
    function [7:0] getG; input [23:0] p; begin getG = p[15:8];  end endfunction
    function [7:0] getB; input [23:0] p; begin getB = p[7:0];   end endfunction

    // ============================================================
    // Stage1 regs: latch wpack + 9 pixels + meta + bias
    // ============================================================
    reg [431:0] wpack_r1;
    reg [23:0]  p00_r1, p01_r1, p02_r1;
    reg [23:0]  p10_r1, p11_r1, p12_r1;
    reg [23:0]  p20_r1, p21_r1, p22_r1;
    reg [5:0]   st1_och;
    reg [11:0]  st1_idx;

    reg signed [31:0] b_r1, b_r2a, b_r2, b_r3;
    reg signed [31:0] b_r4a0, b_r4a, b_r4b0, b_r4;

    // ============================================================
    // Stage2A regs: per-mult operand regs
    // ============================================================
    reg signed [15:0] w_op_r2a [0:26];
    reg signed [8:0]  u_op_r2a [0:26];

    reg [5:0]  st2a_och, st2b_och, st3_och;
    reg [11:0] st2a_idx, st2b_idx, st3_idx;
    reg [5:0]  st4a0_och, st4a_och, st4b0_och, st4_och, st5_och, st5a_och;
    reg [11:0] st4a0_idx, st4a_idx, st4b0_idx, st4_idx, st5_idx, st5a_idx;
    // Stage2B regs: product regs
    (* use_dsp = "yes" *) reg signed [31:0] prod_r2 [0:26];
    // Stage3 regs: Optimized from 64-bit to 32-bit (Data is functionally ~27 bits max)
    reg signed [31:0] s1_r3 [0:8];
    // ============================================================
    // Stage4 split: A0/A1/B0/B1 (cut carry)
    // ============================================================
    // A0 regs
    reg [31:0] s4ab_lo_r4a0   [0:2];
    reg [31:0] s4ab_hi_a_r4a0 [0:2];
    reg [31:0] s4ab_hi_b_r4a0 [0:2];
    reg        s4ab_cy_r4a0   [0:2];
    reg signed [63:0] s4c_r4a0 [0:2];

    // A1 regs
    reg signed [63:0] s4ab_r4a [0:2];
    reg signed [63:0] s4c_r4a  [0:2];

    // B0 regs
    reg [31:0] s2_lo_r4b0   [0:2];
    reg [31:0] s2_hi_a_r4b0 [0:2];
    reg [31:0] s2_hi_b_r4b0 [0:2];
    reg        s2_cy_r4b0   [0:2];
    // B1 regs
    reg signed [63:0] s2_r4 [0:2];
    // Stage5 regs
    reg signed [63:0] s3_sum_r5;
    wire [31:0] s2_0_lo = s2_r4[0][31:0];
    wire [31:0] s2_1_lo = s2_r4[1][31:0];
    wire [31:0] s2_2_lo = s2_r4[2][31:0];

    wire [31:0] s2_0_hi = s2_r4[0][63:32];
    wire [31:0] s2_1_hi = s2_r4[1][63:32];
    wire [31:0] s2_2_hi = s2_r4[2][63:32];
    wire [31:0] bias_lo = b_r4[31:0];
    wire [31:0] bias_hi = {32{b_r4[31]}};
    // 4x32-bit unsigned sum -> 34-bit result (carry up to 2 bits)
    wire [33:0] s5_lo_sum = {2'b0, s2_0_lo} +
                            {2'b0, s2_1_lo} +
                            {2'b0, s2_2_lo} +
                            {2'b0, bias_lo};

    wire [1:0]  s5_lo_cy  = s5_lo_sum[33:32];
    wire [33:0] s5_hi_sum = {2'b0, s2_0_hi} +
                            {2'b0, s2_1_hi} +
                            {2'b0, s2_2_hi} +
                            {2'b0, bias_hi};
    wire [33:0] s5_hi_sum_c = s5_hi_sum + {32'd0, s5_lo_cy};

    wire signed [63:0] s5_sum64_split = {s5_hi_sum_c[31:0], s5_lo_sum[31:0]};

    integer j;
    // ============================================================
    // 独立且无复位的 lb1/lb2 写逻辑，诱导综合为 LUTRAM
    // 解决控制路径布线高延迟的核心
    // ============================================================
    always @(posedge clk) begin
        if (take_pix) begin
            if (x_in <= 6'd31 && y_in <= 6'd31) begin
                lb2[x_in] <= (y_in == 6'd0) ? 24'd0 : lb1[x_in];
                lb1[x_in] <= pix_in;
            end
        end
    end

    // ============================================================
    // Stage1: capture operands
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st1_v   <= 1'b0;
            st1_och <= 6'd0;
            st1_idx <= 12'd0;

            wpack_r1 <= 432'd0;

            p00_r1 <= 24'd0; p01_r1 <= 24'd0; p02_r1 <= 24'd0;
            p10_r1 <= 24'd0; p11_r1 <= 24'd0; p12_r1 <= 24'd0;
            p20_r1 <= 24'd0; p21_r1 <= 24'd0; p22_r1 <= 24'd0;
            b_r1 <= 32'sd0;
        end else if (!stall_all) begin
            st1_v   <= st0_v;
            st1_och <= addr_of_w;
            st1_idx <= pix_cidx;

            if (st0_v) begin
                wpack_r1 <= wpack;
                p00_r1 <= top2; p01_r1 <= top1; p02_r1 <= top0;
                p10_r1 <= mid2; p11_r1 <= mid1; p12_r1 <= mid0;
                p20_r1 <= bot2; p21_r1 <= bot1; p22_r1 <= bot0;

                b_r1 <= ((bias_addr_q == addr_of_w) ? bias_w : 32'sd0);
            end else begin
                wpack_r1 <= 432'd0;
                p00_r1 <= 24'd0; p01_r1 <= 24'd0; p02_r1 <= 24'd0;
                p10_r1 <= 24'd0; p11_r1 <= 24'd0; p12_r1 <= 24'd0;
                p20_r1 <= 24'd0; p21_r1 <= 24'd0; p22_r1 <= 24'd0;

                b_r1 <= 32'sd0;
            end
        end
    end

    wire signed [15:0] w26  = wpack_r1[0*16  +: 16];
    wire signed [15:0] w25  = wpack_r1[1*16  +: 16];
    wire signed [15:0] w24  = wpack_r1[2*16  +: 16];
    wire signed [15:0] w23  = wpack_r1[3*16  +: 16];
    wire signed [15:0] w22  = wpack_r1[4*16  +: 16];
    wire signed [15:0] w21  = wpack_r1[5*16  +: 16];
    wire signed [15:0] w20  = wpack_r1[6*16  +: 16];
    wire signed [15:0] w19  = wpack_r1[7*16  +: 16];
    wire signed [15:0] w18  = wpack_r1[8*16  +: 16];
    wire signed [15:0] w17  = wpack_r1[9*16  +: 16];
    wire signed [15:0] w16  = wpack_r1[10*16 +: 16];
    wire signed [15:0] w15  = wpack_r1[11*16 +: 16];
    wire signed [15:0] w14  = wpack_r1[12*16 +: 16];
    wire signed [15:0] w13  = wpack_r1[13*16 +: 16];
    wire signed [15:0] w12  = wpack_r1[14*16 +: 16];
    wire signed [15:0] w11  = wpack_r1[15*16 +: 16];
    wire signed [15:0] w10  = wpack_r1[16*16 +: 16];
    wire signed [15:0] w9   = wpack_r1[17*16 +: 16];
    wire signed [15:0] w8   = wpack_r1[18*16 +: 16];
    wire signed [15:0] w7   = wpack_r1[19*16 +: 16];
    wire signed [15:0] w6   = wpack_r1[20*16 +: 16];
    wire signed [15:0] w5   = wpack_r1[21*16 +: 16];
    wire signed [15:0] w4   = wpack_r1[22*16 +: 16];
    wire signed [15:0] w3   = wpack_r1[23*16 +: 16];
    wire signed [15:0] w2   = wpack_r1[24*16 +: 16];
    wire signed [15:0] w1   = wpack_r1[25*16 +: 16];
    wire signed [15:0] w0   = wpack_r1[26*16 +: 16];
    wire [7:0] p00r = getR(p00_r1), p01r = getR(p01_r1), p02r = getR(p02_r1);
    wire [7:0] p10r = getR(p10_r1), p11r = getR(p11_r1), p12r = getR(p12_r1);
    wire [7:0] p20r = getR(p20_r1), p21r = getR(p21_r1), p22r = getR(p22_r1);
    wire [7:0] p00g = getG(p00_r1), p01g = getG(p01_r1), p02g = getG(p02_r1);
    wire [7:0] p10g = getG(p10_r1), p11g = getG(p11_r1), p12g = getG(p12_r1);
    wire [7:0] p20g = getG(p20_r1), p21g = getG(p21_r1), p22g = getG(p22_r1);
    wire [7:0] p00b = getB(p00_r1), p01b = getB(p01_r1), p02b = getB(p02_r1);
    wire [7:0] p10b = getB(p10_r1), p11b = getB(p11_r1), p12b = getB(p12_r1);
    wire [7:0] p20b = getB(p20_r1), p21b = getB(p21_r1), p22b = getB(p22_r1);
    wire signed [8:0] u00r = {1'b0,p00r}, u01r = {1'b0,p01r}, u02r = {1'b0,p02r};
    wire signed [8:0] u10r = {1'b0,p10r}, u11r = {1'b0,p11r}, u12r = {1'b0,p12r};
    wire signed [8:0] u20r = {1'b0,p20r}, u21r = {1'b0,p21r}, u22r = {1'b0,p22r};
    wire signed [8:0] u00g = {1'b0,p00g}, u01g = {1'b0,p01g}, u02g = {1'b0,p02g};
    wire signed [8:0] u10g = {1'b0,p10g}, u11g = {1'b0,p11g}, u12g = {1'b0,p12g};
    wire signed [8:0] u20g = {1'b0,p20g}, u21g = {1'b0,p21g}, u22g = {1'b0,p22g};
    wire signed [8:0] u00b = {1'b0,p00b}, u01b = {1'b0,p01b}, u02b = {1'b0,p02b};
    wire signed [8:0] u10b = {1'b0,p10b}, u11b = {1'b0,p11b}, u12b = {1'b0,p12b};
    wire signed [8:0] u20b = {1'b0,p20b}, u21b = {1'b0,p21b}, u22b = {1'b0,p22b};
    // ============================================================
    // Stage2A: register per-mult operands
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st2a_v   <= 1'b0;
            st2a_och <= 6'd0;
            st2a_idx <= 12'd0;
            b_r2a    <= 32'sd0;
            for (j=0; j<27; j=j+1) begin
                w_op_r2a[j] <= 16'sd0;
                u_op_r2a[j] <= 9'sd0;
            end
        end else if (!stall_all) begin
            st2a_v   <= st1_v;
            st2a_och <= st1_och;
            st2a_idx <= st1_idx;
            b_r2a    <= b_r1;

            w_op_r2a[0]  <= w0;   u_op_r2a[0]  <= u00r;
            w_op_r2a[1]  <= w1;   u_op_r2a[1]  <= u01r;
            w_op_r2a[2]  <= w2;   u_op_r2a[2]  <= u02r;
            w_op_r2a[3]  <= w3;   u_op_r2a[3]  <= u10r;
            w_op_r2a[4]  <= w4;   u_op_r2a[4]  <= u11r;
            w_op_r2a[5]  <= w5;   u_op_r2a[5]  <= u12r;
            w_op_r2a[6]  <= w6;   u_op_r2a[6]  <= u20r;
            w_op_r2a[7]  <= w7;   u_op_r2a[7]  <= u21r;
            w_op_r2a[8]  <= w8;   u_op_r2a[8]  <= u22r;

            w_op_r2a[9]  <= w9;   u_op_r2a[9]  <= u00g;
            w_op_r2a[10] <= w10;  u_op_r2a[10] <= u01g;
            w_op_r2a[11] <= w11;  u_op_r2a[11] <= u02g;
            w_op_r2a[12] <= w12;  u_op_r2a[12] <= u10g;
            w_op_r2a[13] <= w13;  u_op_r2a[13] <= u11g;
            w_op_r2a[14] <= w14;  u_op_r2a[14] <= u12g;
            w_op_r2a[15] <= w15;  u_op_r2a[15] <= u20g;
            w_op_r2a[16] <= w16;  u_op_r2a[16] <= u21g;
            w_op_r2a[17] <= w17;  u_op_r2a[17] <= u22g;

            w_op_r2a[18] <= w18;  u_op_r2a[18] <= u00b;
            w_op_r2a[19] <= w19;  u_op_r2a[19] <= u01b;
            w_op_r2a[20] <= w20;  u_op_r2a[20] <= u02b;
            w_op_r2a[21] <= w21;  u_op_r2a[21] <= u10b;
            w_op_r2a[22] <= w22;  u_op_r2a[22] <= u11b;
            w_op_r2a[23] <= w23;  u_op_r2a[23] <= u12b;
            w_op_r2a[24] <= w24;  u_op_r2a[24] <= u20b;
            w_op_r2a[25] <= w25;  u_op_r2a[25] <= u21b;
            w_op_r2a[26] <= w26;  u_op_r2a[26] <= u22b;
        end
    end

    // ============================================================
    // Stage2B: multiply + register products (no mux clear)
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st2b_v   <= 1'b0;
            st2b_och <= 6'd0;
            st2b_idx <= 12'd0;
            b_r2     <= 32'sd0;
            for (j=0; j<27; j=j+1)
                prod_r2[j] <= 32'sd0;
        end else begin
            if (!stall_all) begin
                st2b_v   <= st2a_v;
                st2b_och <= st2a_och;
                st2b_idx <= st2a_idx;
                b_r2     <= b_r2a;
            end

            for (j=0; j<27; j=j+1) begin
                prod_r2[j] <= w_op_r2a[j] * u_op_r2a[j];
            end
        end
    end

    // ============================================================
    // Stage3: 9 groups of 3-term sums
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st3_v <= 1'b0;
            st3_och <= 6'd0; st3_idx <= 12'd0;
            b_r3 <= 32'sd0;
            for (j=0;j<9;j=j+1) s1_r3[j] <= 32'sd0;
        end else if (!stall_all) begin
            st3_v   <= st2b_v;
            st3_och <= st2b_och;
            st3_idx <= st2b_idx;

            b_r3 <= st2b_v ? b_r2 : 32'sd0;
            if (st2b_v) begin
                s1_r3[0] <= prod_r2[0]  + prod_r2[1]  + prod_r2[2];
                s1_r3[1] <= prod_r2[3]  + prod_r2[4]  + prod_r2[5];
                s1_r3[2] <= prod_r2[6]  + prod_r2[7]  + prod_r2[8];
                s1_r3[3] <= prod_r2[9]  + prod_r2[10] + prod_r2[11];
                s1_r3[4] <= prod_r2[12] + prod_r2[13] + prod_r2[14];
                s1_r3[5] <= prod_r2[15] + prod_r2[16] + prod_r2[17];
                s1_r3[6] <= prod_r2[18] + prod_r2[19] + prod_r2[20];
                s1_r3[7] <= prod_r2[21] + prod_r2[22] + prod_r2[23];
                s1_r3[8] <= prod_r2[24] + prod_r2[25] + prod_r2[26];
            end else begin
                for (j=0;j<9;j=j+1) s1_r3[j] <= 32'sd0;
            end
        end
    end

    // ============================================================
    // Stage4A0: compute low32 + carry of (a+b), and latch high parts + c
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st4a0_v   <= 1'b0;
            st4a0_och <= 6'd0;
            st4a0_idx <= 12'd0;
            b_r4a0    <= 32'sd0;
            for (j=0;j<3;j=j+1) begin
                s4ab_lo_r4a0[j]   <= 32'd0;
                s4ab_hi_a_r4a0[j] <= 32'd0;
                s4ab_hi_b_r4a0[j] <= 32'd0;
                s4ab_cy_r4a0[j]   <= 1'b0;
                s4c_r4a0[j]       <= 64'sd0;
            end
        end else if (!stall_all) begin
            st4a0_v   <= st3_v;
            st4a0_och <= st3_och;
            st4a0_idx <= st3_idx;
            b_r4a0    <= b_r3;

            {s4ab_cy_r4a0[0], s4ab_lo_r4a0[0]} <= {1'b0, s1_r3[0]} + {1'b0, s1_r3[1]};
            s4ab_hi_a_r4a0[0] <= {32{s1_r3[0][31]}};
            s4ab_hi_b_r4a0[0] <= {32{s1_r3[1][31]}};
            s4c_r4a0[0]       <= {{32{s1_r3[2][31]}}, s1_r3[2]};
            {s4ab_cy_r4a0[1], s4ab_lo_r4a0[1]} <= {1'b0, s1_r3[3]} + {1'b0, s1_r3[4]};
            s4ab_hi_a_r4a0[1] <= {32{s1_r3[3][31]}};
            s4ab_hi_b_r4a0[1] <= {32{s1_r3[4][31]}};
            s4c_r4a0[1]       <= {{32{s1_r3[5][31]}}, s1_r3[5]};

            {s4ab_cy_r4a0[2], s4ab_lo_r4a0[2]} <= {1'b0, s1_r3[6]} + {1'b0, s1_r3[7]};
            s4ab_hi_a_r4a0[2] <= {32{s1_r3[6][31]}};
            s4ab_hi_b_r4a0[2] <= {32{s1_r3[7][31]}};
            s4c_r4a0[2]       <= {{32{s1_r3[8][31]}}, s1_r3[8]};
        end
    end

    wire [31:0] s4ab_hi_sum0 = s4ab_hi_a_r4a0[0] + s4ab_hi_b_r4a0[0] + {31'd0, s4ab_cy_r4a0[0]};
    wire [31:0] s4ab_hi_sum1 = s4ab_hi_a_r4a0[1] + s4ab_hi_b_r4a0[1] + {31'd0, s4ab_cy_r4a0[1]};
    wire [31:0] s4ab_hi_sum2 = s4ab_hi_a_r4a0[2] + s4ab_hi_b_r4a0[2] + {31'd0, s4ab_cy_r4a0[2]};
    // ============================================================
    // Stage4A1: compute high32(+carry_in) and re-pack 64-bit s4ab, pass c
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st4a_v   <= 1'b0;
            st4a_och <= 6'd0;
            st4a_idx <= 12'd0;
            b_r4a    <= 32'sd0;
            for (j=0;j<3;j=j+1) begin
                s4ab_r4a[j] <= 64'sd0;
                s4c_r4a[j]  <= 64'sd0;
            end
        end else if (!stall_all) begin
            st4a_v   <= st4a0_v;
            st4a_och <= st4a0_och;
            st4a_idx <= st4a0_idx;
            b_r4a    <= b_r4a0;

            s4ab_r4a[0] <= {s4ab_hi_sum0, s4ab_lo_r4a0[0]};
            s4ab_r4a[1] <= {s4ab_hi_sum1, s4ab_lo_r4a0[1]};
            s4ab_r4a[2] <= {s4ab_hi_sum2, s4ab_lo_r4a0[2]};

            s4c_r4a[0]  <= s4c_r4a0[0];
            s4c_r4a[1]  <= s4c_r4a0[1];
            s4c_r4a[2]  <= s4c_r4a0[2];
        end
    end

    // ============================================================
    // Stage4B0: compute low32 + carry of (s4ab + s4c), latch high parts
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st4b0_v   <= 1'b0;
            st4b0_och <= 6'd0;
            st4b0_idx <= 12'd0;
            b_r4b0    <= 32'sd0;
            for (j=0;j<3;j=j+1) begin
                s2_lo_r4b0[j]   <= 32'd0;
                s2_hi_a_r4b0[j] <= 32'd0;
                s2_hi_b_r4b0[j] <= 32'd0;
                s2_cy_r4b0[j]   <= 1'b0;
            end
        end else if (!stall_all) begin
            st4b0_v   <= st4a_v;
            st4b0_och <= st4a_och;
            st4b0_idx <= st4a_idx;
            b_r4b0    <= b_r4a;
            for (j=0;j<3;j=j+1) begin
                {s2_cy_r4b0[j], s2_lo_r4b0[j]} <= {1'b0, s4ab_r4a[j][31:0]} + {1'b0, s4c_r4a[j][31:0]};
                s2_hi_a_r4b0[j] <= s4ab_r4a[j][63:32];
                s2_hi_b_r4b0[j] <= s4c_r4a[j][63:32];
            end
        end
    end

    wire [31:0] s2_hi_sum0 = s2_hi_a_r4b0[0] + s2_hi_b_r4b0[0] + {31'd0, s2_cy_r4b0[0]};
    wire [31:0] s2_hi_sum1 = s2_hi_a_r4b0[1] + s2_hi_b_r4b0[1] + {31'd0, s2_cy_r4b0[1]};
    wire [31:0] s2_hi_sum2 = s2_hi_a_r4b0[2] + s2_hi_b_r4b0[2] + {31'd0, s2_cy_r4b0[2]};
    // ============================================================
    // Stage4B1: compute high32(+carry_in) and re-pack 64-bit s2_r4
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st4_v   <= 1'b0;
            st4_och <= 6'd0;
            st4_idx <= 12'd0;
            b_r4    <= 32'sd0;
            for (j=0;j<3;j=j+1) begin
                s2_r4[j] <= 64'sd0;
            end
        end else if (!stall_all) begin
            st4_v   <= st4b0_v;
            st4_och <= st4b0_och;
            st4_idx <= st4b0_idx;
            b_r4    <= b_r4b0;

            s2_r4[0] <= {s2_hi_sum0, s2_lo_r4b0[0]};
            s2_r4[1] <= {s2_hi_sum1, s2_lo_r4b0[1]};
            s2_r4[2] <= {s2_hi_sum2, s2_lo_r4b0[2]};
        end
    end

    // ============================================================
    // Stage5A: register low32 + carry and high-base sum
    // cut the low-carry -> high-sum combinational dependency
    // ============================================================
    reg [31:0] s5_lo32_r5a;
    reg [1:0]  s5_lo_cy_r5a;
    reg [33:0] s5_hi_base_r5a;

    always @(posedge clk) begin
        if (!rst_n) begin
            st5a_v   <= 1'b0;
            st5a_och <= 6'd0;
            st5a_idx <= 12'd0;

            s5_lo32_r5a    <= 32'd0;
            s5_lo_cy_r5a   <= 2'd0;
            s5_hi_base_r5a <= 34'd0;
        end else if (!stall_all) begin
            st5a_v   <= st4_v;
            st5a_och <= st4_och;
            st5a_idx <= st4_idx;

            if (st4_v) begin
                s5_lo32_r5a    <= s5_lo_sum[31:0];
                s5_lo_cy_r5a   <= s5_lo_sum[33:32];
                s5_hi_base_r5a <= s5_hi_sum; // note: no +carry here
            end
        end
    end

    wire [33:0] s5_hi_sum_c_pipe = s5_hi_base_r5a + {32'd0, s5_lo_cy_r5a};
    wire signed [63:0] s5_sum64_pipe = {s5_hi_sum_c_pipe[31:0], s5_lo32_r5a};

    // ============================================================
    // Stage5B: final 64-bit sum register (1-cycle later than before)
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            st5_v   <= 1'b0;
            st5_och <= 6'd0;
            st5_idx <= 12'd0;
            s3_sum_r5 <= 64'sd0;
        end else if (!stall_all) begin
            st5_v   <= st5a_v;
            st5_och <= st5a_och;
            st5_idx <= st5a_idx;

            if (st5a_v) begin
                s3_sum_r5 <= s5_sum64_pipe;
            end
        end
    end

    // ReLU + rounding >>7
    wire [63:0] relu_u = s3_sum_r5[63] ? 64'd0 : s3_sum_r5[63:0];
    wire [63:0] sh_u   = (relu_u + 64'd64) >> 7;
    wire signed [10:0] sat11_u = sh_u[10:0];
    // ============================================================
    // State machine + HOLD push/pop (移除了 lb1/lb2 的内联写入)
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            state    <= S_NEEDPIX;
            x_in     <= 6'd0;
            y_in     <= 6'd0;
            real_cnt <= 11'd0;

            top2 <= 24'd0; top1 <= 24'd0; top0 <= 24'd0;
            mid2 <= 24'd0; mid1 <= 24'd0; mid0 <= 24'd0;
            bot2 <= 24'd0; bot1 <= 24'd0; bot0 <= 24'd0;

            pix_center_valid <= 1'b0;
            pix_cidx         <= 12'd0;
            pend_valid       <= 1'b0;
            pend_idx         <= 12'd0;
            sweep_cycle <= 8'd0;

            hold_v    <= 1'b0;
            hold_och  <= 6'd0;
            hold_idx  <= 12'd0;
            hold_data <= 11'sd0;
            out_pulse   <= 1'b0;
            out_och     <= 6'd0;
            out_pix_idx <= 12'd0;
            out_data    <= 11'sd0;
        end else begin
            out_pulse <= 1'b0;
            sweep_cycle <= sweep_cycle_next;
            if (hold_v) begin
                out_och     <= hold_och;
                out_pix_idx <= hold_idx;
                out_data    <= hold_data;
            end

            if (hold_v) begin
                if (out_ready) begin
                    out_pulse <= 1'b1;
                    if (st5_v) begin
                        hold_v    <= 1'b1;
                        hold_och  <= st5_och;
                        hold_idx  <= st5_idx;
                        hold_data <= sat11_u;
                    end else begin
                        hold_v <= 1'b0;
                    end
                end
            end else begin
                if (st5_v) begin
                    if (out_ready) begin
                        out_pulse   <= 1'b1;
                        out_och     <= st5_och;
                        out_pix_idx <= st5_idx;
                        out_data    <= sat11_u;
                        hold_v      <= 1'b0;
                    end else begin
                        hold_v    <= 1'b1;
                        hold_och  <= st5_och;
                        hold_idx  <= st5_idx;
                        hold_data <= sat11_u;
                    end
                end
            end

            if (!stall_all) begin
                case (state)
                    S_NEEDPIX: begin
                        if (take_pix) begin
                            if (x_in == 6'd0) begin
                                top2 <= 24'd0; top1 <= 24'd0;
                                top0 <= (x_in <= 6'd31) ? ((y_in <= 6'd1) ? 24'd0 : lb2[x_in]) : 24'd0;
                                mid2 <= 24'd0; mid1 <= 24'd0;
                                mid0 <= (x_in <= 6'd31) ? ((y_in == 6'd0) ? 24'd0 : lb1[x_in]) : 24'd0;
                                bot2 <= 24'd0; bot1 <= 24'd0; bot0 <= pix_in;
                            end else begin
                                top2 <= top1; top1 <= top0;
                                top0 <= (x_in <= 6'd31) ? ((y_in <= 6'd1) ? 24'd0 : lb2[x_in]) : 24'd0;
                                mid2 <= mid1; mid1 <= mid0;
                                mid0 <= (x_in <= 6'd31) ? ((y_in == 6'd0) ? 24'd0 : lb1[x_in]) : 24'd0;
                                bot2 <= bot1; bot1 <= bot0; bot0 <= pix_in;
                            end

                            if (take_ext) begin
                                if (real_cnt < 11'd1024)
                                    real_cnt <= real_cnt + 11'd1;
                            end

                            pix_center_valid <= center_valid_now;
                            pix_cidx         <= cidx_now;
                            if (x_in == 6'd32) begin
                                x_next = 6'd0;
                                y_next = y_in + 6'd1;
                            end else begin
                                x_next = x_in + 6'd1;
                                y_next = y_in;
                            end
                            x_in <= x_next;
                            y_in <= y_next;

                            if (center_valid_now) begin
                                state <= S_SWEEP;
                            end
                        end
                    end

                    S_SWEEP: begin
                        if (take_pix) begin
                            if (x_in == 6'd0) begin
                                top2 <= 24'd0; top1 <= 24'd0;
                                top0 <= (x_in <= 6'd31) ? ((y_in <= 6'd1) ? 24'd0 : lb2[x_in]) : 24'd0;
                                mid2 <= 24'd0; mid1 <= 24'd0;
                                mid0 <= (x_in <= 6'd31) ? ((y_in == 6'd0) ? 24'd0 : lb1[x_in]) : 24'd0;
                                bot2 <= 24'd0; bot1 <= 24'd0; bot0 <= pix_in;
                            end else begin
                                top2 <= top1; top1 <= top0;
                                top0 <= (x_in <= 6'd31) ? ((y_in <= 6'd1) ? 24'd0 : lb2[x_in]) : 24'd0;
                                mid2 <= mid1; mid1 <= mid0;
                                mid0 <= (x_in <= 6'd31) ? ((y_in == 6'd0) ? 24'd0 : lb1[x_in]) : 24'd0;
                                bot2 <= bot1; bot1 <= bot0; bot0 <= pix_in;
                            end

                            if (take_ext) begin
                                if (real_cnt < 11'd1024)
                                    real_cnt <= real_cnt + 11'd1;
                            end

                            if (x_in == 6'd32) begin
                                x_next = 6'd0;
                                y_next = y_in + 6'd1;
                            end else begin
                                x_next = x_in + 6'd1;
                                y_next = y_in;
                            end
                            x_in <= x_next;
                            y_in <= y_next;

                            if (in_drain_prefetch && !pend_valid && center_valid_now) begin
                                pend_valid <= 1'b1;
                                pend_idx   <= cidx_now;
                            end
                        end

                        if (sweep_cycle == SWEEP_END[7:0]) begin
                            if (pend_valid) begin
                                pix_center_valid <= 1'b1;
                                pix_cidx         <= pend_idx;
                                pend_valid       <= 1'b0;
                                state            <= S_SWEEP;
                            end else begin
                                if ((real_cnt == 11'd1024) && (y_in == 6'd33)) begin
                                    state <= S_DONE;
                                end else begin
                                    state <= S_NEEDPIX;
                                end
                            end
                        end
                    end

                    S_DONE: begin
                        state <= S_DONE;
                    end

                    default: begin
                        state <= S_NEEDPIX;
                    end
                endcase
            end
        end
    end

endmodule

`default_nettype wire