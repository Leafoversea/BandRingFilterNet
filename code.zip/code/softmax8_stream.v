`timescale 1ns / 1ps

module softmax8_stream (
    input  wire                clk,
    input  wire                rst_n,

    // 输入接口 (保持串行输入兼容)
    input  wire                s_valid,
    input  wire [0:0]          s_pix_idx, // 保留以兼容外围控制逻辑
    input  wire [2:0]          s_och,
    input  wire signed [31:0]  s_data,
    input  wire                s_last,

    // 输出接口 (直接输出独热码给 LED)
    output reg                 m_valid,
    output reg  [7:0]          led_out    // 8位对应8个通道的最高分指示
);

    // 内部寄存器：用于在串行输入时实时保存当前的“擂主”（最大值及其索引）
    reg signed [31:0] running_max;
    reg [2:0]         running_max_idx;

    // 组合逻辑：提取当前周期的比较结果
    wire signed [31:0] next_max;
    wire [2:0]         next_max_idx;

    // 核心平衡点：复用比较逻辑。
    // 如果是通道0，直接作为初始擂主；否则，将当前输入与已有擂主进行比较。
    assign next_max     = (s_och == 3'd0) ? s_data : ((s_data > running_max) ? s_data : running_max);
    assign next_max_idx = (s_och == 3'd0) ? s_och  : ((s_data > running_max) ? s_och  : running_max_idx);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            running_max     <= 32'sd0;
            running_max_idx <= 3'd0;
            m_valid         <= 1'b0;
            led_out         <= 8'd0;
        end else begin
            // 默认拉低 valid 脉冲
            m_valid <= 1'b0; 

            if (s_valid) begin
                // 每一个有效数据到来，都实时更新当前的擂主寄存器
                running_max     <= next_max;
                running_max_idx <= next_max_idx;

                // 当接收到本轮最后一个通道的数据时，直接输出独热码 (One-Hot)
                if (s_och == 3'd7 || s_last) begin
                    m_valid <= 1'b1;
                    led_out <= 8'd1 << next_max_idx; // 移位生成独热码点亮对应 LED
                end
            end
        end
    end

endmodule