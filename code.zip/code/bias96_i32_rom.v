module bias96_i32_rom (
    input  wire        clk,
    input  wire [6:0]  addr,
    output reg  [6:0]  addr_q,
    output reg  [31:0] dout
);
    localparam BIAS_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/expand_mem/bias96_i32.mem";
    reg [31:0] mem [0:95];

    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0] data_pipe;
    reg [6:0]  addr_pipe;

    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule

module pw_gbank96x16_to128_rom (
    input  wire         clk,
    input  wire [6:0]   addr,
    output reg  [6:0]   addr_q,
    output reg  [511:0] dout
);
    localparam MEM = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/expand_mem/stege1exp.mem";
    reg [511:0] mem [0:95];
    initial begin
         $readmemh(MEM, mem);
    end
    reg [511:0] data_pipe;
    reg [6:0]   addr_pipe ;
    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule
