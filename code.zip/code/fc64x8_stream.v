`timescale 1ns / 1ps

module fc64x8_stream #(
    parameter PATH = "E:/Desktop/ring2/save_to_FPGA/head/fc_mem"
)(
    input  wire                    clk,
    input  wire                    rst_n,

    // 与 gap8x8_stream 输出兼容
    input  wire                    s_valid,
    output wire                    s_ready,
    input  wire [0:0]              s_pix_idx,   // GAP后固定为0，仅保留接口兼容
    input  wire [5:0]              s_och,       // 输入特征通道 0..63
    input  wire signed [15:0]      s_data,      // GAP输出 int16
    input  wire                    s_last,      // 第63个通道时拉高

    // 输出8个类别的logit
    output reg                     m_valid,
    input  wire                    m_ready,
    output reg  [0:0]              m_pix_idx,   // 固定为0
    output reg  [2:0]              m_och,       // 类别号 0..7
    output reg  signed [31:0]      m_data,      // logit int32
    output reg                     m_last
);

    localparam integer SHIFT_OUT = 15;

    localparam [1:0]
        ST_RECV = 2'd0,
        ST_OUT  = 2'd1;

    reg [1:0] state;
    reg [2:0] out_cls_idx;

    reg [127:0] wbank00 [0:7];
    reg [127:0] wbank01 [0:7];
    reg [127:0] wbank02 [0:7];
    reg [127:0] wbank03 [0:7];
    reg [127:0] wbank04 [0:7];
    reg [127:0] wbank05 [0:7];
    reg [127:0] wbank06 [0:7];
    reg [127:0] wbank07 [0:7];

    reg signed [31:0] bias_mem [0:7];
    reg signed [39:0] acc [0:7];

    integer i;

    initial begin
        $readmemh({PATH,"/wbank00.mem"}, wbank00);
        $readmemh({PATH,"/wbank01.mem"}, wbank01);
        $readmemh({PATH,"/wbank02.mem"}, wbank02);
        $readmemh({PATH,"/wbank03.mem"}, wbank03);
        $readmemh({PATH,"/wbank04.mem"}, wbank04);
        $readmemh({PATH,"/wbank05.mem"}, wbank05);
        $readmemh({PATH,"/wbank06.mem"}, wbank06);
        $readmemh({PATH,"/wbank07.mem"}, wbank07);
        $readmemh({PATH,"/bias08_i32.mem"}, bias_mem);
    end

    wire signed [39:0] bias_rnd [0:7];
    genvar g;
    generate
        for (g = 0; g < 8; g = g + 1) begin : gen_bias_rnd
            assign bias_rnd[g] = {{8{bias_mem[g][31]}}, bias_mem[g]} + (40'sd1 <<< (SHIFT_OUT - 1));
        end
    endgenerate

    reg pipe_busy;
    reg s_valid_pipe;
    reg [5:0] s_och_pipe;
    reg s_last_pipe;
    
    // [核心优化]: 将 6-bit 比较逻辑前移，化解 DSP 控制端口的建立时间违例
    reg is_first_och_pipe;

    reg signed [31:0] p_reg [0:7];

    assign s_ready = (state == ST_RECV) && !pipe_busy;

    wire [2:0] bank_idx = s_och[5:3];
    wire [2:0] lane_idx = s_och[2:0];

    reg signed [15:0] w0, w1, w2, w3, w4, w5, w6, w7;
    reg [127:0] line0, line1, line2, line3, line4, line5, line6, line7;

    always @(*) begin
        case (bank_idx)
            3'd0: begin
                line0 = wbank00[0]; line1 = wbank00[1]; line2 = wbank00[2]; line3 = wbank00[3];
                line4 = wbank00[4]; line5 = wbank00[5]; line6 = wbank00[6]; line7 = wbank00[7];
            end
            3'd1: begin
                line0 = wbank01[0]; line1 = wbank01[1]; line2 = wbank01[2]; line3 = wbank01[3];
                line4 = wbank01[4]; line5 = wbank01[5]; line6 = wbank01[6]; line7 = wbank01[7];
            end
            3'd2: begin
                line0 = wbank02[0]; line1 = wbank02[1]; line2 = wbank02[2]; line3 = wbank02[3];
                line4 = wbank02[4]; line5 = wbank02[5]; line6 = wbank02[6]; line7 = wbank02[7];
            end
            3'd3: begin
                line0 = wbank03[0]; line1 = wbank03[1]; line2 = wbank03[2]; line3 = wbank03[3];
                line4 = wbank03[4]; line5 = wbank03[5]; line6 = wbank03[6]; line7 = wbank03[7];
            end
            3'd4: begin
                line0 = wbank04[0]; line1 = wbank04[1]; line2 = wbank04[2]; line3 = wbank04[3];
                line4 = wbank04[4]; line5 = wbank04[5]; line6 = wbank04[6]; line7 = wbank04[7];
            end
            3'd5: begin
                line0 = wbank05[0]; line1 = wbank05[1]; line2 = wbank05[2]; line3 = wbank05[3];
                line4 = wbank05[4]; line5 = wbank05[5]; line6 = wbank05[6]; line7 = wbank05[7];
            end
            3'd6: begin
                line0 = wbank06[0]; line1 = wbank06[1]; line2 = wbank06[2]; line3 = wbank06[3];
                line4 = wbank06[4]; line5 = wbank06[5]; line6 = wbank06[6]; line7 = wbank06[7];
            end
            default: begin
                line0 = wbank07[0]; line1 = wbank07[1]; line2 = wbank07[2]; line3 = wbank07[3];
                line4 = wbank07[4]; line5 = wbank07[5]; line6 = wbank07[6]; line7 = wbank07[7];
            end
        endcase

        w0 = line0[lane_idx*16 +: 16];
        w1 = line1[lane_idx*16 +: 16];
        w2 = line2[lane_idx*16 +: 16];
        w3 = line3[lane_idx*16 +: 16];
        w4 = line4[lane_idx*16 +: 16];
        w5 = line5[lane_idx*16 +: 16];
        w6 = line6[lane_idx*16 +: 16];
        w7 = line7[lane_idx*16 +: 16];
    end

    wire signed [31:0] out_data_w [0:7];
    generate
        for (g = 0; g < 8; g = g + 1) begin : gen_out
            assign out_data_w[g] = {{7{acc[g][39]}}, acc[g][39:15]};
        end
    endgenerate

    always @(posedge clk) begin
        if (!rst_n) begin
            state       <= ST_RECV;
            out_cls_idx <= 3'd0;

            m_valid     <= 1'b0;
            m_pix_idx   <= 1'b0;
            m_och       <= 3'd0;
            m_data      <= 32'sd0;
            m_last      <= 1'b0;

            pipe_busy         <= 1'b0;
            s_valid_pipe      <= 1'b0;
            s_och_pipe        <= 6'd0;
            s_last_pipe       <= 1'b0;
            is_first_och_pipe <= 1'b0;

            for (i = 0; i < 8; i = i + 1) begin
                acc[i]   <= 40'sd0;
                p_reg[i] <= 32'sd0;
            end
        end else begin
            
            if (s_valid && s_ready && s_last)
                pipe_busy <= 1'b1;
            else if (state == ST_OUT && m_valid && m_ready && m_last)
                pipe_busy <= 1'b0;

            if (s_ready) begin
                s_valid_pipe      <= s_valid;
                s_och_pipe        <= s_och;
                s_last_pipe       <= s_last;
                // 第一拍直接存好布尔判定
                is_first_och_pipe <= (s_och == 6'd0); 
            end else begin
                s_valid_pipe      <= 1'b0;
            end

            if (s_valid && s_ready) begin
                p_reg[0] <= $signed(s_data) * $signed(w0);
                p_reg[1] <= $signed(s_data) * $signed(w1);
                p_reg[2] <= $signed(s_data) * $signed(w2);
                p_reg[3] <= $signed(s_data) * $signed(w3);
                p_reg[4] <= $signed(s_data) * $signed(w4);
                p_reg[5] <= $signed(s_data) * $signed(w5);
                p_reg[6] <= $signed(s_data) * $signed(w6);
                p_reg[7] <= $signed(s_data) * $signed(w7);
            end

            case (state)
                ST_RECV: begin
                    m_valid <= 1'b0;
                    m_last  <= 1'b0;

                    if (s_valid_pipe) begin
                        // 替换原有的 (s_och_pipe == 6'd0)，极速切换DSP内部工作模式
                        if (is_first_och_pipe) begin 
                            acc[0] <= bias_rnd[0] + {{8{p_reg[0][31]}}, p_reg[0]};
                            acc[1] <= bias_rnd[1] + {{8{p_reg[1][31]}}, p_reg[1]};
                            acc[2] <= bias_rnd[2] + {{8{p_reg[2][31]}}, p_reg[2]};
                            acc[3] <= bias_rnd[3] + {{8{p_reg[3][31]}}, p_reg[3]};
                            acc[4] <= bias_rnd[4] + {{8{p_reg[4][31]}}, p_reg[4]};
                            acc[5] <= bias_rnd[5] + {{8{p_reg[5][31]}}, p_reg[5]};
                            acc[6] <= bias_rnd[6] + {{8{p_reg[6][31]}}, p_reg[6]};
                            acc[7] <= bias_rnd[7] + {{8{p_reg[7][31]}}, p_reg[7]};
                        end else begin
                            acc[0] <= acc[0] + {{8{p_reg[0][31]}}, p_reg[0]};
                            acc[1] <= acc[1] + {{8{p_reg[1][31]}}, p_reg[1]};
                            acc[2] <= acc[2] + {{8{p_reg[2][31]}}, p_reg[2]};
                            acc[3] <= acc[3] + {{8{p_reg[3][31]}}, p_reg[3]};
                            acc[4] <= acc[4] + {{8{p_reg[4][31]}}, p_reg[4]};
                            acc[5] <= acc[5] + {{8{p_reg[5][31]}}, p_reg[5]};
                            acc[6] <= acc[6] + {{8{p_reg[6][31]}}, p_reg[6]};
                            acc[7] <= acc[7] + {{8{p_reg[7][31]}}, p_reg[7]};
                        end

                        if (s_last_pipe) begin
                            out_cls_idx <= 3'd0;
                            state       <= ST_OUT;
                        end
                    end
                end

                ST_OUT: begin
                    if (!m_valid || (m_valid && m_ready)) begin
                        m_valid   <= 1'b1;
                        m_pix_idx <= 1'b0;
                        m_och     <= out_cls_idx;
                        m_last    <= (out_cls_idx == 3'd7);
                        m_data    <= out_data_w[out_cls_idx];

                        if (out_cls_idx == 3'd7) begin
                            out_cls_idx <= 3'd0;
                            state       <= ST_RECV;
                        end else begin
                            out_cls_idx <= out_cls_idx + 3'd1;
                        end
                    end
                end

                default: state <= ST_RECV;
            endcase
        end
    end

endmodule