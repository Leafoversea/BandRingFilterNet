module GF_top (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        s_valid,
    output wire        s_ready,
    input  wire [9:0]  s_pix_idx,
    input  wire [5:0]  s_och,
    input  wire signed [12:0] s_data,
    input  wire        s_last,

    output wire        m_valid,
    input  wire        m_ready,
    output wire [9:0]  m_pix_idx,
    output wire [5:0]  m_och,
    output wire signed [12:0] m_data,
    output wire        m_last
);

    // ============================================================
    // 旁路残差 FIFO (使用 LUTRAM 节省 BRAM，包含复位忙碌修复)
    // ============================================================
    wire        res_full;
    wire        res_empty;
    wire signed [12:0] res_dout;
    wire        res_push;
    wire        res_pop;
    wire        res_wr_busy; 
    wire        res_rd_busy; 

    // 强制使用分布式 RAM (LUTRAM) 深度设为 8192，完全覆盖 DW 的延迟
    xpm_fifo_sync #(
        .FIFO_MEMORY_TYPE("distributed"), 
        .FIFO_READ_LATENCY(0),            // FWFT 模式
        .FIFO_WRITE_DEPTH(4096),          
        .READ_DATA_WIDTH(13),
        .WRITE_DATA_WIDTH(13),
        .READ_MODE("fwft"),
        .USE_ADV_FEATURES("0000")
    ) u_res_fifo (
        .rst        (~rst_n),
        .wr_clk     (clk),
        .wr_en      (res_push),
        .din        (s_data),
        .full       (res_full),
        .rd_en      (res_pop),
        .dout       (res_dout),
        .empty      (res_empty),
        .wr_rst_busy(res_wr_busy),  // 捕获写忙状态
        .rd_rst_busy(res_rd_busy),  // 捕获读忙状态
        .sleep      (1'b0),
        .injectsbiterr(1'b0),
        .injectdbiterr(1'b0)
    );

    // ---------------- 输入端 Fork 同步逻辑 ----------------
    wire pw_in_ready;
    
    // 只有 PW就绪、FIFO没满，且 FIFO 不在复位期，顶层才拉高 s_ready 接收数据
    assign s_ready  = pw_in_ready && !res_full && !res_wr_busy;
    wire s_fire     = s_valid && s_ready;
    
    assign res_push = s_fire;
    wire pw_in_valid = s_valid && !res_full && !res_wr_busy;

    // ---------------- PW (unchanged module instance) ----------------
    wire        pw_valid;
    wire        pw_ready;
    wire [6:0]  pw_och;
    wire [9:0]  pw_pix;
    wire signed [12:0] pw_data;

    pointwise1x1_grp8_32to96_vr #(
        .USE_RELU(1),
        .OUT_SHIFT(13)
    ) u_pw (
        .clk(clk),
        .rst_n(rst_n),

        .in_valid(pw_in_valid),
        .in_ready(pw_in_ready),
        .in_och(s_och),
        .in_pix_idx(s_pix_idx),
        .in_data(s_data),

        .out_valid(pw_valid),
        .out_ready(pw_ready),
        .out_och(pw_och),
        .out_pix_idx(pw_pix),
        .out_data(pw_data)
    );

    // ============================================================
    // FIFO #1 : PW -> DW
    // ============================================================
    wire        f1_s_valid = pw_valid;
    wire        f1_s_ready;
    wire [29:0] f1_s_data  = {pw_och, pw_pix, pw_data};

    wire        f1_m_valid;
    wire        f1_m_ready;
    wire [29:0] f1_m_data;

    rv_fifo_showahead #(
        .WIDTH(30),
        .DEPTH(8)
    ) u_fifo_pw_dw (
        .clk(clk),
        .rst_n(rst_n),
        .s_valid(f1_s_valid),
        .s_ready(f1_s_ready),
        .s_data (f1_s_data),
        .m_valid(f1_m_valid),
        .m_ready(f1_m_ready),
        .m_data (f1_m_data)
    );
    assign pw_ready = f1_s_ready;

    wire [6:0]  pw2dw_och  = f1_m_data[29:23];
    wire [9:0]  pw2dw_pix  = f1_m_data[22:13];
    wire signed [12:0] pw2dw_data = $signed(f1_m_data[12:0]);

    // ---------------- DW (unchanged module instance) ----------------
    wire        dw_valid;
    wire        dw_ready;
    wire [6:0]  dw_och;
    wire [9:0]  dw_pix;
    wire signed [12:0] dw_data;
    wire        dw_last;

    dwconv5x5_p25_96_h32w32_bram #(
        .H(32),
        .W(32),
        .PAD(2),
        .OUT_SHIFT(9),
        .USE_RELU(1)
    ) u_dw (
        .clk(clk),
        .rst_n(rst_n),

        .in_valid(f1_m_valid),
        .in_ready(f1_m_ready),
        .in_och(pw2dw_och),
        .in_pix_idx(pw2dw_pix),
        .in_data(pw2dw_data),

        .out_valid(dw_valid),
        .out_ready(dw_ready),
        .out_och(dw_och),
        .out_pix_idx(dw_pix),
        .out_data(dw_data),
        .out_last(dw_last)
    );

    // ============================================================
    // FIFO #2 : DW -> PROJ
    // ============================================================
    wire        f2_s_valid = dw_valid;
    wire        f2_s_ready;
    wire [29:0] f2_s_data  = {dw_och, dw_pix, dw_data};

    wire        f2_m_valid;
    wire        f2_m_ready;
    wire [29:0] f2_m_data;

    rv_fifo_showahead #(
        .WIDTH(30),
        .DEPTH(8)
    ) u_fifo_dw_pj (
        .clk(clk),
        .rst_n(rst_n),
        .s_valid(f2_s_valid),
        .s_ready(f2_s_ready),
        .s_data (f2_s_data),
        .m_valid(f2_m_valid),
        .m_ready(f2_m_ready),
        .m_data (f2_m_data)
    );
    assign dw_ready = f2_s_ready;

    wire [6:0]  dw2pj_och  = f2_m_data[29:23];
    wire [9:0]  dw2pj_pix  = f2_m_data[22:13];
    wire signed [12:0] dw2pj_data = $signed(f2_m_data[12:0]);

    // ---------------- PROJ (unchanged module instance) ----------------
    wire        pj_valid;
    wire        pj_ready;
    wire [5:0]  pj_och;
    wire [9:0]  pj_pix;
    wire signed [12:0] pj_data;

    pointwise1x1_grp8_96to32_vr #(
        .USE_RELU(0),
        .OUT_SHIFT(15)
    ) u_proj (
        .clk(clk),
        .rst_n(rst_n),

        .in_valid(f2_m_valid),
        .in_ready(f2_m_ready),
        .in_och(dw2pj_och),
        .in_pix_idx(dw2pj_pix),
        .in_data(dw2pj_data),

        .out_valid(pj_valid),
        .out_ready(pj_ready),
        .out_och(pj_och),
        .out_pix_idx(pj_pix),
        .out_data(pj_data)
    );

    // ============================================================
    // 输出端 Join 逻辑：实现按序相加 (带饱和截断)
    // ============================================================
    wire f3_s_ready;
    
    // 确保 PROJ 有效、旁路 FIFO 不空，且读端口不在复位忙碌状态
    wire joined_valid = pj_valid && !res_empty && !res_rd_busy;
    
    // 联合握手信号：下游准备好，且双端数据都有效时，同时消耗两端数据
    assign res_pop  = pj_valid && f3_s_ready && !res_empty && !res_rd_busy;
    assign pj_ready = f3_s_ready && !res_empty && !res_rd_busy;

    wire f3_s_valid = joined_valid;

    // 有符号 13-bit 饱和加法计算
    wire signed [13:0] add_temp = $signed(pj_data) + $signed(res_dout);
    wire signed [12:0] sat_data = (add_temp > 14'sd4095)  ? 13'sd4095 :
                                  (add_temp < -14'sd4096) ? -13'sd4096 :
                                  add_temp[12:0];

    // ============================================================
    // FIFO #3 : PROJ -> TOP output
    // ============================================================
    wire        pj_last_tag = (pj_pix == 10'd1023) && (pj_och == 6'd31);
    
    // 使用饱和加法结果替换原 pj_data
    wire [29:0] f3_s_data  = {pj_last_tag, pj_pix, pj_och, sat_data}; 

    wire        f3_m_valid;
    wire        f3_m_ready;
    wire [29:0] f3_m_data;

    rv_fifo_showahead #(
        .WIDTH(30),
        .DEPTH(8)
    ) u_fifo_pj_out (
        .clk(clk),
        .rst_n(rst_n),
        .s_valid(f3_s_valid),
        .s_ready(f3_s_ready),
        .s_data (f3_s_data),
        .m_valid(f3_m_valid),
        .m_ready(f3_m_ready),
        .m_data (f3_m_data)
    );

    assign m_valid    = f3_m_valid;
    assign f3_m_ready = m_ready;

    wire out_last_tag      = f3_m_data[29];
    wire [9:0] out_pix     = f3_m_data[28:19];
    wire [5:0] out_och6    = f3_m_data[18:13];
    wire signed [12:0] out_data13 = $signed(f3_m_data[12:0]);

    assign m_pix_idx = out_pix;
    assign m_och     = out_och6;
    assign m_data    = out_data13;

    // last only when the last beat is actually accepted
    assign m_last = m_valid && m_ready && out_last_tag;
endmodule