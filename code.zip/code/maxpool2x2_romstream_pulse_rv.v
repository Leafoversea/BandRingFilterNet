`timescale 1ns/1ps
`default_nettype none

module maxpool2x2_romstream_pulse_rv #(
    parameter integer W    = 64,
    parameter integer H    = 64,
    parameter integer BITS = 8,
    parameter integer AW   = 12
)(
    input  wire               clk,
    input  wire               rst_n,

    output wire               rom_en,
    input  wire [AW-1:0]      rom_addr_q,
    input  wire [3*BITS-1:0]  rom_pix,
    input  wire               rom_pix_valid,

    input  wire               out_ready,
    output reg                out_pulse,
    output reg  [3*BITS-1:0]  out_data,
    output reg                out_sof,
    output reg                out_eof,

    output wire               drop_pulse
);

    // ============================================================
    // Local params / helpers
    // ============================================================
    localparam integer PIXW = 3*BITS;
    localparam integer R_HI = 3*BITS-1;
    localparam integer R_LO = 2*BITS;
    localparam integer G_HI = 2*BITS-1;
    localparam integer G_LO = 1*BITS;
    localparam integer B_HI = 1*BITS-1;
    localparam integer B_LO = 0;

    function integer clog2;
        input integer v;
        integer i;
        begin
            clog2 = 0;
            for (i = v-1; i > 0; i = i >> 1)
                clog2 = clog2 + 1;
        end
    endfunction

    localparam integer CW = clog2(W);
    localparam integer RH = clog2(H);

    // ============================================================
    // ROM request / input buffer
    // ============================================================
    reg             rom_req_pend;

    reg             ibuf_v;
    reg [PIXW-1:0]  ibuf_d;
    reg             ibuf_sof;

    // 1-entry output skid buffer (pend_*)
    reg             pend_v;
    reg [PIXW-1:0]  pend_data;
    reg             pend_sof;
    reg             pend_eof;

    wire core_in_ready = ~pend_v;
    wire accept_in     = ibuf_v & core_in_ready;

    assign rom_en     = (~rom_req_pend) & (~ibuf_v);
    assign drop_pulse = rom_pix_valid & ibuf_v;

    // ============================================================
    // Row/Col counters
    // ============================================================
    reg [CW-1:0] col;
    reg [RH-1:0] row;

    wire [CW-1:0] col_c = (ibuf_sof) ? {CW{1'b0}} : col;
    wire [RH-1:0] row_c = (ibuf_sof) ? {RH{1'b0}} : row;

    wire col_is_last = (col_c == (W-1));
    wire row_is_last = (row_c == (H-1));

    // ============================================================
    // line buffer + pooling state
    // ============================================================
    reg [PIXW-1:0] top_prev;
    reg [PIXW-1:0] bot_prev;
    reg            sof_pending;

    (* ram_style = "distributed" *)
    reg [PIXW-1:0] linebuf [0:W-1];

    wire [PIXW-1:0] bot_pix = ibuf_d;
    wire [PIXW-1:0] top_pix = linebuf[col_c];

    wire emit_this = (col_c[0] == 1'b1) && (row_c[0] == 1'b1);
    wire last_in   = col_is_last && row_is_last;
    wire last_out  = emit_this && last_in;

    // ============================================================
    // max helpers
    // ============================================================
    function [BITS-1:0] umax2;
        input [BITS-1:0] a,b;
        begin
            umax2 = (a > b) ? a : b;
        end
    endfunction

    // ============================================================
    // Stage0 regs: register top_pix/bot_pix/parity/flags
    // ============================================================
    reg            s0_v;
    reg [PIXW-1:0] s0_top;
    reg [PIXW-1:0] s0_bot;
    reg            s0_col_odd;
    reg            s0_row_odd;
    reg            s0_sofpend;
    reg            s0_last_out;

    // ============================================================
    // NEW Stage1A regs: pipeline the heavy max4 comparator chain
    //   - stage1a computes pairwise maxima (tl,tr) and (bl,br) for each channel
    //   - stage1b computes final max and drives gen_*
    // ============================================================
    reg            s1a_v;
    reg [BITS-1:0] s1a_r_m1, s1a_r_m2;
    reg [BITS-1:0] s1a_g_m1, s1a_g_m2;
    reg [BITS-1:0] s1a_b_m1, s1a_b_m2;
    reg            s1a_sof;
    reg            s1a_eof;

    // ============================================================
    // +2 latency token pipeline: gen -> tok1 -> tok2
    // ============================================================
    reg            gen_v;
    reg [PIXW-1:0] gen_data;
    reg            gen_sof;
    reg            gen_eof;

    reg            tok1_v;
    reg [PIXW-1:0] tok1_data;
    reg            tok1_sof;
    reg            tok1_eof;

    reg            tok2_v;
    reg [PIXW-1:0] tok2_data;
    reg            tok2_sof;
    reg            tok2_eof;

    integer i;

    // ============================================================
    // Sequential logic
    // ============================================================
    always @(posedge clk) begin
        if (!rst_n) begin
            rom_req_pend <= 1'b0;

            ibuf_v   <= 1'b0;
            ibuf_d   <= {PIXW{1'b0}};
            ibuf_sof <= 1'b0;

            col <= {CW{1'b0}};
            row <= {RH{1'b0}};

            top_prev    <= {PIXW{1'b0}};
            bot_prev    <= {PIXW{1'b0}};
            sof_pending <= 1'b1;

            pend_v    <= 1'b0;
            pend_data <= {PIXW{1'b0}};
            pend_sof  <= 1'b0;
            pend_eof  <= 1'b0;

            s0_v       <= 1'b0;
            s0_top     <= {PIXW{1'b0}};
            s0_bot     <= {PIXW{1'b0}};
            s0_col_odd <= 1'b0;
            s0_row_odd <= 1'b0;
            s0_sofpend <= 1'b0;
            s0_last_out<= 1'b0;

            // NEW stage1a
            s1a_v    <= 1'b0;
            s1a_r_m1 <= {BITS{1'b0}}; s1a_r_m2 <= {BITS{1'b0}};
            s1a_g_m1 <= {BITS{1'b0}}; s1a_g_m2 <= {BITS{1'b0}};
            s1a_b_m1 <= {BITS{1'b0}}; s1a_b_m2 <= {BITS{1'b0}};
            s1a_sof  <= 1'b0;
            s1a_eof  <= 1'b0;

            gen_v    <= 1'b0;
            gen_data <= {PIXW{1'b0}};
            gen_sof  <= 1'b0;
            gen_eof  <= 1'b0;

            tok1_v    <= 1'b0;
            tok1_data <= {PIXW{1'b0}};
            tok1_sof  <= 1'b0;
            tok1_eof  <= 1'b0;

            tok2_v    <= 1'b0;
            tok2_data <= {PIXW{1'b0}};
            tok2_sof  <= 1'b0;
            tok2_eof  <= 1'b0;

            out_pulse <= 1'b0;
            out_data  <= {PIXW{1'b0}};
            out_sof   <= 1'b0;
            out_eof   <= 1'b0;

`ifndef SYNTHESIS
            for (i=0; i<W; i=i+1)
                linebuf[i] <= {PIXW{1'b0}};
`endif
        end else begin
            // defaults
            out_pulse <= 1'b0;
            out_sof   <= 1'b0;
            out_eof   <= 1'b0;

            gen_v   <= 1'b0;
            gen_sof <= 1'b0;
            gen_eof <= 1'b0;

            // NEW stage1a default
            s1a_v <= 1'b0;

            // -------------------------
            // ROM request / capture
            // -------------------------
            if (rom_en)
                rom_req_pend <= 1'b1;

            if (rom_req_pend && rom_pix_valid) begin
                rom_req_pend <= 1'b0;
                if (!ibuf_v) begin
                    ibuf_v   <= 1'b1;
                    ibuf_d   <= rom_pix;
                    ibuf_sof <= (rom_addr_q == {AW{1'b0}});
                end
            end

            if (accept_in) begin
                ibuf_v   <= 1'b0;
                ibuf_sof <= 1'b0;
            end

            // -------------------------
            // Token pipeline shift (+2)
            // -------------------------
            tok1_v    <= gen_v;
            tok1_data <= gen_data;
            tok1_sof  <= gen_sof;
            tok1_eof  <= gen_eof;

            tok2_v    <= tok1_v;
            tok2_data <= tok1_data;
            tok2_sof  <= tok1_sof;
            tok2_eof  <= tok1_eof;

            // -------------------------
            // Output skid buffer using tok2_*
            // -------------------------
            if (pend_v) begin
                if (out_ready) begin
                    out_pulse <= 1'b1;
                    out_data  <= pend_data;
                    out_sof   <= pend_sof;
                    out_eof   <= pend_eof;
                    pend_v    <= 1'b0;

                    if (tok2_v) begin
                        pend_v    <= 1'b1;
                        pend_data <= tok2_data;
                        pend_sof  <= tok2_sof;
                        pend_eof  <= tok2_eof;
                    end
                end
            end else begin
                if (tok2_v) begin
                    if (out_ready) begin
                        out_pulse <= 1'b1;
                        out_data  <= tok2_data;
                        out_sof   <= tok2_sof;
                        out_eof   <= tok2_eof;
                    end else begin
                        pend_v    <= 1'b1;
                        pend_data <= tok2_data;
                        pend_sof  <= tok2_sof;
                        pend_eof  <= tok2_eof;
                    end
                end
            end

            // ======================================================
            // Stage1B: consume previous cycle's s1a_* -> emit gen
            // (this is the NEW timing cut: s0_* no longer directly feeds gen_data_reg)
            // ======================================================
            if (s1a_v) begin
                // final max (1 compare per channel)
                gen_v    <= 1'b1;
                gen_data <= {
                    umax2(s1a_r_m1, s1a_r_m2),
                    umax2(s1a_g_m1, s1a_g_m2),
                    umax2(s1a_b_m1, s1a_b_m2)
                };
                gen_sof  <= s1a_sof;
                gen_eof  <= s1a_eof;

                if (s1a_sof)
                    sof_pending <= 1'b0;
            end

            // ======================================================
            // Stage1 (unchanged behavior): use s0_* to update prev and
            // when (odd col, odd row) capture stage1a pairwise maxima.
            // ======================================================
            if (s0_v) begin
                if (!s0_col_odd) begin
                    top_prev <= s0_top;
                    bot_prev <= s0_bot;
                end else begin
                    // odd col
                    if (s0_row_odd) begin
                        // Stage1A capture
                        // window: tl=top_prev, tr=s0_top, bl=bot_prev, br=s0_bot
                        s1a_v <= 1'b1;

                        // R channel
                        s1a_r_m1 <= umax2(top_prev[R_HI:R_LO], s0_top[R_HI:R_LO]);
                        s1a_r_m2 <= umax2(bot_prev[R_HI:R_LO], s0_bot[R_HI:R_LO]);
                        // G channel
                        s1a_g_m1 <= umax2(top_prev[G_HI:G_LO], s0_top[G_HI:G_LO]);
                        s1a_g_m2 <= umax2(bot_prev[G_HI:G_LO], s0_bot[G_HI:G_LO]);
                        // B channel
                        s1a_b_m1 <= umax2(top_prev[B_HI:B_LO], s0_top[B_HI:B_LO]);
                        s1a_b_m2 <= umax2(bot_prev[B_HI:B_LO], s0_bot[B_HI:B_LO]);

                        s1a_sof <= s0_sofpend;
                        s1a_eof <= s0_last_out;
                    end
                end
            end

            // ======================================================
            // Stage0: accept_in -> register top_pix/bot_pix/parity/flags
            // Also update linebuf and col/row counters.
            // ======================================================
            s0_v <= 1'b0;
            if (!pend_v) begin
                if (accept_in) begin
                    if (ibuf_sof)
                        sof_pending <= 1'b1;

                    s0_v       <= 1'b1;
                    s0_top     <= top_pix;
                    s0_bot     <= bot_pix;
                    s0_col_odd <= col_c[0];
                    s0_row_odd <= row_c[0];
                    s0_sofpend <= sof_pending;
                    s0_last_out<= last_out;

                    linebuf[col_c] <= bot_pix;

                    if (col_is_last) begin
                        col <= {CW{1'b0}};
                        if (row_is_last)
                            row <= {RH{1'b0}};
                        else
                            row <= row_c + {{(RH-1){1'b0}},1'b1};
                    end else begin
                        col <= col_c + {{(CW-1){1'b0}},1'b1};
                        row <= row_c;
                    end
                end
            end
        end
    end

endmodule

`default_nettype wire