`timescale 1ns / 1ps

module calibrator8x8_stream #(
    parameter PATH = "E:/Desktop/ring2/save_to_FPGA/head/calibrator_mem"
)(
    input  wire                    clk,
    input  wire                    rst_n,

    // 与前级 FC 输出保持兼容
    input  wire                    s_valid,
    output wire                    s_ready,
    input  wire [0:0]              s_pix_idx,   
    input  wire [2:0]              s_och,       
    input  wire signed [31:0]      s_data,      
    input  wire                    s_last,      

    // 输出校准后的8个logit
    output reg                     m_valid,
    input  wire                    m_ready,
    output reg  [0:0]              m_pix_idx,   
    output reg  [2:0]              m_och,       
    output reg  signed [31:0]      m_data,      
    output reg                     m_last
);

    localparam integer SHIFT_OUT = 13;

    localparam [1:0]
        ST_RECV = 2'd0,
        ST_OUT  = 2'd1;

    reg [1:0] state;
    
    // 权重与偏置内存
    reg [127:0] wbank00 [0:7];
    reg signed [31:0] bias_mem [0:7];

    reg signed [44:0] acc [0:7];

    integer i;

    initial begin
        $readmemh({PATH,"/wbank00.mem"},    wbank00);
        $readmemh({PATH,"/bias08_i32.mem"}, bias_mem);
    end

    // [优化点]: 预计算含有四舍五入常数的Bias。原先加法发生在ST_OUT管道中，
    // 现在直接合并在第一拍接收阶段，省去 ST_OUT 级联中的庞大 CARRY 资源
    wire signed [44:0] bias_rnd [0:7];
    genvar g;
    generate
        for (g = 0; g < 8; g = g + 1) begin : gen_bias_rnd
            assign bias_rnd[g] = {{13{bias_mem[g][31]}}, bias_mem[g]} + (45'sd1 <<< (SHIFT_OUT - 1));
        end
    endgenerate

    // ------------------------------------------------------------
    // 延迟、握手平衡与内部流水线逻辑
    // ------------------------------------------------------------
    reg pipe_busy;
    reg s_valid_pipe;
    reg [2:0] s_och_pipe;
    reg s_last_pipe;
    
    reg signed [40:0] p_reg [0:7];

    // ST_OUT 输出级内部流水线寄存器
    reg [3:0] rd_idx; 
    reg       pipe1_valid;
    reg [2:0] pipe1_och;
    reg       pipe1_last;
    reg signed [31:0] pipe1_data; // 替换了庞大的46位中间寄存储器

    assign s_ready = (state == ST_RECV) && !pipe_busy;

    reg signed [15:0] w0, w1, w2, w3, w4, w5, w6, w7;
    reg [127:0] line0, line1, line2, line3, line4, line5, line6, line7;

    always @(*) begin
        line0 = wbank00[0];
        line1 = wbank00[1];
        line2 = wbank00[2];
        line3 = wbank00[3];
        line4 = wbank00[4];
        line5 = wbank00[5];
        line6 = wbank00[6];
        line7 = wbank00[7];

        w0 = line0[s_och*16 +: 16];
        w1 = line1[s_och*16 +: 16];
        w2 = line2[s_och*16 +: 16];
        w3 = line3[s_och*16 +: 16];
        w4 = line4[s_och*16 +: 16];
        w5 = line5[s_och*16 +: 16];
        w6 = line6[s_och*16 +: 16];
        w7 = line7[s_och*16 +: 16];
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            state        <= ST_RECV;
            m_valid      <= 1'b0;
            m_pix_idx    <= 1'b0;
            m_och        <= 3'd0;
            m_data       <= 32'sd0;
            m_last       <= 1'b0;
            
            pipe_busy    <= 1'b0;
            s_valid_pipe <= 1'b0;
            s_och_pipe   <= 3'd0;
            s_last_pipe  <= 1'b0;
            
            rd_idx       <= 4'd0;
            pipe1_valid  <= 1'b0;
            pipe1_och    <= 3'd0;
            pipe1_last   <= 1'b0;
            pipe1_data   <= 32'sd0;

            for (i = 0; i < 8; i = i + 1) begin
                acc[i]   <= 45'sd0;
                p_reg[i] <= 41'sd0;
            end
        end else begin
            
            // --- 阶段 0: 握手与输入控制 ---
            if (s_valid && s_ready && s_last)
                pipe_busy <= 1'b1;
            else if (state == ST_OUT && m_valid && m_ready && m_last)
                pipe_busy <= 1'b0; 

            if (s_ready) begin
                s_valid_pipe <= s_valid;
                s_och_pipe   <= s_och;
                s_last_pipe  <= s_last;
            end else begin
                s_valid_pipe <= 1'b0;
            end

            // --- 阶段 1: DSP乘法器并行计算 ---
            if (s_valid && s_ready) begin
                p_reg[0] <= $signed(s_data[24:0]) * $signed(w0);
                p_reg[1] <= $signed(s_data[24:0]) * $signed(w1);
                p_reg[2] <= $signed(s_data[24:0]) * $signed(w2);
                p_reg[3] <= $signed(s_data[24:0]) * $signed(w3);
                p_reg[4] <= $signed(s_data[24:0]) * $signed(w4);
                p_reg[5] <= $signed(s_data[24:0]) * $signed(w5);
                p_reg[6] <= $signed(s_data[24:0]) * $signed(w6);
                p_reg[7] <= $signed(s_data[24:0]) * $signed(w7);
            end

            // --- 阶段 2: 状态机与流水线控制 ---
            case (state)
                ST_RECV: begin
                    m_valid <= 1'b0;
                    m_last  <= 1'b0;

                    if (s_valid_pipe) begin
                        if (s_och_pipe == 3'd0) begin
                            // 第一拍使用包含四舍五入常量的偏置
                            acc[0] <= bias_rnd[0] + {{4{p_reg[0][40]}}, p_reg[0]};
                            acc[1] <= bias_rnd[1] + {{4{p_reg[1][40]}}, p_reg[1]};
                            acc[2] <= bias_rnd[2] + {{4{p_reg[2][40]}}, p_reg[2]};
                            acc[3] <= bias_rnd[3] + {{4{p_reg[3][40]}}, p_reg[3]};
                            acc[4] <= bias_rnd[4] + {{4{p_reg[4][40]}}, p_reg[4]};
                            acc[5] <= bias_rnd[5] + {{4{p_reg[5][40]}}, p_reg[5]};
                            acc[6] <= bias_rnd[6] + {{4{p_reg[6][40]}}, p_reg[6]};
                            acc[7] <= bias_rnd[7] + {{4{p_reg[7][40]}}, p_reg[7]};
                        end else begin
                            acc[0] <= acc[0] + {{4{p_reg[0][40]}}, p_reg[0]};
                            acc[1] <= acc[1] + {{4{p_reg[1][40]}}, p_reg[1]};
                            acc[2] <= acc[2] + {{4{p_reg[2][40]}}, p_reg[2]};
                            acc[3] <= acc[3] + {{4{p_reg[3][40]}}, p_reg[3]};
                            acc[4] <= acc[4] + {{4{p_reg[4][40]}}, p_reg[4]};
                            acc[5] <= acc[5] + {{4{p_reg[5][40]}}, p_reg[5]};
                            acc[6] <= acc[6] + {{4{p_reg[6][40]}}, p_reg[6]};
                            acc[7] <= acc[7] + {{4{p_reg[7][40]}}, p_reg[7]};
                        end

                        if (s_last_pipe) begin
                            rd_idx      <= 4'd0;
                            pipe1_valid <= 1'b0;
                            state       <= ST_OUT;
                        end
                    end
                end

                ST_OUT: begin
                    if (!m_valid || (m_valid && m_ready)) begin
                        
                        if (pipe1_valid) begin
                            m_valid   <= 1'b1;
                            m_pix_idx <= 1'b0;
                            m_och     <= pipe1_och;
                            m_last    <= pipe1_last;
                            m_data    <= pipe1_data; // 无缝通过寄存器输出
                        end else begin
                            m_valid   <= 1'b0;
                            if (rd_idx == 4'd8) begin
                                state <= ST_RECV;
                            end
                        end

                        if (rd_idx < 4'd8) begin
                            pipe1_valid <= 1'b1;
                            pipe1_och   <= rd_idx[2:0];
                            pipe1_last  <= (rd_idx == 4'd7);
                            // [终极收拢]: 利用Verilog硬件切片完成右移13位，并安全放入32位管道中。没有逻辑延迟，直接走线！
                            pipe1_data  <= acc[rd_idx[2:0]][44:13]; 
                            
                            rd_idx <= rd_idx + 4'd1;
                        end else begin
                            pipe1_valid <= 1'b0;
                        end
                        
                    end
                end

                default: state <= ST_RECV;
            endcase
        end
    end

endmodule