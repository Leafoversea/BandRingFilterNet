`timescale 1ns/1ps
`default_nettype none

// Async ROM: combinational read (distributed ROM) for fall-through path.
module coef_ck_imre32_rom_async #(
    parameter integer C = 32,
    parameter integer K = 8
)(
    input  wire [15:0] addr,
    output wire [31:0] dout
);

    localparam integer DEPTH = C*K;
    localparam COEF_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ring/coef_ck_imre32.mem";

    (* rom_style = "distributed" *) reg [31:0] mem [0:DEPTH-1];

    integer k;
    integer fd;
    initial begin
        for (k = 0; k < DEPTH; k = k + 1) mem[k] = 32'h0;
        fd = $fopen(COEF_MEM_FILE, "r");
        if (fd == 0) $finish;
        $fclose(fd);
        $readmemh(COEF_MEM_FILE, mem);
    end

    assign dout = mem[addr];

endmodule

`default_nettype wire