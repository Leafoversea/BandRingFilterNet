`timescale 1ns / 1ps

module GF_stage2 #(
    parameter PW_SHIFT = 0,
    parameter PW_MEM = "",
    parameter PW_BIAS = "",
    parameter DW_SHIFT = 0,
    parameter DW_MEM = "",
    parameter DW_BIAS = "",
    parameter PRO_SHIFT = 0,
    parameter PRO_MEM = "",
    parameter PRO_BIAS = ""
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        s_valid,
    output wire        s_ready,
    input  wire [7:0]  s_pix_idx,  // 10-bit -> 8-bit
    input  wire [5:0]  s_och,
    input  wire signed [12:0] s_data,
    input  wire        s_last,

    output wire        m_valid,
    input  wire        m_ready,
    output wire [7:0]  m_pix_idx,  // 10-bit -> 8-bit
    output wire [5:0]  m_och,
    output wire signed [12:0] m_data,
    output wire        m_last
);
    wire        res_full;
    wire        res_empty;
    wire signed [12:0] res_dout;
    wire        res_push;
    wire        res_pop;
    wire        res_wr_busy; 
    wire        res_rd_busy;

    xpm_fifo_sync #(
        .FIFO_MEMORY_TYPE("block"), 
        .FIFO_READ_LATENCY(0),            
        .FIFO_WRITE_DEPTH(16384),          
        .READ_DATA_WIDTH(13),
        .WRITE_DATA_WIDTH(13),
        .READ_MODE("fwft"),
        .USE_ADV_FEATURES("0000")
    ) u_res_fifo (
        .rst        (~rst_n),
        .wr_clk     (clk),
        .wr_en      (res_push),
        .din        (s_data),
        .full       (res_full),
        .rd_en      (res_pop),
        .dout       (res_dout),
        .empty      (res_empty),
        .wr_rst_busy(res_wr_busy),  
        .rd_rst_busy(res_rd_busy),  
        .sleep      (1'b0),
        .injectsbiterr(1'b0),
        .injectdbiterr(1'b0)
    );

    // =========================================================================
    // [时序修复 1]: 打拍隔离 XPM FIFO 内部较慢的 reset_busy 信号，切断长组合逻辑
    // =========================================================================
    reg res_wr_busy_q = 1'b1;
    reg res_rd_busy_q = 1'b1;
    always @(posedge clk) begin
        if (!rst_n) begin
            res_wr_busy_q <= 1'b1;
            res_rd_busy_q <= 1'b1;
        end else begin
            res_wr_busy_q <= res_wr_busy;
            res_rd_busy_q <= res_rd_busy;
        end
    end

    wire pw_in_ready;
    assign s_ready  = pw_in_ready && !res_full && !res_wr_busy_q;
    wire s_fire     = s_valid && s_ready;
    assign res_push = s_fire;
    wire pw_in_valid = s_valid && !res_full && !res_wr_busy_q;

    // ---------------- PW ----------------
    wire        pw_valid;
    wire        pw_ready;
    wire [7:0]  pw_och;    
    wire [7:0]  pw_pix;    // 8-bit
    wire signed [12:0] pw_data;

    pointwise1x1_grp8_48to144_vr #(
        .OUT_SHIFT(PW_SHIFT),
        .PW_MEM(PW_MEM),
        .PW_BIAS(PW_BIAS)
    )u_pw (
        .clk(clk), .rst_n(rst_n),
        .in_valid(pw_in_valid), .in_ready(pw_in_ready),
        .in_och(s_och), .in_pix_idx(s_pix_idx), .in_data(s_data),
        .out_valid(pw_valid), .out_ready(pw_ready),
        .out_och(pw_och), .out_pix_idx(pw_pix), .out_data(pw_data)
    );

    // ---------------- FIFO #1 : PW -> DW (29 bits) ----------------
    wire        f1_s_valid = pw_valid;
    wire        f1_s_ready;
    wire [28:0] f1_s_data  = {pw_och, pw_pix, pw_data}; 
    wire        f1_m_valid;
    wire        f1_m_ready;
    wire [28:0] f1_m_data;

    rv_fifo_showahead #(.WIDTH(29), .DEPTH(8)) u_fifo_pw_dw (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f1_s_valid), .s_ready(f1_s_ready), .s_data (f1_s_data),
        .m_valid(f1_m_valid), .m_ready(f1_m_ready), .m_data (f1_m_data)
    );
    assign pw_ready = f1_s_ready;

    wire [7:0]  pw2dw_och  = f1_m_data[28:21];
    wire [7:0]  pw2dw_pix  = f1_m_data[20:13];
    wire signed [12:0] pw2dw_data = $signed(f1_m_data[12:0]);

    // ---------------- DW ----------------
    wire        dw_valid;
    wire        dw_ready;
    wire [7:0]  dw_och;
    wire [7:0]  dw_pix;
    wire signed [12:0] dw_data;
    wire        dw_last;

    dwconv5x5_p25_144_h16w16_bram #(
        .DW_MEM (DW_MEM),
        .DW_BIAS(DW_BIAS),
        .OUT_SHIFT(DW_SHIFT)
    )u_dw (
        .clk(clk), .rst_n(rst_n),
        .in_valid(f1_m_valid), .in_ready(f1_m_ready),
        .in_och(pw2dw_och), .in_pix_idx(pw2dw_pix), .in_data(pw2dw_data),
        .out_valid(dw_valid), .out_ready(dw_ready),
        .out_och(dw_och), .out_pix_idx(dw_pix), .out_data(dw_data), .out_last(dw_last)
    );

    // ---------------- FIFO #2 : DW -> PROJ (29 bits) ----------------
    wire        f2_s_valid = dw_valid;
    wire        f2_s_ready;
    wire [28:0] f2_s_data  = {dw_och, dw_pix, dw_data};
    wire        f2_m_valid;
    wire        f2_m_ready;
    wire [28:0] f2_m_data;

    rv_fifo_showahead #(.WIDTH(29), .DEPTH(8)) u_fifo_dw_pj (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f2_s_valid), .s_ready(f2_s_ready), .s_data (f2_s_data),
        .m_valid(f2_m_valid), .m_ready(f2_m_ready), .m_data (f2_m_data)
    );
    assign dw_ready = f2_s_ready;

    wire [7:0]  dw2pj_och  = f2_m_data[28:21];
    wire [7:0]  dw2pj_pix  = f2_m_data[20:13];
    wire signed [12:0] dw2pj_data = $signed(f2_m_data[12:0]);

    // ---------------- PROJ ----------------
    wire        pj_valid;
    wire        pj_ready;
    wire [5:0]  pj_och;
    wire [7:0]  pj_pix;
    wire signed [12:0] pj_data;

    pointwise1x1_grp8_144to48_vr #(
        .PRO_MEM(PRO_MEM),
        .PRO_BIAS(PRO_BIAS),
        .OUT_SHIFT(PRO_SHIFT)
    )u_proj (
        .clk(clk), .rst_n(rst_n),
        .in_valid(f2_m_valid), .in_ready(f2_m_ready),
        .in_och(dw2pj_och), .in_pix_idx(dw2pj_pix), .in_data(dw2pj_data),
        .out_valid(pj_valid), .out_ready(pj_ready),
        .out_och(pj_och), .out_pix_idx(pj_pix), .out_data(pj_data)
    );

    // ---------------- Join 逻辑 ----------------
    wire f3_s_ready;
    wire joined_valid = pj_valid && !res_empty && !res_rd_busy_q;
    assign res_pop  = pj_valid && f3_s_ready && !res_empty && !res_rd_busy_q;
    assign pj_ready = f3_s_ready && !res_empty && !res_rd_busy_q;

    wire f3_s_valid = joined_valid;
    wire signed [13:0] add_temp = $signed(pj_data) + $signed(res_dout);
    wire signed [12:0] sat_data = (add_temp > 14'sd4095)  ? 13'sd4095 :
                                  (add_temp < -14'sd4096) ? -13'sd4096 : add_temp[12:0];

    // ---------------- FIFO #3 : PROJ -> TOP output (28 bits) ----------------
    wire        pj_last_tag = (pj_pix == 8'd255) && (pj_och == 6'd47);
    wire [27:0] f3_s_data  = {pj_last_tag, pj_pix, pj_och, sat_data};
    wire        f3_m_valid;
    wire        f3_m_ready;
    wire [27:0] f3_m_data;

    rv_fifo_showahead #(.WIDTH(28), .DEPTH(8)) u_fifo_pj_out (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f3_s_valid), .s_ready(f3_s_ready), .s_data (f3_s_data),
        .m_valid(f3_m_valid), .m_ready(f3_m_ready), .m_data (f3_m_data)
    );

    // =========================================================================
    // [时序修复 2]: 输出端插入 Skid Buffer，斩断跨模块的组合逻辑路径（Valid/Ready/Data）
    // =========================================================================
    reg         skid_valid;
    reg [27:0]  skid_data;
    reg         out_valid_reg;
    reg [27:0]  out_data_reg;

    always @(posedge clk) begin
        if (!rst_n) begin
            out_valid_reg <= 1'b0;
            skid_valid    <= 1'b0;
            out_data_reg  <= 28'd0;
            skid_data     <= 28'd0;
        end else begin
            // 弹出逻辑：下游取走数据
            if (m_ready) begin
                if (skid_valid) begin
                    out_valid_reg <= 1'b1;
                    out_data_reg  <= skid_data;
                    skid_valid    <= 1'b0;
                end else begin
                    out_valid_reg <= 1'b0;
                end
            end

            // 压入逻辑：接收上游新数据
            if (f3_m_ready && f3_m_valid) begin
                if (m_ready || !out_valid_reg) begin
                    out_valid_reg <= 1'b1;
                    out_data_reg  <= f3_m_data;
                end else begin
                    skid_valid <= 1'b1;
                    skid_data  <= f3_m_data;
                end
            end
        end
    end

    // 斩断反向反压长路径
    assign f3_m_ready = !skid_valid;

    // 斩断前向信号长布线路径
    assign m_valid   = out_valid_reg;
    assign m_last    = out_valid_reg && out_data_reg[27];
    assign m_pix_idx = out_data_reg[26:19];
    assign m_och     = out_data_reg[18:13];
    assign m_data    = $signed(out_data_reg[12:0]);

endmodule