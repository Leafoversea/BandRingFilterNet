module rv_fifo_showahead_block3 #(
    parameter integer WIDTH = 32,
    parameter integer DEPTH = 8
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 s_valid,
    output wire                 s_ready,
    input  wire [WIDTH-1:0]     s_data,
    output wire                 m_valid,
    input  wire                 m_ready,
    output wire [WIDTH-1:0]     m_data
);
    function integer clog2_int;
        input integer v; integer r; begin r = 0; v = v - 1;
            while (v > 0) begin v = v >> 1; r = r + 1; end
            clog2_int = (r < 1) ? 1 : r;
        end
    endfunction
    localparam integer AW = clog2_int(DEPTH);

    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [AW-1:0]    wptr, rptr;
    reg [AW:0]      count;

    wire empty = (count == {(AW+1){1'b0}});
    wire full  = (count == DEPTH[AW:0]);

    assign m_valid = !empty;
    assign m_data  = empty ? {WIDTH{1'b0}} : mem[rptr];  // [修复重点] 添加 0 掩码，解决仿真 XXXX 态
    assign s_ready = !full;

    wire push = s_valid && s_ready;
    wire pop  = m_valid && m_ready;

    always @(posedge clk) begin
        if (!rst_n) begin
            wptr <= 0; rptr <= 0; count <= 0;
        end else begin
            case ({push,pop})
                2'b10: begin mem[wptr] <= s_data; wptr <= wptr + 1'b1; count <= count + 1'b1; end
                2'b01: begin rptr <= rptr + 1'b1; count <= count - 1'b1; end
                2'b11: begin mem[wptr] <= s_data; wptr <= wptr + 1'b1; rptr <= rptr + 1'b1; end
                default: begin end
            endcase
        end
    end
endmodule
