`timescale 1ns/1ps
`default_nettype none

module ringmul_band_ck_stage_vr #(
    parameter integer H        = 32,
    parameter integer W        = 32,
    parameter integer Wc       = 17,
    parameter integer C        = 32,
    parameter integer K        = 8,
    parameter integer DW       = 16,
    parameter integer FQ       = 15,
    parameter integer DBG_EN   = 1,
    parameter integer DBG_MAX  = 256
)(
    input  wire          clk,
    input  wire          rst_n,
    input  wire          s_valid,
    output wire          s_ready,
    input  wire [5:0]    s_och,
    input  wire [4:0]    s_ky,
    input  wire [4:0]    s_kx,
    input  wire [DW-1:0] s_re,
    input  wire [DW-1:0] s_im,
    input  wire          s_last,
    output wire          m_valid,
    input  wire          m_ready,
    output wire [5:0]    m_och,
    output wire [4:0]    m_ky,
    output wire [4:0]    m_kx,
    output wire [DW-1:0] m_re,
    output wire [DW-1:0] m_im,
    output wire          m_last
);

    // ============================================================
    // Constants & Saturation Function
    // ============================================================
    localparam [6:0] CY = H/2;
    localparam [6:0] CX = W/2;

    localparam integer XW = DW;
    localparam integer GW = 16;
    localparam integer PW = XW + GW;
    localparam integer SW = PW + 1;

    function [DW-1:0] sat_dw;
        input signed [SW-1:0] x;
        reg over_pos;
        reg over_neg;
        begin
            over_pos = (x[SW-1] == 1'b0) && (|x[SW-2 : DW-1]);
            over_neg = (x[SW-1] == 1'b1) && (~&x[SW-2 : DW-1]);
            
            if (over_pos)       sat_dw = {1'b0, {(DW-1){1'b1}}};
            else if (over_neg)  sat_dw = {1'b1, {(DW-1){1'b0}}};
            else                sat_dw = x[DW-1:0];
        end
    endfunction

    // ============================================================
    // band_calc Precomputation (Distributed ROM)
    // ============================================================
    (* rom_style = "distributed" *) reg [2:0] sb_rom [0:1023];
    integer iy, ix;
    reg signed [6:0] temp_dy, temp_dx;
    reg [10:0] temp_r2_init;
    reg [3:0]  temp_b_init;
    initial begin
        for (iy = 0; iy < 32; iy = iy + 1) begin
            for (ix = 0; ix < 32; ix = ix + 1) begin
                temp_dy = $signed({2'b00, iy[4:0]}) - $signed({1'b0, CY[4:0]});
                if (ix[4:0] == CX[4:0]) temp_dx = -$signed({1'b0, CX[4:0]});
                else                    temp_dx =  $signed({2'b00, ix[4:0]});
                temp_r2_init = (temp_dy * temp_dy) + (temp_dx * temp_dx);
                temp_b_init = (temp_r2_init == 11'd0) ? 4'd0 : (temp_r2_init - 11'd1) >> 6;
                sb_rom[{iy[4:0], ix[4:0]}] = (temp_b_init > 4'd7) ? 3'd7 : temp_b_init[2:0];
            end
        end
    end

    // ============================================================
    // Pipeline Control (6-Stage optimized for DSP48E1: AREG -> MREG -> PREG)
    // ============================================================
    reg v0, v1, v2, v3, v4, v5;
    assign m_valid = v5;
    
    wire st5_ready = (!v5) || m_ready;
    wire st4_ready = (!v4) || st5_ready;
    wire st3_ready = (!v3) || st4_ready;
    wire st2_ready = (!v2) || st3_ready;
    wire st1_ready = (!v1) || st2_ready;
    wire st0_ready = (!v0) || st1_ready;
    
    assign s_ready = st0_ready;

    // ============================================================
    // Data & Logic Pipeline
    // ============================================================
    wire [2:0]  s_b_comb = (K == 8) ? sb_rom[{s_ky, s_kx}] : 3'd0;
    wire [15:0] s_a_comb = (K == 8) ? {7'b0, s_och, s_b_comb} : ((s_och * K) + s_b_comb);

    // -- Stage 0: Address Decoupling --
    (* max_fanout = "8" *) reg [15:0] r0_a;
    reg [5:0]    r0_och;
    reg [4:0]    r0_ky, r0_kx;
    reg [DW-1:0] r0_re, r0_im;
    reg          r0_last;

    // Lookup Async Coef based on registered Address 
    wire [31:0] w_coef;
    coef_ck_imre32_rom_async #(
        .C(C),
        .K(K)
    ) u_coef_async (
        .addr (r0_a),
        .dout (w_coef)
    );

    // -- Stage 1: Async ROM output registered in Fabric (Absorbs 3.19ns delay) --
    // 取消 dont_touch，释放后端的 DSP 内部输入寄存器
    reg [31:0]   r1_coef;
    reg [5:0]    r1_och;
    reg [4:0]    r1_ky, r1_kx;
    reg [DW-1:0] r1_re, r1_im;
    reg          r1_last;

    // -- Stage 2: Mapped to DSP48E1 Input Registers (AREG / BREG) --
    // 这级彻底消除了 Fabric FF 跨越布线网络进入乘法器核心的极高 Setup 建立时间违例
    reg signed [15:0] r2_xr, r2_xi, r2_gr, r2_gi;
    reg [5:0]    r2_och;
    reg [4:0]    r2_ky, r2_kx;
    reg          r2_last;

    // -- Stage 3: DSP Multiply (Mapped to DSP MREG) --
    (* use_dsp = "yes" *) reg signed [PW-1:0] r3_ac, r3_bd, r3_ad, r3_bc;
    reg [5:0]    r3_och;
    reg [4:0]    r3_ky, r3_kx;
    reg          r3_last;

    // -- Stage 4: DSP Post-Adder (Mapped to DSP PREG) --
    // Vivado 会自动推断级联，在 DSP 内部执行 r3_ac - r3_bd，白嫖加法器，省去 100+ LUT！
    (* use_dsp = "yes" *) reg signed [SW-1:0] r4_rr, r4_ii;
    reg [5:0]    r4_och;
    reg [4:0]    r4_ky, r4_kx;
    reg          r4_last;

    // -- Stage 5: Output stage (Fabric FF for Saturation) --
    reg [5:0]    r5_och;
    reg [4:0]    r5_ky, r5_kx;
    reg [DW-1:0] r5_re, r5_im;
    reg          r5_last;

    assign m_och   = r5_och;
    assign m_ky    = r5_ky;
    assign m_kx    = r5_kx;
    assign m_re    = r5_re;
    assign m_im    = r5_im;
    assign m_last  = r5_last;

    always @(posedge clk) begin
        if (!rst_n) begin
            v0 <= 1'b0; v1 <= 1'b0; v2 <= 1'b0; 
            v3 <= 1'b0; v4 <= 1'b0; v5 <= 1'b0;
        end else begin
            
            // Stage 5
            if (st5_ready) begin
                v5 <= v4;
                if (v4) begin
                    r5_och  <= r4_och;
                    r5_ky   <= r4_ky;
                    r5_kx   <= r4_kx;
                    r5_last <= r4_last;
                    r5_re   <= sat_dw(r4_rr >>> FQ);
                    r5_im   <= sat_dw(r4_ii >>> FQ);
                end
            end

            // Stage 4
            if (st4_ready) begin
                v4 <= v3;
                if (v3) begin
                    r4_och  <= r3_och;
                    r4_ky   <= r3_ky;
                    r4_kx   <= r3_kx;
                    r4_last <= r3_last;
                    r4_rr   <= r3_ac - r3_bd;  // 吸收到 DSP内部的 PREG
                    r4_ii   <= r3_ad + r3_bc;  // 吸收到 DSP内部的 PREG
                end
            end

            // Stage 3
            if (st3_ready) begin
                v3 <= v2;
                if (v2) begin
                    r3_och  <= r2_och;
                    r3_ky   <= r2_ky;
                    r3_kx   <= r2_kx;
                    r3_last <= r2_last;
                    r3_ac   <= r2_xr * r2_gr;  // 吸收到 DSP内部的 MREG
                    r3_bd   <= r2_xi * r2_gi;
                    r3_ad   <= r2_xr * r2_gi;
                    r3_bc   <= r2_xi * r2_gr;
                end
            end

            // Stage 2
            if (st2_ready) begin
                v2 <= v1;
                if (v1) begin
                    r2_och  <= r1_och;
                    r2_ky   <= r1_ky;
                    r2_kx   <= r1_kx;
                    r2_last <= r1_last;
                    r2_xr   <= $signed(r1_re);
                    r2_xi   <= $signed(r1_im);
                    r2_gr   <= $signed(r1_coef[15:0]);
                    r2_gi   <= $signed(r1_coef[31:16]);
                end
            end

            // Stage 1
            if (st1_ready) begin
                v1 <= v0;
                if (v0) begin
                    r1_och  <= r0_och;
                    r1_ky   <= r0_ky;
                    r1_kx   <= r0_kx;
                    r1_re   <= r0_re;
                    r1_im   <= r0_im;
                    r1_last <= r0_last;
                    r1_coef <= w_coef; // 吸收分布式 ROM 的高延迟
                end
            end

            // Stage 0
            if (st0_ready) begin
                v0 <= s_valid;
                if (s_valid) begin
                    r0_a    <= s_a_comb;
                    r0_och  <= s_och;
                    r0_ky   <= s_ky;
                    r0_kx   <= s_kx;
                    r0_re   <= s_re;
                    r0_im   <= s_im;
                    r0_last <= s_last;
                end
            end
        end
    end

endmodule