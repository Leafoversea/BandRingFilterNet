module rv_fifo_showahead #(
    parameter integer WIDTH = 32,
    parameter integer DEPTH = 8
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire                 s_valid,
    output wire                 s_ready,
    input  wire [WIDTH-1:0]     s_data,

    output wire                 m_valid,
    input  wire                 m_ready,
    output wire [WIDTH-1:0]     m_data
);
    function integer clog2_int;
        input integer v;
        integer r;
        begin
            r = 0;
            v = v - 1;
            while (v > 0) begin
                v = v >> 1;
                r = r + 1;
            end
            clog2_int = (r < 1) ? 1 : r;
        end
    endfunction

    localparam integer AW = clog2_int(DEPTH);

    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [AW-1:0]    wptr, rptr;
    reg [AW:0]      count;

    wire empty = (count == { (AW+1){1'b0} });
    wire full  = (count == DEPTH[AW:0]);

    // FWFT (show-ahead)
    assign m_valid = empty ? s_valid : 1'b1;
    //assign m_data  = empty ? s_data  : mem[rptr];
    assign m_data  = empty ? (s_valid ? s_data : {WIDTH{1'b0}}) : mem[rptr];
    // pop depends on downstream, but s_ready no longer depends on pop
    wire pop  = m_valid && m_ready;

    // ====== KEY CHANGE ======
    // Break the combinational path: m_ready -> pop -> s_ready
    // This may reduce peak throughput only in the rare "full && pop in same cycle" case,
    // but keeps ready/valid functional correctness (no reorder/no loss).
    assign s_ready = (!full);

    wire push = s_valid && s_ready;

    // bypass when empty & s_valid & m_ready in same cycle => direct forward, RAM untouched
    wire bypass = empty && s_valid && m_ready;

    always @(posedge clk) begin
        if (!rst_n) begin
            wptr  <= {AW{1'b0}};
            rptr  <= {AW{1'b0}};
            count <= {(AW+1){1'b0}};
            // mem[] reset removed to save resources; safe because empty is defined by count==0
        end else begin
            if (!bypass) begin
                case ({push,pop})
                    2'b10: begin
                        mem[wptr] <= s_data;
                        wptr      <= wptr + {{(AW-1){1'b0}},1'b1};
                        count     <= count + {{AW{1'b0}},1'b1};
                    end
                    2'b01: begin
                        rptr      <= rptr + {{(AW-1){1'b0}},1'b1};
                        count     <= count - {{AW{1'b0}},1'b1};
                    end
                    2'b11: begin
                        mem[wptr] <= s_data;
                        wptr      <= wptr + {{(AW-1){1'b0}},1'b1};
                        rptr      <= rptr + {{(AW-1){1'b0}},1'b1};
                        // count unchanged
                    end
                    default: begin end
                endcase
            end
            // bypass: remain empty; pointers/count unchanged
        end
    end

endmodule
