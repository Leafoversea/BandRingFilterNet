module rom64x16_dist_dbg (
    input  wire        clk,
    input  wire [5:0]  addr,
    output reg  [5:0]  addr_q,      // aligned address (1-cycle delayed)
    output reg  signed [431:0] dout
);
    (* ram_style = "block" *)reg [431:0] mem [0:63];
localparam MEM = "E:/Desktop/ring2/save_to_FPGA/stem/fold_stemconv_mem/stemconv.mem";

    initial begin
        $readmemh(MEM, mem);
    end
    always @(posedge clk) begin
        addr_q <= addr;                 
        dout   <= $signed(mem[addr]);  
    end
endmodule
