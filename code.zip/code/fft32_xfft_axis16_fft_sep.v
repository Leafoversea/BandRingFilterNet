`default_nettype wire
module fft32_xfft_axis16_fft_sep #(
    parameter integer IN_DW = 12,
    parameter [9:0] SCALE_SCH10 = 10'b0000000000,
    parameter       CFG_EACH_FRAME = 1'b0,

    // Force XFFT to do forward FFT (FWD_INV=1) instead of inverse (FWD_INV=0).
    // This bit is the LSB of s_axis_config_tdata for the common XFFT config layout.
    parameter       FWD_INV = 1'b1,

    // Kept only for compatibility with your other wrappers; no conjugate trick here anymore.
    parameter       PY_MODE = 1'b1
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [IN_DW-1:0] in_re,
    input  wire [IN_DW-1:0] in_im,
    input  wire             in_valid,
    output wire             in_ready,
    input  wire             in_last,

    output wire [15:0] out_re,
    output wire [15:0] out_im,
    output wire        out_valid,
    input  wire        out_ready,
    output wire        out_last,

    output wire        event_frame_started,
    output wire        event_tlast_unexpected,
    output wire        event_tlast_missing,
    output wire        event_status_channel_halt,
    output wire        event_data_in_channel_halt,
    output wire        event_data_out_channel_halt
);

    // ---------------- config channel ----------------
    reg cfg_done;

    // NOTE: For the common runtime-config layout, LSB is FWD_INV (1=FFT, 0=IFFT).
    // If your XFFT instance was generated with additional runtime fields (NFFT/CP_LEN),
    // this packing must match that exact layout.
    wire [15:0] cfg_tdata  = {5'b0, SCALE_SCH10, FWD_INV};
    wire        cfg_tvalid = !cfg_done;
    wire        cfg_tready;

    wire data_in_ready;
    assign in_ready = cfg_done && data_in_ready;

    wire din_valid = in_valid && cfg_done;
    wire din_last  = in_last && din_valid;

    // ---------------- data packing ----------------
    // Sign-extend inputs to 16-bit, no conjugate / sign flipping.
    wire [15:0] re16 = {{(16-IN_DW){in_re[IN_DW-1]}}, in_re};
    wire [15:0] im16 = {{(16-IN_DW){in_im[IN_DW-1]}}, in_im};

    wire [31:0] core_in_tdata = {im16, re16};

    wire [31:0] core_tdata;
    wire        core_tvalid;
    wire        core_tlast;

    // ---------------- output skid buffer ----------------
    reg  [15:0] out_re_r;
    reg  [15:0] out_im_r;
    reg         out_valid_r;
    reg         out_last_r;

    wire buf_ready   = (!out_valid_r) || out_ready;
    wire core_tready = buf_ready;

    // cfg_done logic
    always @(posedge clk) begin
        if (!rst_n) begin
            cfg_done <= 1'b0;
        end else begin
            if (!cfg_done) begin
                if (cfg_tvalid && cfg_tready) cfg_done <= 1'b1;
            end else if (CFG_EACH_FRAME != 0) begin
                if (din_valid && data_in_ready && din_last) cfg_done <= 1'b0;
            end
        end
    end

    wire [15:0] core_re16 = core_tdata[15:0];
    wire [15:0] core_im16 = core_tdata[31:16];

    always @(posedge clk) begin
        if (!rst_n) begin
            out_re_r    <= 16'd0;
            out_im_r    <= 16'd0;
            out_valid_r <= 1'b0;
            out_last_r  <= 1'b0;
        end else if (buf_ready) begin
            out_valid_r <= core_tvalid;
            if (core_tvalid) begin
                out_re_r   <= core_re16;
                out_im_r   <= core_im16;
                out_last_r <= core_tlast;
            end else begin
                out_re_r   <= 16'd0;
                out_im_r   <= 16'd0;
                out_last_r <= 1'b0;
            end
        end
    end

    assign out_re    = out_re_r;
    assign out_im    = out_im_r;
    assign out_valid = out_valid_r;
    assign out_last  = out_last_r;

    // ---------------- XFFT IP ----------------
    xfft_0 u_fft (
        .aclk(clk),
        .aresetn(rst_n),

        .s_axis_config_tdata(cfg_tdata),
        .s_axis_config_tvalid(cfg_tvalid),
        .s_axis_config_tready(cfg_tready),

        .s_axis_data_tdata(core_in_tdata),
        .s_axis_data_tvalid(din_valid),
        .s_axis_data_tready(data_in_ready),
        .s_axis_data_tlast(din_last),

        .m_axis_data_tdata(core_tdata),
        .m_axis_data_tvalid(core_tvalid),
        .m_axis_data_tready(core_tready),
        .m_axis_data_tlast(core_tlast),

        .event_frame_started(event_frame_started),
        .event_tlast_unexpected(event_tlast_unexpected),
        .event_tlast_missing(event_tlast_missing),
        .event_status_channel_halt(event_status_channel_halt),
        .event_data_in_channel_halt(event_data_in_channel_halt),
        .event_data_out_channel_halt(event_data_out_channel_halt)
    );

endmodule