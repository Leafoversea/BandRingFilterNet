module pointwise1x1_grp8_48to144_vr #(
    parameter integer USE_RELU  = 1,
    parameter integer OUT_SHIFT = 15,
    parameter PW_MEM ="",
    parameter PW_BIAS = ""
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_valid,
    output wire        in_ready,
    input  wire [5:0]  in_och,
    input  wire [7:0]  in_pix_idx, // 8-bit
    input  wire signed [12:0] in_data,

    output reg         out_valid,
    input  wire        out_ready,
    output reg  [7:0]  out_och,
    output reg  [7:0]  out_pix_idx, // 8-bit
    output reg  signed [12:0] out_data
);
    localparam integer NUM_IC = 48;
    localparam integer ACC_W  = 35; // 极限瘦身: 48通道累加，35位足够

    reg signed [12:0] xbuf0 [0:NUM_IC-1];
    reg signed [12:0] xbuf1 [0:NUM_IC-1];
    reg [7:0]         pix0, pix1;

    reg buf_full0, buf_full1;
    reg wr_pref;
    reg wr_active;
    reg wr_sel_lock;

    (* keep = "true", max_fanout = "16" *) reg rd_sel_0;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_1;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_2;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_3;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_4;
    (* keep = "true", max_fanout = "16" *) reg rd_sel_5;

    wire both_full = buf_full0 && buf_full1;
    assign in_ready = !both_full;
    wire in_fire = in_valid && in_ready;

    wire choose_buf0 = (!buf_full0) && ((wr_pref == 1'b0) || buf_full1);
    wire choose_buf1 = (!buf_full1) && ((wr_pref == 1'b1) || buf_full0);

    task write_xbuf48;
        input sel;
        input [5:0] idx;
        input signed [12:0] val;
        begin
            if (!sel) xbuf0[idx] <= val;
            else      xbuf1[idx] <= val;
        end
    endtask

    wire rd_buf_full = (rd_sel_0 == 1'b0) ? buf_full0 : buf_full1;
    wire other_full  = (rd_sel_0 == 1'b0) ? buf_full1 : buf_full0;
    wire [9:0] rd_pix = (rd_sel_0 == 1'b0) ? pix0 : pix1;

    (* keep = "true" *) reg  [7:0] w_addr;
    (* keep = "true" *) reg  [7:0] b_addr;

    wire [127:0] wgb0, wgb1, wgb2, wgb3, wgb4, wgb5;
    wire [7:0]   w0_addr_q;
    wire [7:0]   b_addr_q;

    // TODO: Replace with your actual 144x16 -> 768-bit ROM primitive
    pw_gbank144x16_to768_rom #(.MEM(PW_MEM))u_w0(
        .clk(clk),
        .addr(w_addr),
        .addr_q(w0_addr_q),
        .dout({wgb0, wgb1, wgb2, wgb3, wgb4, wgb5})
    );
    
    wire [31:0] b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;
    bias144_i32_rom #(.BIAS_MEM_FILE(PW_BIAS))u_b(
        .clk(clk),
        .addr(b_addr),
        .addr_q(b_addr_q),
        .dout(b_dout_u)
    );

    // Pipeline Stages
    reg        s0_v;
    reg [7:0]  s0_och;
    reg [7:0]  s0_pix;
    reg signed [31:0] s0_bias;
    reg signed [12:0] x_s0 [0:47];
    reg signed [16:0] w_s0 [0:47];

    reg        s1_v;
    reg [7:0]  s1_och;
    reg [7:0]  s1_pix;
    reg signed [31:0] s1_bias;
    (* use_dsp = "yes" *) reg signed [31:0] s1_p [0:47];
    
    reg        s2_v;
    reg [7:0]  s2_och;
    reg [7:0]  s2_pix;
    reg signed [31:0] s2_bias;
    reg signed [ACC_W-1:0] s2_s [0:23];

    reg        s2b_v;
    reg [7:0]  s2b_och;
    reg [7:0]  s2b_pix;
    reg signed [31:0] s2b_bias;
    reg signed [ACC_W-1:0] s2b_s [0:11];
    
    reg        s3_v;
    reg [7:0]  s3_och;
    reg [7:0]  s3_pix;
    reg signed [31:0] s3_bias;
    reg signed [ACC_W-1:0] s3_s [0:5];

    reg        s4_v;
    reg [7:0]  s4_och;
    reg [7:0]  s4_pix;
    reg signed [31:0] s4_bias;
    reg signed [ACC_W-1:0] s4_t0, s4_t1, s4_t2;
    
    reg        s5_v;
    reg [7:0]  s5_och;
    reg [7:0]  s5_pix;
    (* use_dsp = "no" *) reg signed [ACC_W-1:0] s5_sum_bias;
    
    reg        s6_v;
    reg [7:0]  s6_och;
    reg [7:0]  s6_pix;
    reg signed [ACC_W-1:0] s6_xs;

    reg skid_full;
    reg [7:0]  skid_och;
    reg [7:0]  skid_pix;
    reg signed [12:0] skid_data;
    
    wire pipe_en = !skid_full;
    wire s6_rdy  = pipe_en; wire s5_rdy  = pipe_en; wire s4_rdy  = pipe_en;
    wire s3_rdy  = pipe_en; wire s2b_rdy = pipe_en; wire s2_rdy  = pipe_en;
    wire s1_rdy  = pipe_en; wire s0_rdy  = pipe_en;

    function signed [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x;
        begin sext32_to_acc = {{(ACC_W-32){x[31]}}, x}; end
    endfunction

    wire signed [ACC_W-1:0] round_pos_w = (OUT_SHIFT == 0) ? {ACC_W{1'b0}} : ($signed({{(ACC_W-1){1'b0}}, 1'b1}) <<< (OUT_SHIFT-1));
    wire signed [ACC_W-1:0] round_neg_w = (OUT_SHIFT == 0) ? {ACC_W{1'b0}} : (round_pos_w - $signed({{(ACC_W-1){1'b0}}, 1'b1}));

    wire s5_sign = s5_sum_bias[ACC_W-1];
    wire signed [ACC_W-1:0] s5_rounded_sum = s5_sum_bias + round_pos_w;
    //wire signed [ACC_W-1:0] s5_rounded_sum = s5_sum_bias + round_neg_w + {{(ACC_W-1){1'b0}}, ~s5_sign};

    function signed [12:0] sat13_from_acc;
        input signed [ACC_W-1:0] x;
        begin
            if (x[ACC_W-1] == 1'b0) begin
                if (|x[ACC_W-2:12]) sat13_from_acc = 13'sd4095;
                else                sat13_from_acc = x[12:0];
            end else begin
                if (~&x[ACC_W-2:12]) sat13_from_acc = -13'sd4096;
                else                 sat13_from_acc = x[12:0];
            end
        end
    endfunction

    function signed [12:0] relu_sat13_from_acc;
        input signed [ACC_W-1:0] x;
        begin
            if ((USE_RELU != 0) && x[ACC_W-1]) relu_sat13_from_acc = 13'sd0;
            else                               relu_sat13_from_acc = sat13_from_acc(x);
        end
    endfunction

    reg        run;
    reg [7:0]  issue_och;
    reg        issued_all;
    reg        cap_pending;
    reg [7:0]  exp_och;

    wire last_issue = (issue_och == 8'd143);
    wire rom_aligned_exp = (w0_addr_q == exp_och);
    wire will_capture = run && cap_pending && pipe_en && rom_aligned_exp;
    wire can_issue    = run && pipe_en && (!issued_all) && ( (!cap_pending) || will_capture );
    wire can_capture  = will_capture;

    integer i;

    always @(posedge clk) begin
        if (!rst_n) begin
            buf_full0   <= 1'b0; buf_full1   <= 1'b0;
            wr_pref     <= 1'b0; wr_active   <= 1'b0; wr_sel_lock <= 1'b0;
            rd_sel_0    <= 1'b0; rd_sel_1    <= 1'b0; rd_sel_2    <= 1'b0;
            rd_sel_3    <= 1'b0; rd_sel_4    <= 1'b0; rd_sel_5    <= 1'b0;
            w_addr      <= 8'd0; b_addr      <= 8'd0;
            run         <= 1'b0; issue_och   <= 8'd0;
            issued_all  <= 1'b0; cap_pending <= 1'b0; exp_och     <= 8'd0;
            s0_v  <= 1'b0; s1_v  <= 1'b0; s2_v  <= 1'b0; s2b_v <= 1'b0;
            s3_v  <= 1'b0; s4_v  <= 1'b0; s5_v  <= 1'b0; s6_v  <= 1'b0;
            out_valid <= 1'b0; skid_full <= 1'b0;
        end else begin
            if (in_fire) begin
                if (!wr_active && (in_och == 6'd0)) begin
                    if (choose_buf0) begin
                        wr_sel_lock <= 1'b0; wr_active   <= 1'b1;
                        pix0        <= in_pix_idx; xbuf0[0]  <= $signed(in_data);
                    end else if (choose_buf1) begin
                        wr_sel_lock <= 1'b1; wr_active   <= 1'b1;
                        pix1        <= in_pix_idx; xbuf1[0]  <= $signed(in_data);
                    end
                end else if (wr_active && (in_och < 6'd48)) begin
                    write_xbuf48(wr_sel_lock, in_och, $signed(in_data));
                end

                if (wr_active && (in_och == 6'd47)) begin
                    if (!wr_sel_lock) buf_full0 <= 1'b1;
                    else              buf_full1 <= 1'b1;
                    wr_pref   <= ~wr_sel_lock;
                    wr_active <= 1'b0;
                end
            end

            if (!run) begin
                if (!rd_sel_0) begin
                    if (!buf_full0 && buf_full1) begin
                        rd_sel_0 <= 1'b1; rd_sel_1 <= 1'b1; rd_sel_2 <= 1'b1; 
                        rd_sel_3 <= 1'b1; rd_sel_4 <= 1'b1; rd_sel_5 <= 1'b1;
                    end
                end else begin
                    if (!buf_full1 && buf_full0) begin
                        rd_sel_0 <= 1'b0; rd_sel_1 <= 1'b0; rd_sel_2 <= 1'b0; 
                        rd_sel_3 <= 1'b0; rd_sel_4 <= 1'b0; rd_sel_5 <= 1'b0;
                    end
                end

                if (rd_buf_full) begin
                    run         <= 1'b1;
                    issued_all  <= 1'b0;
                    cap_pending <= 1'b0;
                end
            end else begin
                if (can_issue) begin
                    w_addr  <= issue_och; b_addr  <= issue_och; exp_och <= issue_och;
                    if (last_issue) issued_all <= 1'b1;
                    else            issue_och <= issue_och + 8'd1;
                end else if (issued_all && !cap_pending) begin
                    w_addr    <= 8'd0; b_addr    <= 8'd0; issue_och <= 8'd0; exp_och   <= 8'd0;
                end

                begin : CAP_UPD
                    reg issued_this, captured_this;
                    issued_this   = can_issue; captured_this = can_capture;
                    cap_pending <= (cap_pending && !captured_this) || issued_this;
                end

                if (s0_rdy) begin 
                    s0_v <= can_capture; s0_och  <= exp_och; s0_pix  <= rd_pix; s0_bias <= b_dout;
                    for (i=0; i<8; i=i+1) begin
                        x_s0[i]    <= rd_sel_0 ? xbuf1[i] : xbuf0[i];       w_s0[i]    <= $signed(wgb0[16*i +: 16]);
                        x_s0[8+i]  <= rd_sel_1 ? xbuf1[8+i] : xbuf0[8+i];   w_s0[8+i]  <= $signed(wgb1[16*i +: 16]);
                        x_s0[16+i] <= rd_sel_2 ? xbuf1[16+i] : xbuf0[16+i]; w_s0[16+i] <= $signed(wgb2[16*i +: 16]);
                        x_s0[24+i] <= rd_sel_3 ? xbuf1[24+i] : xbuf0[24+i]; w_s0[24+i] <= $signed(wgb3[16*i +: 16]);
                        x_s0[32+i] <= rd_sel_4 ? xbuf1[32+i] : xbuf0[32+i]; w_s0[32+i] <= $signed(wgb4[16*i +: 16]);
                        x_s0[40+i] <= rd_sel_5 ? xbuf1[40+i] : xbuf0[40+i]; w_s0[40+i] <= $signed(wgb5[16*i +: 16]);
                    end
                end

                if (s1_rdy) begin
                    if (s0_v) begin
                        s1_v <= 1'b1; s1_och <= s0_och; s1_pix <= s0_pix; s1_bias <= s0_bias;
                        for (i=0; i<48; i=i+1) s1_p[i] <= $signed(x_s0[i]) * $signed(w_s0[i]);
                    end else s1_v <= 1'b0;
                end

                if (s2_rdy) begin
                    if (s1_v) begin
                        s2_v <= 1'b1; s2_och <= s1_och; s2_pix <= s1_pix; s2_bias <= s1_bias;
                        for (i=0; i<24; i=i+1) s2_s[i] <= sext32_to_acc(s1_p[2*i]) + sext32_to_acc(s1_p[2*i+1]);
                    end else s2_v <= 1'b0;
                end

                if (s2b_rdy) begin
                    if (s2_v) begin
                        s2b_v <= 1'b1; s2b_och <= s2_och; s2b_pix <= s2_pix; s2b_bias <= s2_bias;
                        for (i=0; i<12; i=i+1) s2b_s[i] <= s2_s[2*i] + s2_s[2*i+1];
                    end else s2b_v <= 1'b0;
                end

                if (s3_rdy) begin
                    if (s2b_v) begin
                        s3_v <= 1'b1; s3_och <= s2b_och; s3_pix <= s2b_pix; s3_bias <= s2b_bias;
                        for (i=0; i<6; i=i+1) s3_s[i] <= s2b_s[2*i] + s2b_s[2*i+1];
                    end else s3_v <= 1'b0;
                end

                if (s4_rdy) begin
                    if (s3_v) begin
                        s4_v <= 1'b1; s4_och <= s3_och; s4_pix <= s3_pix; s4_bias <= s3_bias;
                        s4_t0 <= s3_s[0] + s3_s[1]; s4_t1 <= s3_s[2] + s3_s[3]; s4_t2 <= s3_s[4] + s3_s[5];
                    end else s4_v <= 1'b0;
                end

                if (s5_rdy) begin
                    if (s4_v) begin
                        s5_v <= 1'b1; s5_och <= s4_och; s5_pix <= s4_pix;
                        s5_sum_bias <= (s4_t0 + s4_t1) + s4_t2 + sext32_to_acc(s4_bias);
                    end else s5_v <= 1'b0;
                end

                if (s6_rdy) begin
                    if (s5_v) begin
                        s6_v <= 1'b1; s6_och <= s5_och; s6_pix <= s5_pix;
                        if (OUT_SHIFT == 0) s6_xs <= s5_sum_bias;
                        else                s6_xs <= s5_rounded_sum >>> OUT_SHIFT;
                    end else s6_v <= 1'b0;
                end

                if (out_ready || !out_valid) begin
                    if (skid_full) begin
                        out_valid <= 1'b1; out_och <= skid_och; out_pix_idx <= skid_pix; out_data <= skid_data; skid_full <= 1'b0; 
                    end else if (s6_v) begin
                        out_valid <= 1'b1; out_och <= s6_och; out_pix_idx <= s6_pix; out_data <= relu_sat13_from_acc(s6_xs);
                    end else begin
                        out_valid <= 1'b0;
                    end
                end else begin
                    if (s6_v && pipe_en) begin
                        skid_full <= 1'b1; skid_och <= s6_och; skid_pix <= s6_pix; skid_data <= relu_sat13_from_acc(s6_xs);
                    end
                end

                if (out_valid && out_ready && (out_och == 8'd143)) begin
                    if (rd_sel_0 == 1'b0) buf_full0 <= 1'b0;
                    else                  buf_full1 <= 1'b0;
                    if (other_full) begin
                        rd_sel_0 <= ~rd_sel_0; rd_sel_1 <= ~rd_sel_1; rd_sel_2 <= ~rd_sel_2;
                        rd_sel_3 <= ~rd_sel_3; rd_sel_4 <= ~rd_sel_4; rd_sel_5 <= ~rd_sel_5;
                        run <= 1'b1; issued_all <= 1'b0;
                    end else begin
                        run <= 1'b0; issued_all <= 1'b0; cap_pending <= 1'b0;
                    end
                end
            end 
        end
    end
endmodule
module bias144_i32_rom #(
    parameter BIAS_MEM_FILE = "E:/Desktop/ip_ring/save_to_FPGA/stage2/block1/ffn/expand_mem/bias144_i32.mem"
)(
    input  wire        clk,
    input  wire [7:0]  addr,    // Expanded to 8 bits for 144
    output reg  [7:0]  addr_q,
    output reg  [31:0] dout
);
    //localparam BIAS_MEM_FILE = "E:/Desktop/ip_ring/save_to_FPGA/stage2/block1/ffn/expand_mem/bias144_i32.mem";
    
    reg [31:0] mem [0:143];     // Depth updated to 144

    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0] data_pipe;
    reg [7:0]  addr_pipe;
    
    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout      <= data_pipe;
        addr_q    <= addr_pipe;
    end
endmodule

// ============================================================
// 2. PW Expansion Weights ROM (48 ic -> 144 oc)
// ============================================================
module pw_gbank144x16_to768_rom #(
    parameter MEM = "E:/Desktop/ip_ring/save_to_FPGA/stage2/block1/ffn/expand_mem/stage2b1pw.mem"
)(
    input  wire         clk,
    input  wire [7:0]   addr,    // Expanded to 8 bits for 144
    output reg  [7:0]   addr_q,
    output reg  [767:0] dout     // 48 in_channels * 16 bits = 768 bits
);
    //localparam MEM = "E:/Desktop/ip_ring/save_to_FPGA/stage2/block1/ffn/expand_mem/stage2b1pw.mem";
    
    reg [767:0] mem [0:143];     // Depth updated to 144
    
    initial begin
         $readmemh(MEM, mem);
    end
    
    reg [767:0] data_pipe;
    reg [7:0]   addr_pipe;
    
    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout      <= data_pipe;
        addr_q    <= addr_pipe;
    end
endmodule