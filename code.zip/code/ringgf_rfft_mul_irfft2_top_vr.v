`timescale 1ns/1ps
`default_nettype none

module ringgf_rfft_mul_irfft2_top_vr #(
    parameter integer H                      = 32,
    parameter integer W                      = 32,
    parameter integer C                      = 32,
    parameter integer IN_DW                  = 12,
    parameter integer FFTW                   = 16,
    parameter integer OUT_DW                 = 12,
    parameter [9:0]   RFFT_ROW_SCALE_SCH10   = 10'b0000000000,
    parameter [9:0]   RFFT_COL_SCALE_SCH10   = 10'b0000000001,
    parameter [9:0]   IRFFT_COL_IFFT_SCALE_SCH10 = 10'b0000000000,
    parameter [9:0]   IRFFT_ROW_IFFT_SCALE_SCH10 = 10'b1111100001,
    parameter integer DBG_EN                 = 1,
    parameter integer DBG_MAX                = 256,
    parameter         PY_MODE                = 1'b1
)(
    input  wire                  clk,
    input  wire                  rst_n,

    input  wire                  s_valid,
    output wire                  s_ready,
    input  wire [9:0]            s_pix_idx,
    input  wire [5:0]            s_och,
    input  wire [IN_DW-1:0]      s_data,

    output wire                  m_valid,
    input  wire                  m_ready,
    output wire [9:0]            m_pix_idx,
    output wire [5:0]            m_och,
    output wire [OUT_DW-1:0]     m_data,
    output wire                  m_last
);

    localparam integer PIXN = H * W;

    // --------------------------------------------------------
    // Store (input frame buffer + RMW read/modify/write)
    // --------------------------------------------------------
    wire                  store_frame_full;
    wire                  st_rd_en;
    wire [9:0]            st_rd_pix_idx;
    wire [5:0]            st_rd_och;
    wire                  st_rd_valid;
    wire [IN_DW-1:0]      st_rd_data;

    wire                  rb_en;
    wire                  rb_we;
    wire [9:0]            rb_pix_idx;
    wire [5:0]            rb_och;
    wire [IN_DW-1:0]      rb_wdata;
    wire                  rb_valid;
    wire [IN_DW-1:0]      rb_rdata;

    bn_a_store12_frame_vr #(
        .H(H), .W(W), .C(C), .DW(IN_DW)
    ) u_store (
        .clk        (clk),
        .rst_n      (rst_n),
        .clr_frame  (1'b0),
        .allow_overwrite (1'b0),

        .s_valid    (s_valid),
        .s_ready    (s_ready),
        .s_pix_idx  (s_pix_idx),
        .s_och      (s_och),
        .s_data     (s_data),
        .frame_full (store_frame_full),

        .rd_en      (st_rd_en),
        .rd_pix_idx (st_rd_pix_idx),
        .rd_och     (st_rd_och),
        .rd_valid   (st_rd_valid),
        .rd_data    (st_rd_data),

        .rb_en      (rb_en),
        .rb_we      (rb_we),
        .rb_pix_idx (rb_pix_idx),
        .rb_och     (rb_och),
        .rb_wdata   (rb_wdata),
        .rb_valid   (rb_valid),
        .rb_rdata   (rb_rdata)
    );

    // --------------------------------------------------------
    // Shared rd_* controls into store (BN prefetch OR OUT_READ)
    // --------------------------------------------------------
    reg                 st_rd_en_r;
    reg  [9:0]          st_rd_pix_idx_r;
    reg  [5:0]          st_rd_och_r;

    assign st_rd_en      = st_rd_en_r;
    assign st_rd_pix_idx = st_rd_pix_idx_r;
    assign st_rd_och     = st_rd_och_r;

    // --------------------------------------------------------
    // BN prefetch from store (2-entry reg FIFO)
    // --------------------------------------------------------
    reg  [9:0]          rd_pix_d;
    reg  [5:0]          rd_och_d;
    reg                 rd_pending;

    reg [9:0]           iss_pix_cnt;
    reg [5:0]           iss_och_cnt;
    reg                 issued_all;
    reg                 bn_done;

    reg                 q0_v, q1_v;
    reg  [9:0]          q0_pix, q1_pix;
    reg  [5:0]          q0_och, q1_och;
    reg  [IN_DW-1:0]    q0_dat, q1_dat;

    wire                bn_fifo_full  = q0_v && q1_v;
    wire                bn_fifo_empty = !q0_v;

    wire                 bn_in_valid = q0_v;
    wire                 bn_in_ready;
    wire                 bn_in_fire  = bn_in_valid && bn_in_ready;

    wire [5:0]           bn_in_och     = q0_och;
    wire [9:0]           bn_in_pix_idx = q0_pix;
    wire signed [15:0]   bn_in_data    = $signed({{(16-IN_DW){q0_dat[IN_DW-1]}}, q0_dat});

    wire                 bn_out_valid;
    wire                 bn_out_ready;
    wire [5:0]           bn_out_och;
    wire [9:0]           bn_out_pix_idx;
    wire signed [15:0]   bn_out_data;

    bn_affine32_vr #(
        .ROM_LAT(1),
        .FX(8),
        .FY(8),
        .FA(11),
        .USE_RELU(0)
    ) u_bn (
        .clk        (clk),
        .rst_n      (rst_n),
        .in_valid   (bn_in_valid),
        .in_ready   (bn_in_ready),
        .in_och     (bn_in_och),
        .in_pix_idx (bn_in_pix_idx),
        .in_data    (bn_in_data),

        .out_valid  (bn_out_valid),
        .out_ready  (bn_out_ready),
        .out_och    (bn_out_och),
        .out_pix_idx(bn_out_pix_idx),
        .out_data   (bn_out_data)
    );

    // --------------------------------------------------------
    // RFFT -> MUL -> IRFFT chain (unchanged wiring)
    // --------------------------------------------------------
    wire                 rfft_s_valid = bn_out_valid;
    wire                 rfft_s_ready;
    assign               bn_out_ready = rfft_s_ready;

    wire [9:0]           rfft_s_pix   = bn_out_pix_idx;
    wire [5:0]           rfft_s_och   = bn_out_och;
    wire [15:0]          rfft_s_data  = bn_out_data;

    wire                 rfft_m_valid;
    wire                 rfft_m_ready;
    wire [5:0]           rfft_m_och;
    wire [4:0]           rfft_m_ky;
    wire [4:0]           rfft_m_kx;
    wire [15:0]          rfft_m_re;
    wire [15:0]          rfft_m_im;
    wire                 rfft_m_last;

    rfft2_32x32_half_stream_in16_vr #(
        .H(H), .W(W), .C(C),
        .ROW_SCALE_SCH10(RFFT_ROW_SCALE_SCH10),
        .COL_SCALE_SCH10(RFFT_COL_SCALE_SCH10),
        .DBG_EN(0),
        .PY_MODE(PY_MODE)
    ) u_rfft2 (
        .clk        (clk),
        .rst_n      (rst_n),
        .clr_frame  (1'b0),

        .s_valid    (rfft_s_valid),
        .s_ready    (rfft_s_ready),
        .s_pix_idx  (rfft_s_pix),
        .s_och      (rfft_s_och),
        .s_data     (rfft_s_data),
        .busy       (),

        .m_valid    (rfft_m_valid),
        .m_ready    (rfft_m_ready),
        .m_och      (rfft_m_och),
        .m_ky       (rfft_m_ky),
        .m_kx       (rfft_m_kx),
        .m_re       (rfft_m_re),
        .m_im       (rfft_m_im),
        .m_last     (rfft_m_last)
    );

    wire                 mul_s_valid = rfft_m_valid;
    wire                 mul_s_ready;
    assign               rfft_m_ready = mul_s_ready;

    wire                 mul_m_valid;
    wire                 mul_m_ready;
    wire [5:0]           mul_m_och;
    wire [4:0]           mul_m_ky;
    wire [4:0]           mul_m_kx;
    wire [15:0]          mul_m_re;
    wire [15:0]          mul_m_im;
    wire                 mul_m_last;

    ringmul_band_ck_stage_vr #(
        .H(H), .W(W), .Wc((W/2)+1), .C(C),
        .K(8),
        .DW(16),
        .FQ(15),
        .DBG_EN(0),
        .DBG_MAX(0)
    ) u_mul (
        .clk        (clk),
        .rst_n      (rst_n),

        .s_valid    (mul_s_valid),
        .s_ready    (mul_s_ready),
        .s_och      (rfft_m_och),
        .s_ky       (rfft_m_ky),
        .s_kx       (rfft_m_kx),
        .s_re       (rfft_m_re),
        .s_im       (rfft_m_im),
        .s_last     (rfft_m_last),

        .m_valid    (mul_m_valid),
        .m_ready    (mul_m_ready),
        .m_och      (mul_m_och),
        .m_ky       (mul_m_ky),
        .m_kx       (mul_m_kx),
        .m_re       (mul_m_re),
        .m_im       (mul_m_im),
        .m_last     (mul_m_last)
    );

    wire                 ir_s_valid = mul_m_valid;
    wire                 ir_s_ready;
    assign               mul_m_ready = ir_s_ready;

    wire                 ir_m_valid;
    wire                 ir_m_ready;
    wire [9:0]           ir_m_pix_idx;
    wire [5:0]           ir_m_och;
    wire [OUT_DW-1:0]    ir_m_data;
    wire                 ir_m_last;

    irfft2_32x32_half_in16_out12_vr #(
        .H(H), .W(W), .C(C),
        .IN_DW(16),
        .OUT_DW(OUT_DW),
        .COL_IFFT_SCALE_SCH10(IRFFT_COL_IFFT_SCALE_SCH10),
        .ROW_IFFT_SCALE_SCH10(IRFFT_ROW_IFFT_SCALE_SCH10),
        .OUT_RSHIFT(0),
        .PY_MODE(PY_MODE)
    ) u_irfft2 (
        .clk        (clk),
        .rst_n      (rst_n),

        .s_valid    (ir_s_valid),
        .s_ready    (ir_s_ready),
        .s_och      (mul_m_och),
        .s_ky       (mul_m_ky),
        .s_kx       (mul_m_kx),
        .s_re       (mul_m_re),
        .s_im       (mul_m_im),

        .m_valid    (ir_m_valid),
        .m_ready    (ir_m_ready),
        .m_pix_idx  (ir_m_pix_idx),
        .m_och      (ir_m_och),
        .m_data     (ir_m_data),
        .m_last     (ir_m_last),
        .busy       ()
    );

    // --------------------------------------------------------
    // IRFFT -> RMW decouple FIFO (2-entry regs)
    // --------------------------------------------------------
    reg                 irq0_v, irq1_v;
    reg  [9:0]          irq0_pix, irq1_pix;
    reg  [5:0]          irq0_och, irq1_och;
    reg  [OUT_DW-1:0]   irq0_dat, irq1_dat;
    reg                 irq0_last, irq1_last;

    wire                ir_fifo_full  = irq0_v && irq1_v;
    wire                ir_fifo_empty = !irq0_v;

    assign              ir_m_ready = !ir_fifo_full;

    // --------------------------------------------------------
    // RMW FSM: read old, add ifft, write back to store
    // --------------------------------------------------------
    localparam [1:0] RMW_IDLE  = 2'd0;
    localparam [1:0] RMW_WAIT  = 2'd1;

    reg [1:0]            rmw_st;
    reg [9:0]            rmw_pix;
    reg [5:0]            rmw_och;
    reg [OUT_DW-1:0]     rmw_ifft;
    reg                  rmw_last_hold;

    reg                  rb_en_r;
    reg                  rb_we_r;
    reg [9:0]            rb_pix_r;
    reg [5:0]            rb_och_r;
    reg [IN_DW-1:0]      rb_wdata_r;

    assign rb_en      = rb_en_r;
    assign rb_we      = rb_we_r;
    assign rb_pix_idx = rb_pix_r;
    assign rb_och     = rb_och_r;
    assign rb_wdata   = rb_wdata_r;

    wire signed [OUT_DW-1:0] raw12_s  = $signed(rb_rdata);
    wire signed [OUT_DW-1:0] ifft12_s = $signed(rmw_ifft);
    wire signed [OUT_DW:0]   sum13_s  =
        $signed({raw12_s[OUT_DW-1],  raw12_s}) +
        $signed({ifft12_s[OUT_DW-1], ifft12_s});
    wire [OUT_DW-1:0] sum12 = sum13_s[OUT_DW-1:0];

    // --------------------------------------------------------
    // OUT_READ: reorder output as (pix outer, och inner)
    // --------------------------------------------------------
    localparam [1:0] OUT_IDLE = 2'd0;
    localparam [1:0] OUT_RUN  = 2'd1;
    localparam [1:0] OUT_DONE = 2'd2;

    reg [1:0] out_st;
    reg       rmw_done;

    // issue counters advance on rd_en ONLY
    reg [9:0]  out_iss_pix;
    reg [5:0]  out_iss_och;
    reg [15:0] out_iss_cnt;

    reg        out_rd_pending;
    reg [9:0]  out_rd_pix_d;
    reg [5:0]  out_rd_och_d;

    // 2-deep skid buffer for m_*
    reg                  m_valid_r;
    reg [9:0]            m_pix_r;
    reg [5:0]            m_och_r;
    reg [OUT_DW-1:0]     m_data_r;
    reg                  m_last_r;

    reg                  pend_v;
    reg [9:0]            pend_pix;
    reg [5:0]            pend_och;
    reg [OUT_DW-1:0]     pend_data;
    reg                  pend_last;

    assign m_valid   = m_valid_r;
    assign m_pix_idx = m_pix_r;
    assign m_och     = m_och_r;
    assign m_data    = m_data_r;
    assign m_last    = m_last_r;

    wire out_slot0_free = (!m_valid_r) || (m_valid_r && m_ready);
    wire out_slot1_free = !pend_v;
    wire out_has_space  = out_slot0_free || out_slot1_free;

    integer dbg_n;

    // --------------------------------------------------------
    // Sequential logic
    // --------------------------------------------------------
    always @(posedge clk) begin
        if (!rst_n) begin
            st_rd_en_r      <= 1'b0;
            st_rd_pix_idx_r <= 10'd0;
            st_rd_och_r     <= 6'd0;

            rd_pix_d        <= 10'd0;
            rd_och_d        <= 6'd0;
            rd_pending      <= 1'b0;

            iss_pix_cnt     <= 10'd0;
            iss_och_cnt     <= 6'd0;
            issued_all      <= 1'b0;
            bn_done         <= 1'b0;

            q0_v            <= 1'b0;
            q1_v            <= 1'b0;
            q0_pix          <= 10'd0;
            q0_och          <= 6'd0;
            q0_dat          <= {IN_DW{1'b0}};
            q1_pix          <= 10'd0;
            q1_och          <= 6'd0;
            q1_dat          <= {IN_DW{1'b0}};

            irq0_v          <= 1'b0;
            irq1_v          <= 1'b0;
            irq0_pix        <= 10'd0;
            irq0_och        <= 6'd0;
            irq0_dat        <= {OUT_DW{1'b0}};
            irq0_last       <= 1'b0;
            irq1_pix        <= 10'd0;
            irq1_och        <= 6'd0;
            irq1_dat        <= {OUT_DW{1'b0}};
            irq1_last       <= 1'b0;

            rmw_st          <= RMW_IDLE;
            rmw_pix         <= 10'd0;
            rmw_och         <= 6'd0;
            rmw_ifft        <= {OUT_DW{1'b0}};
            rmw_last_hold   <= 1'b0;

            rb_en_r         <= 1'b0;
            rb_we_r         <= 1'b0;
            rb_pix_r        <= 10'd0;
            rb_och_r        <= 6'd0;
            rb_wdata_r      <= {IN_DW{1'b0}};

            out_st          <= OUT_IDLE;
            rmw_done        <= 1'b0;

            out_iss_pix     <= 10'd0;
            out_iss_och     <= 6'd0;
            out_iss_cnt     <= 16'd0;

            out_rd_pending  <= 1'b0;
            out_rd_pix_d    <= 10'd0;
            out_rd_och_d    <= 6'd0;

            m_valid_r       <= 1'b0;
            m_pix_r         <= 10'd0;
            m_och_r         <= 6'd0;
            m_data_r        <= {OUT_DW{1'b0}};
            m_last_r        <= 1'b0;

            pend_v          <= 1'b0;
            pend_pix        <= 10'd0;
            pend_och        <= 6'd0;
            pend_data       <= {OUT_DW{1'b0}};
            pend_last       <= 1'b0;

            dbg_n           <= 0;
        end else begin
            // defaults
            st_rd_en_r <= 1'b0;
            rb_en_r    <= 1'b0;
            rb_we_r    <= 1'b0;

            // output skid
            if (m_valid_r && m_ready) begin
                m_valid_r <= 1'b0;
                m_last_r  <= 1'b0;
            end
            if (!m_valid_r && pend_v) begin
                m_valid_r <= 1'b1;
                m_pix_r   <= pend_pix;
                m_och_r   <= pend_och;
                m_data_r  <= pend_data;
                m_last_r  <= pend_last;
                pend_v    <= 1'b0;
            end

            // BN prefetch (only before OUT_READ starts)
            if (!bn_done && store_frame_full && (out_st == OUT_IDLE)) begin
                if (!issued_all && !bn_fifo_full && !rd_pending) begin
                    st_rd_en_r      <= 1'b1;
                    st_rd_pix_idx_r <= iss_pix_cnt;
                    st_rd_och_r     <= iss_och_cnt;
                    rd_pix_d        <= iss_pix_cnt;
                    rd_och_d        <= iss_och_cnt;
                    rd_pending      <= 1'b1;

                    if (iss_pix_cnt == (PIXN-1)) begin
                        iss_pix_cnt <= 10'd0;
                        if (iss_och_cnt == (C-1)) begin
                            iss_och_cnt <= 6'd0;
                            issued_all  <= 1'b1;
                        end else begin
                            iss_och_cnt <= iss_och_cnt + 6'd1;
                        end
                    end else begin
                        iss_pix_cnt <= iss_pix_cnt + 10'd1;
                    end
                end

                if (st_rd_valid) begin
                    rd_pending <= 1'b0;
                    if (!q0_v) begin
                        q0_v   <= 1'b1;
                        q0_pix <= rd_pix_d;
                        q0_och <= rd_och_d;
                        q0_dat <= st_rd_data;
                    end else if (!q1_v) begin
                        q1_v   <= 1'b1;
                        q1_pix <= rd_pix_d;
                        q1_och <= rd_och_d;
                        q1_dat <= st_rd_data;
                    end
                end

                if (bn_in_fire) begin
                    if (q1_v) begin
                        q0_pix <= q1_pix;
                        q0_och <= q1_och;
                        q0_dat <= q1_dat;
                        q0_v   <= 1'b1;
                        q1_v   <= 1'b0;
                    end else begin
                        q0_v   <= 1'b0;
                    end
                end

                if (issued_all && !rd_pending && bn_fifo_empty) begin
                    bn_done <= 1'b1;
                end
            end

            // push IRFFT outputs into ir_fifo
            if (ir_m_valid && ir_m_ready) begin
                if (!irq0_v) begin
                    irq0_v    <= 1'b1;
                    irq0_pix  <= ir_m_pix_idx;
                    irq0_och  <= ir_m_och;
                    irq0_dat  <= ir_m_data;
                    irq0_last <= ir_m_last;
                end else if (!irq1_v) begin
                    irq1_v    <= 1'b1;
                    irq1_pix  <= ir_m_pix_idx;
                    irq1_och  <= ir_m_och;
                    irq1_dat  <= ir_m_data;
                    irq1_last <= ir_m_last;
                end
            end

            // RMW FSM
            case (rmw_st)
                RMW_IDLE: begin
                    if (!rmw_done && !ir_fifo_empty) begin
                        rmw_pix       <= irq0_pix;
                        rmw_och       <= irq0_och;
                        rmw_ifft      <= irq0_dat;
                        rmw_last_hold <= irq0_last;

                        if (irq1_v) begin
                            irq0_v    <= 1'b1;
                            irq0_pix  <= irq1_pix;
                            irq0_och  <= irq1_och;
                            irq0_dat  <= irq1_dat;
                            irq0_last <= irq1_last;
                            irq1_v    <= 1'b0;
                        end else begin
                            irq0_v    <= 1'b0;
                        end

                        rb_en_r  <= 1'b1;
                        rb_we_r  <= 1'b0;
                        rb_pix_r <= irq0_pix;
                        rb_och_r <= irq0_och;

                        rmw_st <= RMW_WAIT;
                    end
                end

                RMW_WAIT: begin
                    if (rb_valid) begin
                        rb_en_r    <= 1'b1;
                        rb_we_r    <= 1'b1;
                        rb_pix_r   <= rmw_pix;
                        rb_och_r   <= rmw_och;
                        rb_wdata_r <= sum12;

                        if (rmw_last_hold) rmw_done <= 1'b1;

                        if ((DBG_EN != 0) && (dbg_n < DBG_MAX)) begin
                            $display("[RMW] och=%0d pix=%0d RAW=%0d IFFT=%0d SUM=%0d",
                                rmw_och, rmw_pix,
                                $signed(rb_rdata), $signed(rmw_ifft), $signed(sum12));
                            dbg_n <= dbg_n + 1;
                        end

                        rmw_st <= RMW_IDLE;
                    end
                end

                default: rmw_st <= RMW_IDLE;
            endcase

            // OUT_READ
            case (out_st)
                OUT_IDLE: begin
                    if (rmw_done) begin
                        out_st         <= OUT_RUN;
                        out_iss_pix    <= 10'd0;
                        out_iss_och    <= 6'd0;
                        out_iss_cnt    <= 16'd0;
                        out_rd_pending <= 1'b0;
                    end
                end

                OUT_RUN: begin
                    if (!out_rd_pending && out_has_space) begin
                        st_rd_en_r      <= 1'b1;
                        st_rd_pix_idx_r <= out_iss_pix;
                        st_rd_och_r     <= out_iss_och;

                        out_rd_pix_d    <= out_iss_pix;
                        out_rd_och_d    <= out_iss_och;
                        out_rd_pending  <= 1'b1;

                        if (out_iss_och == (C-1)) begin
                            out_iss_och <= 6'd0;
                            out_iss_pix <= out_iss_pix + 10'd1;
                        end else begin
                            out_iss_och <= out_iss_och + 6'd1;
                        end
                        out_iss_cnt <= out_iss_cnt + 16'd1;
                    end

                    if (st_rd_valid) begin
                        out_rd_pending <= 1'b0;

                        if (!m_valid_r) begin
                            m_valid_r <= 1'b1;
                            m_pix_r   <= out_rd_pix_d;
                            m_och_r   <= out_rd_och_d;
                            m_data_r  <= st_rd_data[OUT_DW-1:0];
                            m_last_r  <= (out_rd_pix_d == (PIXN-1)) && (out_rd_och_d == (C-1));
                        end else if (!pend_v) begin
                            pend_v    <= 1'b1;
                            pend_pix  <= out_rd_pix_d;
                            pend_och  <= out_rd_och_d;
                            pend_data <= st_rd_data[OUT_DW-1:0];
                            pend_last <= (out_rd_pix_d == (PIXN-1)) && (out_rd_och_d == (C-1));
                        end
                    end

                    if (m_valid_r && m_ready && m_last_r) begin
                        out_st <= OUT_DONE;
                    end
                end

                OUT_DONE: begin
                    out_st <= OUT_DONE;
                end

                default: out_st <= OUT_IDLE;
            endcase
        end
    end

endmodule

`default_nettype wire
