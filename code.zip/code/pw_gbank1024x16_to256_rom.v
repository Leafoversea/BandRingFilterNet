`timescale 1ns/1ps
`default_nettype none

module pw_gbank1024x16_to256_rom(
    input  wire        clk,
    input  wire [6:0]  addr,    // 地址位宽从 5bit (32深度) 扩展为 7bit (128深度)
    output reg  [6:0]  addr_q,   
    output reg  [255:0] dout    // 输出位宽从 1024bit 降为 256bit
);
    localparam MEM_BASE_PATH = "E:/Desktop/ring2/save_to_FPGA/stem/fold_stem_to_C1_mem/stemc.mem";
    // 强制使用 BRAM，定义 128 深度 × 256 位宽的存储器
    (* ram_style = "block" *) reg [255:0] mem [0:127];
    initial begin
        $readmemh(MEM_BASE_PATH, mem);
    end
    // 流水线寄存器位宽同步更新
    reg [255:0] data_pipe;
    reg [6:0]   addr_pipe;
    
    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule

`default_nettype wire

module bias32x32_i32_rom (
    input  wire        clk,
    input  wire [4:0]  addr,
    output reg  [4:0]  addr_q,   
    output reg  [31:0] dout
);
    localparam BIAS_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stem/fold_stem_to_C1_mem/bias32_i32.mem";
    reg [31:0] mem [0:31];
    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0] data_pipe;
    reg [4:0]  addr_pipe;

    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule

