`timescale 1ns/1ps

module stem_top_tb;

    // Clock and reset signals
    reg clk_in1;
    reg rst_n;

    // Instantiate the DUT (Device Under Test)
    //wire [23:0] rom_data;
    // wire [23:0] pool_data;
    // wire        pool_pulse;
    // wire        pool_sof_out;
    // wire        pool_eof_out;
    wire        stem_pulse;
    wire [4:0]  stem_och;
    wire [11:0] stem_pix_idx;
    wire [10:0] stem_data;
    //wire        frame_done_pulse;
    wire        drop_pulse;
    //wire        fifo_overflow_pulse;

    stem_top uut (
        .clk              (clk_in1),
        .rst_n            (rst_n),
        //.rom_data         (rom_data),
        // .pool_data        (pool_data),
        // .pool_pulse       (pool_pulse),
        // .pool_sof_out     (pool_sof_out),
        // .pool_eof_out     (pool_eof_out),
        .stem_pulse       (stem_pulse),
        .stem_och         (stem_och),
        .stem_pix_idx     (stem_pix_idx),
        .stem_data        (stem_data),
        //.frame_done_pulse (frame_done_pulse),
        .drop_pulse       (drop_pulse)
    );

    // Clock generation (1ns period, 500MHz clock)
    initial begin
        clk_in1 = 1'b0;
        forever #1 clk_in1 = ~clk_in1; 
    end

    // Reset pulse
    initial begin
        rst_n = 1'b0;
        #20;
        rst_n = 1'b1;
    end

    // File handling for writing stem_data as signed decimal
    integer coe_file;
    integer sign_data;
    initial begin
        // Open the .coe file (create if not exists)
        coe_file = $fopen("E:/region/python/coe/stem_data.coe", "w");
        if (coe_file == 0) begin
            $display("Error opening the file!");
            $finish;
        end
        $fwrite(coe_file, "dtype=int16 N=1 C=32 H=32 W=32 F=8\n");
        $fwrite(coe_file, "pix_idx och val_hex val_dec\n");
    end

    // Record stem_data in .coe file when stem_pulse is high
    always @(posedge stem_pulse) begin
            // Convert the 32-bit stem_data to signed decimal
            sign_data = $signed(stem_data);
            // Write the signed decimal value to the .coe file
            $fwrite(coe_file, "%0d %0d 0x%04h %0d\n", stem_pix_idx, stem_och,stem_data[10:0], sign_data);
            if(stem_och==6'h1f&&stem_pix_idx==12'h3ff)begin
                #1;
                $fclose(coe_file);
                $finish;
            end
    end

endmodule
