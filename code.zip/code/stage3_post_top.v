`timescale 1ns / 1ps

module stage3_post_top (
    input  wire                     clk,
    input  wire                     rst_n,

    input  wire                     s_valid,
    output wire                     s_ready,
    input  wire [5:0]               s_pix_idx,
    input  wire [5:0]               s_och,
    input  wire signed [12:0]       s_data,
    input  wire                     s_last,

    output wire                 m_valid,
    output wire  [7:0]          led_out 
);

    // ------------------------------------------------------------
    // GAP -> FC
    // ------------------------------------------------------------
    wire                     gap_valid;
    wire                     gap_ready;
    wire [0:0]               gap_pix_idx;
    wire [5:0]               gap_och;
    wire signed [15:0]       gap_data;
    wire                     gap_last;

    // ------------------------------------------------------------
    // FC -> calibrator
    // ------------------------------------------------------------
    wire                     fc_valid;
    wire                     fc_ready;
    wire [0:0]               fc_pix_idx;
    wire [2:0]               fc_och;
    wire signed [31:0]       fc_data;
    wire                     fc_last;

    // ------------------------------------------------------------
    // calibrator -> softmax
    // ------------------------------------------------------------
    wire                     cal_valid;
    //wire                     cal_ready;
    wire [0:0]               cal_pix_idx;
    wire [2:0]               cal_och;
    wire signed [31:0]       cal_data;
    wire                     cal_last;

    // ============================================================
    // 1) GAP
    // ============================================================
    gap8x8_stream #(
        .C      (64),
        .H      (8),
        .W      (8),
        .IN_W   (13),
        .OUT_W  (16),
        .PIX_W  (6),
        .CH_W   (6)
    ) u_gap8x8_stream (
        .clk      (clk),
        .rst_n    (rst_n),

        .s_valid  (s_valid),
        .s_ready  (s_ready),
        .s_pix_idx(s_pix_idx),
        .s_och    (s_och),
        .s_data   (s_data),
        .s_last   (s_last),

        .m_valid  (gap_valid),
        .m_ready  (gap_ready),
        .m_pix_idx(gap_pix_idx),
        .m_och    (gap_och),
        .m_data   (gap_data),
        .m_last   (gap_last)
    );

    // ============================================================
    // 2) FC
    // ============================================================
    fc64x8_stream u_fc64x8_stream (
        .clk      (clk),
        .rst_n    (rst_n),

        .s_valid  (gap_valid),
        .s_ready  (gap_ready),
        .s_pix_idx(gap_pix_idx),
        .s_och    (gap_och),
        .s_data   (gap_data),
        .s_last   (gap_last),

        .m_valid  (fc_valid),
        .m_ready  (fc_ready),
        .m_pix_idx(fc_pix_idx),
        .m_och    (fc_och),
        .m_data   (fc_data),
        .m_last   (fc_last)
    );

    // ============================================================
    // 3) Calibrator
    // ============================================================
    calibrator8x8_stream u_calibrator8x8_stream (
        .clk      (clk),
        .rst_n    (rst_n),

        .s_valid  (fc_valid),
        .s_ready  (fc_ready),
        .s_pix_idx(fc_pix_idx),
        .s_och    (fc_och),
        .s_data   (fc_data),
        .s_last   (fc_last),

        .m_valid  (cal_valid),
        .m_ready  (1'b1),
        .m_pix_idx(cal_pix_idx),
        .m_och    (cal_och),
        .m_data   (cal_data),
        .m_last   (cal_last)
    );

    // ============================================================
    // 4) Softmax
    // ============================================================
    softmax8_stream u_softmax8_stream (
        .clk      (clk),
        .rst_n    (rst_n),

        .s_valid  (cal_valid),
        //.s_ready  (cal_ready),
        .s_pix_idx(cal_pix_idx),
        .s_och    (cal_och),
        .s_data   (cal_data),
        .s_last   (cal_last),

        .m_valid  (m_valid),
        .led_out  (led_out)
    );

endmodule
