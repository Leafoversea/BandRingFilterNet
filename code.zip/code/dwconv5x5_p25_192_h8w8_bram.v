`timescale 1ns/1ps
`default_nettype none

module dwconv5x5_p25_192_h8w8_bram #(
    parameter integer H              = 8,
    parameter integer W              = 8,
    parameter integer PAD            = 2,
    parameter integer OUT_SHIFT      = 10,
    parameter integer USE_RELU       = 1,
    parameter integer OUT_FIFO_DEPTH = 16,
    parameter MEM = "",
    parameter BIAS = ""
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire                 in_valid,
    output wire                 in_ready,
    input  wire [7:0]           in_och,
    input  wire [9:0]           in_pix_idx,
    input  wire signed [12:0] in_data,

    output wire                 out_valid,
    input  wire                 out_ready,
    output wire [7:0]           out_och,
    output wire [9:0]           out_pix_idx,
    output wire signed [12:0] out_data,
    output wire                 out_last
);
    localparam [5:0] X_MAX_EX  = W[5:0];
    localparam [5:0] Y_MAX_EX  = H[5:0];
    localparam [5:0] WP2       = (W + PAD);
    localparam [5:0] HP2       = (H + PAD);

    localparam integer DEPTH_ROW = (W*192);
    localparam integer ADDR_W    = 11;
    localparam integer ACC_W     = 40;
    localparam integer BIAS_W    = 20;

    function integer clog2_int;
        input integer v;
        integer r;
        begin
            r = 0;
            v = v - 1;
            while (v > 0) begin
                v = v >> 1;
                r = r + 1;
            end
            clog2_int = r;
        end
    endfunction

    localparam integer FIFO_AW = clog2_int(OUT_FIFO_DEPTH);

    reg [FIFO_AW-1:0] fifo_wptr, fifo_rptr;
    reg [FIFO_AW:0]   fifo_count;

    (* ram_style = "distributed" *) reg [7:0]         fifo_och   [0:OUT_FIFO_DEPTH-1];
    (* ram_style = "distributed" *) reg [9:0]         fifo_pix   [0:OUT_FIFO_DEPTH-1];
    (* ram_style = "distributed" *) reg signed [12:0] fifo_dat   [0:OUT_FIFO_DEPTH-1];
    (* ram_style = "distributed" *) reg               fifo_lastb [0:OUT_FIFO_DEPTH-1];
    
    wire fifo_empty = (fifo_count == 0);
    wire fifo_full  = (fifo_count == OUT_FIFO_DEPTH[FIFO_AW:0]);

    assign out_valid   = !fifo_empty;
    assign out_och     = fifo_och[fifo_rptr];
    assign out_pix_idx = fifo_pix[fifo_rptr];
    assign out_data    = fifo_dat[fifo_rptr];
    assign out_last    = fifo_lastb[fifo_rptr];

    wire fifo_pop = out_ready && out_valid;

    reg [5:0] x_scan;
    reg [5:0] y_scan;
    reg [7:0] c_scan;

    wire x_in_rng   = (x_scan < X_MAX_EX);
    wire y_in_rng   = (y_scan < Y_MAX_EX);
    wire need_input = x_in_rng && y_in_rng;

    wire bottom_pad_row = (y_scan >= Y_MAX_EX);
    wire x_real_col     = x_in_rng;
    wire out_en0 = (x_scan >= 6'd2) && (x_scan < (W[5:0] + 6'd2)) &&
                   (y_scan >= 6'd2) && (y_scan < (H[5:0] + 6'd2));
    wire [5:0] out_x0_u = x_scan - 6'd2;
    wire [5:0] out_y0_u = y_scan - 6'd2;
    wire [9:0] out_pix0 = out_y0_u * W + out_x0_u;
    wire last0 = out_en0 && (out_pix0 == (H*W-1)) && (c_scan == 8'd191);
    
    localparam integer PIPE_LEN = 1;
    localparam integer SHIFT    = PIPE_LEN - 1;

    reg [FIFO_AW:0] inflight_out;
    wire can_accept = ((fifo_count + inflight_out) < OUT_FIFO_DEPTH[FIFO_AW:0]);

    reg       clr_active;
    reg [7:0] clr_addr;
    wire accept_step_raw = can_accept && (need_input ? (in_valid && in_ready) : 1'b1);
    wire accept_step     = (!clr_active) && accept_step_raw;

    assign in_ready = (!clr_active) && can_accept && need_input;
    wire in_fire = in_valid && in_ready;

    wire signed [12:0] sample_cur = need_input ? in_data : 13'sd0;
    wire wr_data_real   = accept_step && need_input;
    wire wr_zero_bottom = accept_step && bottom_pad_row && x_real_col;
    wire wr_en          = wr_data_real || wr_zero_bottom;
    wire signed [12:0] wr_data = wr_data_real ? in_data : 13'sd0;

    reg [ADDR_W-1:0] addr_xyc_reg;
    always @(posedge clk) begin
        if (!rst_n) begin
            addr_xyc_reg <= {ADDR_W{1'b0}};
        end else if (accept_step) begin
            if (x_scan >= X_MAX_EX) begin
                addr_xyc_reg <= {ADDR_W{1'b0}};
            end else if (c_scan == 8'd191 && x_scan == (X_MAX_EX - 1)) begin
                addr_xyc_reg <= {ADDR_W{1'b0}};
            end else begin
                addr_xyc_reg <= addr_xyc_reg + 1'b1;
            end
        end
    end

    wire [ADDR_W-1:0] addr_xyc = addr_xyc_reg;
    wire [1:0] bank_cur = y_scan[1:0];

    wire vm1 = (y_scan >= 6'd1);
    wire vm2 = (y_scan >= 6'd2);
    wire vm3 = (y_scan >= 6'd3);
    wire vm4 = (y_scan >= 6'd4);

    wire rd_x_ok = x_in_rng;
    wire step_will_output = accept_step && out_en0;

    (* ram_style = "block" *)reg [12:0] mem0 [0:DEPTH_ROW-1];
    (* ram_style = "block" *)reg [12:0] mem1 [0:DEPTH_ROW-1];
    (* ram_style = "block" *)reg [12:0] mem2 [0:DEPTH_ROW-1];
    (* ram_style = "block" *)reg [12:0] mem3 [0:DEPTH_ROW-1];

    reg signed [12:0] q0, q1, q2, q3;
    wire we0 = wr_en && (bank_cur == 2'd0);
    wire we1 = wr_en && (bank_cur == 2'd1);
    wire we2 = wr_en && (bank_cur == 2'd2);
    wire we3 = wr_en && (bank_cur == 2'd3);
    
    always @(posedge clk) begin
        if (accept_step) begin
            if (we0) mem0[addr_xyc] <= wr_data;
            if (we1) mem1[addr_xyc] <= wr_data;
            if (we2) mem2[addr_xyc] <= wr_data;
            if (we3) mem3[addr_xyc] <= wr_data;

            q0 <= mem0[addr_xyc];
            q1 <= mem1[addr_xyc];
            q2 <= mem2[addr_xyc];
            q3 <= mem3[addr_xyc];
        end
    end

    reg p0_valid;
    reg [7:0] p0_c;
    reg p0_out_en;
    reg [9:0] p0_out_pix;
    reg p0_last;
    reg p0_vm1, p0_vm2, p0_vm3, p0_vm4;
    reg [1:0] p0_bank;
    reg p0_x_ok;
    always @(posedge clk) begin
        if (!rst_n) begin
            p0_valid   <= 1'b0;
            p0_c       <= 8'd0;
            p0_out_en  <= 1'b0;
            p0_out_pix <= 10'd0;
            p0_last    <= 1'b0;
            p0_vm1     <= 1'b0;
            p0_vm2     <= 1'b0;
            p0_vm3     <= 1'b0;
            p0_vm4     <= 1'b0;
            p0_bank    <= 2'd0;
            p0_x_ok    <= 1'b0;
        end else begin
            p0_valid <= accept_step;
            if (accept_step) begin
                p0_c       <= c_scan;
                p0_out_en  <= out_en0;
                p0_out_pix <= out_pix0;
                p0_last    <= last0;
                p0_vm1     <= vm1;
                p0_vm2     <= vm2;
                p0_vm3     <= vm3;
                p0_vm4     <= vm4;
                p0_bank    <= bank_cur;
                p0_x_ok    <= rd_x_ok;
            end
        end
    end

    reg signed [12:0] p0_cur;
    always @(posedge clk) begin
        if (accept_step) begin
            p0_cur <= sample_cur;
        end
    end

    reg signed [12:0] m1_u, m2_u, m3_u, m4_u;
    always @(*) begin
        m1_u = 13'sd0; m2_u = 13'sd0; m3_u = 13'sd0; m4_u = 13'sd0;
        if (p0_x_ok) begin
            if (p0_vm1) begin
                case (p0_bank)
                    2'd0: m1_u = q3; 2'd1: m1_u = q0; 2'd2: m1_u = q1; 2'd3: m1_u = q2;
                endcase
            end
            if (p0_vm2) begin
                case (p0_bank)
                    2'd0: m2_u = q2; 2'd1: m2_u = q3; 2'd2: m2_u = q0; 2'd3: m2_u = q1;
                endcase
            end
            if (p0_vm3) begin
                case (p0_bank)
                    2'd0: m3_u = q1; 2'd1: m3_u = q2; 2'd2: m3_u = q3; 2'd3: m3_u = q0;
                endcase
            end
            if (p0_vm4) begin
                case (p0_bank)
                    2'd0: m4_u = q0; 2'd1: m4_u = q1; 2'd2: m4_u = q2; 2'd3: m4_u = q3;
                endcase
            end
        end
    end

    reg        s1_valid;
    reg [7:0]  s1_c;
    reg        s1_out_en;
    reg [9:0]  s1_out_pix;
    reg        s1_last;

    reg        pipe_v   [0:PIPE_LEN-1];
    reg [7:0]  pipe_c   [0:PIPE_LEN-1];
    reg        pipe_oe  [0:PIPE_LEN-1];
    reg [9:0]  pipe_pix [0:PIPE_LEN-1];
    reg        pipe_last[0:PIPE_LEN-1];

    integer si;
    always @(posedge clk) begin
        if (!rst_n) begin
            s1_valid <= 1'b0;
            s1_c <= 8'd0;
            s1_out_en <= 1'b0;
            s1_out_pix <= 10'd0;
            s1_last <= 1'b0;
            for (si=0; si<PIPE_LEN; si=si+1) begin
                pipe_v[si]    <= 1'b0;
                pipe_c[si]    <= 8'd0;
                pipe_oe[si]   <= 1'b0;
                pipe_pix[si]  <= 10'd0;
                pipe_last[si] <= 1'b0;
            end
        end else begin
            s1_valid <= p0_valid;
            if (p0_valid) begin
                s1_c       <= p0_c;
                s1_out_en  <= p0_out_en;
                s1_out_pix <= p0_out_pix;
                s1_last    <= p0_last;
            end

            pipe_v[0]    <= s1_valid;
            pipe_c[0]    <= s1_c;
            pipe_oe[0]   <= s1_out_en;
            pipe_pix[0]  <= s1_out_pix;
            pipe_last[0] <= s1_last;
            
            for (si=1; si<PIPE_LEN; si=si+1) begin
                pipe_v[si]    <= pipe_v[si-1];
                pipe_c[si]    <= pipe_c[si-1];
                pipe_oe[si]   <= pipe_oe[si-1];
                pipe_pix[si]  <= pipe_pix[si-1];
                pipe_last[si] <= pipe_last[si-1];
            end
        end
    end

    reg signed [12:0] s1_r0, s1_r1, s1_r2, s1_r3, s1_r4;
    reg signed [12:0] pipe_r0 [0:PIPE_LEN-1];
    reg signed [12:0] pipe_r1 [0:PIPE_LEN-1];
    reg signed [12:0] pipe_r2 [0:PIPE_LEN-1];
    reg signed [12:0] pipe_r3 [0:PIPE_LEN-1];
    reg signed [12:0] pipe_r4 [0:PIPE_LEN-1];
    integer sdi;

    always @(posedge clk) begin
        if (p0_valid) begin
            s1_r0 <= m4_u; s1_r1 <= m3_u; s1_r2 <= m2_u; s1_r3 <= m1_u; s1_r4 <= p0_cur;
        end

        pipe_r0[0] <= s1_r0; pipe_r1[0] <= s1_r1; pipe_r2[0] <= s1_r2; pipe_r3[0] <= s1_r3; pipe_r4[0] <= s1_r4;

        for (sdi=1; sdi<PIPE_LEN; sdi=sdi+1) begin
            pipe_r0[sdi] <= pipe_r0[sdi-1]; pipe_r1[sdi] <= pipe_r1[sdi-1]; pipe_r2[sdi] <= pipe_r2[sdi-1];
            pipe_r3[sdi] <= pipe_r3[sdi-1]; pipe_r4[sdi] <= pipe_r4[sdi-1];
        end
    end

    wire comp_valid0       = pipe_v[SHIFT] && (!clr_active);
    wire [7:0] comp_c0     = pipe_c[SHIFT];
    wire signed [12:0] ins0_0 = pipe_r0[SHIFT];
    wire signed [12:0] ins1_0 = pipe_r1[SHIFT];
    wire signed [12:0] ins2_0 = pipe_r2[SHIFT];
    wire signed [12:0] ins3_0 = pipe_r3[SHIFT];
    wire signed [12:0] ins4_0 = pipe_r4[SHIFT];
    wire comp_oe0          = pipe_oe[SHIFT];
    wire [9:0] comp_pix0   = pipe_pix[SHIFT];
    wire comp_last0        = pipe_last[SHIFT];
    
    reg [7:0] w_addr;
    reg [7:0] b_addr;

    wire [127:0] wgb0, wgb1, wgb2, wgb3;
    wire [7:0]   w_addr_q;
    wire [7:0]   b_addr_q;

    dw_wbank192_rom #(.MEM(MEM))u_w(
        .clk(clk),
        .addr(w_addr),
        .addr_q(w_addr_q),
        .dout({wgb0, wgb1, wgb2, wgb3})
    );
    wire [31:0] b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;
    dw_bias192_i32_rom #(.BIAS_MEM_FILE(BIAS))u_b(
        .clk(clk),
        .addr(b_addr),
        .addr_q(b_addr_q),
        .dout(b_dout_u)
    );
    always @(posedge clk) begin
        if (!rst_n) begin
            w_addr <= 8'd0;
            b_addr <= 8'd0;
        end else begin
            if (accept_step) begin
                w_addr <= c_scan;
                b_addr <= c_scan;
            end
        end
    end

    wire signed [BIAS_W-1:0] bias_s = b_dout[BIAS_W-1:0];
    function [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x;
        begin sext32_to_acc = {{(ACC_W-32){x[31]}}, x}; end
    endfunction

    function [ACC_W-1:0] sext_bias_to_acc;
        input signed [BIAS_W-1:0] x;
        begin sext_bias_to_acc = {{(ACC_W-BIAS_W){x[BIAS_W-1]}}, x}; end
    endfunction

    reg        pre_v;
    reg [7:0]  pre_c;
    reg        pre_oe;
    reg [9:0]  pre_pix;
    reg        pre_last;

    always @(posedge clk) begin
        if (!rst_n) begin
            pre_v    <= 1'b0; pre_c    <= 8'd0; pre_oe   <= 1'b0; pre_pix  <= 10'd0; pre_last <= 1'b0;
        end else begin
            pre_v <= comp_valid0;
            if (comp_valid0) begin
                pre_c    <= comp_c0; pre_oe   <= comp_oe0; pre_pix  <= comp_pix0; pre_last <= comp_last0;
            end
        end
    end

    reg signed [12:0] pre_ins0, pre_ins1, pre_ins2, pre_ins3, pre_ins4;
    reg [127:0] pre_wgb0, pre_wgb1, pre_wgb2, pre_wgb3;
    reg signed [BIAS_W-1:0] pre_bias;
    
    always @(posedge clk) begin
        if (comp_valid0) begin
            pre_ins0 <= ins0_0; pre_ins1 <= ins1_0; pre_ins2 <= ins2_0; pre_ins3 <= ins3_0; pre_ins4 <= ins4_0;
            pre_wgb0 <= wgb0; pre_wgb1 <= wgb1; pre_wgb2 <= wgb2; pre_wgb3 <= wgb3; pre_bias <= bias_s;
        end
    end

    reg                    t_v, t_oe, t_last;
    reg  [7:0]             t_c;
    reg  [9:0]             t_pix;
    wire [64:0] row0_old1, row1_old1, row2_old1, row3_old1, row4_old1;
    reg         row_we;
    reg  [7:0]  row_waddr_0, row_waddr_1, row_waddr_2, row_waddr_3, row_waddr_4;
    reg [64:0] row0_wdata, row1_wdata, row2_wdata, row3_wdata, row4_wdata;

    wire [7:0] row_raddr = pipe_c[SHIFT];
    
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A(8), .ADDR_WIDTH_B(8), .AUTO_SLEEP_TIME(0), .BYTE_WRITE_WIDTH_A(65),
        .CASCADE_HEIGHT(0), .CLOCKING_MODE("common_clock"), .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"), .MEMORY_INIT_PARAM("0"), .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("distributed"), .MEMORY_SIZE(12480), .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_B(65), .READ_LATENCY_B(1), .READ_RESET_VALUE_B("0"),
        .RST_MODE_A("SYNC"), .RST_MODE_B("SYNC"), .SIM_ASSERT_CHK(0),
        .USE_EMBEDDED_CONSTRAINT(0), .USE_MEM_INIT(0), .WAKEUP_TIME("disable_sleep"),
        .WRITE_DATA_WIDTH_A(65), .WRITE_MODE_B("read_first")
    ) u_row0 (
        .clka(clk), .ena(1'b1), .wea(row_we), .addra(row_waddr_0), .dina(row0_wdata),
        .clkb(clk), .enb(1'b1), .addrb(row_raddr), .doutb(row0_old1),
        .rstb(1'b0), .regceb(1'b1), .sleep(1'b0), .injectdbiterra(1'b0), .injectsbiterra(1'b0), .dbiterrb(), .sbiterrb()
    );
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A(8), .ADDR_WIDTH_B(8), .AUTO_SLEEP_TIME(0), .BYTE_WRITE_WIDTH_A(65),
        .CASCADE_HEIGHT(0), .CLOCKING_MODE("common_clock"), .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"), .MEMORY_INIT_PARAM("0"), .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("distributed"), .MEMORY_SIZE(12480), .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_B(65), .READ_LATENCY_B(1), .READ_RESET_VALUE_B("0"),
        .RST_MODE_A("SYNC"), .RST_MODE_B("SYNC"), .SIM_ASSERT_CHK(0),
        .USE_EMBEDDED_CONSTRAINT(0), .USE_MEM_INIT(0), .WAKEUP_TIME("disable_sleep"),
        .WRITE_DATA_WIDTH_A(65), .WRITE_MODE_B("read_first")
    ) u_row1 (
        .clka(clk), .ena(1'b1), .wea(row_we), .addra(row_waddr_1), .dina(row1_wdata),
        .clkb(clk), .enb(1'b1), .addrb(row_raddr), .doutb(row1_old1),
        .rstb(1'b0), .regceb(1'b1), .sleep(1'b0), .injectdbiterra(1'b0), .injectsbiterra(1'b0), .dbiterrb(), .sbiterrb()
    );
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A(8), .ADDR_WIDTH_B(8), .AUTO_SLEEP_TIME(0), .BYTE_WRITE_WIDTH_A(65),
        .CASCADE_HEIGHT(0), .CLOCKING_MODE("common_clock"), .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"), .MEMORY_INIT_PARAM("0"), .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("distributed"), .MEMORY_SIZE(12480), .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_B(65), .READ_LATENCY_B(1), .READ_RESET_VALUE_B("0"),
        .RST_MODE_A("SYNC"), .RST_MODE_B("SYNC"), .SIM_ASSERT_CHK(0),
        .USE_EMBEDDED_CONSTRAINT(0), .USE_MEM_INIT(0), .WAKEUP_TIME("disable_sleep"),
        .WRITE_DATA_WIDTH_A(65), .WRITE_MODE_B("read_first")
    ) u_row2 (
        .clka(clk), .ena(1'b1), .wea(row_we), .addra(row_waddr_2), .dina(row2_wdata),
        .clkb(clk), .enb(1'b1), .addrb(row_raddr), .doutb(row2_old1),
        .rstb(1'b0), .regceb(1'b1), .sleep(1'b0), .injectdbiterra(1'b0), .injectsbiterra(1'b0), .dbiterrb(), .sbiterrb()
    );
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A(8), .ADDR_WIDTH_B(8), .AUTO_SLEEP_TIME(0), .BYTE_WRITE_WIDTH_A(65),
        .CASCADE_HEIGHT(0), .CLOCKING_MODE("common_clock"), .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"), .MEMORY_INIT_PARAM("0"), .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("distributed"), .MEMORY_SIZE(12480), .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_B(65), .READ_LATENCY_B(1), .READ_RESET_VALUE_B("0"),
        .RST_MODE_A("SYNC"), .RST_MODE_B("SYNC"), .SIM_ASSERT_CHK(0),
        .USE_EMBEDDED_CONSTRAINT(0), .USE_MEM_INIT(0), .WAKEUP_TIME("disable_sleep"),
        .WRITE_DATA_WIDTH_A(65), .WRITE_MODE_B("read_first")
    ) u_row3 (
        .clka(clk), .ena(1'b1), .wea(row_we), .addra(row_waddr_3), .dina(row3_wdata),
        .clkb(clk), .enb(1'b1), .addrb(row_raddr), .doutb(row3_old1),
        .rstb(1'b0), .regceb(1'b1), .sleep(1'b0), .injectdbiterra(1'b0), .injectsbiterra(1'b0), .dbiterrb(), .sbiterrb()
    );
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A(8), .ADDR_WIDTH_B(8), .AUTO_SLEEP_TIME(0), .BYTE_WRITE_WIDTH_A(65),
        .CASCADE_HEIGHT(0), .CLOCKING_MODE("common_clock"), .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"), .MEMORY_INIT_PARAM("0"), .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("distributed"), .MEMORY_SIZE(12480), .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_B(65), .READ_LATENCY_B(1), .READ_RESET_VALUE_B("0"),
        .RST_MODE_A("SYNC"), .RST_MODE_B("SYNC"), .SIM_ASSERT_CHK(0),
        .USE_EMBEDDED_CONSTRAINT(0), .USE_MEM_INIT(0), .WAKEUP_TIME("disable_sleep"),
        .WRITE_DATA_WIDTH_A(65), .WRITE_MODE_B("read_first")
    ) u_row4 (
        .clka(clk), .ena(1'b1), .wea(row_we), .addra(row_waddr_4), .dina(row4_wdata),
        .clkb(clk), .enb(1'b1), .addrb(row_raddr), .doutb(row4_old1),
        .rstb(1'b0), .regceb(1'b1), .sleep(1'b0), .injectdbiterra(1'b0), .injectsbiterra(1'b0), .dbiterrb(), .sbiterrb()
    );
    
    always @(posedge clk) begin
        if (!rst_n) begin
            clr_active <= 1'b1;
            clr_addr   <= 8'd0;
            row_we      <= 1'b0;
            row_waddr_0 <= 8'd0; row_waddr_1 <= 8'd0; row_waddr_2 <= 8'd0; row_waddr_3 <= 8'd0; row_waddr_4 <= 8'd0;
            t_v    <= 1'b0; t_oe   <= 1'b0; t_last <= 1'b0; t_c    <= 8'd0; t_pix  <= 10'd0;
        end else begin
            t_v    <= 1'b0;
            row_we <= 1'b0;

            if (clr_active) begin
                row_we      <= 1'b1;
                row_waddr_0 <= clr_addr; row_waddr_1 <= clr_addr; row_waddr_2 <= clr_addr;
                row_waddr_3 <= clr_addr; row_waddr_4 <= clr_addr;
                if (clr_addr == 8'd191) begin
                    clr_active <= 1'b0; clr_addr   <= 8'd0;
                end else clr_addr <= clr_addr + 8'd1;
            end else if (pre_v) begin
                t_v    <= 1'b1; t_oe   <= pre_oe; t_c    <= pre_c; t_pix  <= pre_pix; t_last <= pre_last;
                row_we      <= 1'b1;
                row_waddr_0 <= pre_c; row_waddr_1 <= pre_c; row_waddr_2 <= pre_c; row_waddr_3 <= pre_c; row_waddr_4 <= pre_c;
            end
        end
    end

    reg signed [12:0] t_r0t1,t_r0t2,t_r0t3,t_r0t4,t_i0;
    reg signed [12:0] t_r1t1,t_r1t2,t_r1t3,t_r1t4,t_i1;
    reg signed [12:0] t_r2t1,t_r2t2,t_r2t3,t_r2t4,t_i2;
    reg signed [12:0] t_r3t1,t_r3t2,t_r3t3,t_r3t4,t_i3;
    reg signed [12:0] t_r4t1,t_r4t2,t_r4t3,t_r4t4,t_i4;
    reg signed [15:0] t_w00, t_w01, t_w02, t_w03, t_w04;
    reg signed [15:0] t_w10, t_w11, t_w12, t_w13, t_w14;
    reg signed [15:0] t_w20, t_w21, t_w22, t_w23, t_w24;
    reg signed [15:0] t_w30, t_w31, t_w32, t_w33, t_w34;
    reg signed [15:0] t_w40, t_w41, t_w42, t_w43, t_w44;
    reg signed [BIAS_W-1:0] t_bias;
    
    always @(posedge clk) begin
        if (clr_active) begin
            row0_wdata <= 65'd0; row1_wdata <= 65'd0; row2_wdata <= 65'd0; row3_wdata <= 65'd0; row4_wdata <= 65'd0;
        end else if (pre_v) begin
            t_r0t1 <= $signed(row0_old1[51:39]); t_r0t2 <= $signed(row0_old1[38:26]); t_r0t3 <= $signed(row0_old1[25:13]); t_r0t4 <= $signed(row0_old1[12:0]);  t_i0 <= pre_ins0;
            t_r1t1 <= $signed(row1_old1[51:39]); t_r1t2 <= $signed(row1_old1[38:26]); t_r1t3 <= $signed(row1_old1[25:13]); t_r1t4 <= $signed(row1_old1[12:0]);  t_i1 <= pre_ins1;
            t_r2t1 <= $signed(row2_old1[51:39]); t_r2t2 <= $signed(row2_old1[38:26]); t_r2t3 <= $signed(row2_old1[25:13]); t_r2t4 <= $signed(row2_old1[12:0]);  t_i2 <= pre_ins2;
            t_r3t1 <= $signed(row3_old1[51:39]); t_r3t2 <= $signed(row3_old1[38:26]); t_r3t3 <= $signed(row3_old1[25:13]); t_r3t4 <= $signed(row3_old1[12:0]);  t_i3 <= pre_ins3;
            t_r4t1 <= $signed(row4_old1[51:39]); t_r4t2 <= $signed(row4_old1[38:26]); t_r4t3 <= $signed(row4_old1[25:13]); t_r4t4 <= $signed(row4_old1[12:0]);  t_i4 <= pre_ins4;
            
            t_w00 <= $signed(pre_wgb0[15:0]);    t_w01 <= $signed(pre_wgb0[31:16]);   t_w02 <= $signed(pre_wgb0[47:32]);   t_w03 <= $signed(pre_wgb0[63:48]);   t_w04 <= $signed(pre_wgb0[79:64]);
            t_w10 <= $signed(pre_wgb0[95:80]);   t_w11 <= $signed(pre_wgb0[111:96]);  t_w12 <= $signed(pre_wgb0[127:112]); t_w13 <= $signed(pre_wgb1[15:0]);    t_w14 <= $signed(pre_wgb1[31:16]);
            t_w20 <= $signed(pre_wgb1[47:32]);   t_w21 <= $signed(pre_wgb1[63:48]);   t_w22 <= $signed(pre_wgb1[79:64]);   t_w23 <= $signed(pre_wgb1[95:80]);   t_w24 <= $signed(pre_wgb1[111:96]);
            t_w30 <= $signed(pre_wgb1[127:112]); t_w31 <= $signed(pre_wgb2[15:0]);    t_w32 <= $signed(pre_wgb2[31:16]);   t_w33 <= $signed(pre_wgb2[47:32]);   t_w34 <= $signed(pre_wgb2[63:48]);
            t_w40 <= $signed(pre_wgb2[79:64]);   t_w41 <= $signed(pre_wgb2[95:80]);   t_w42 <= $signed(pre_wgb2[111:96]);  t_w43 <= $signed(pre_wgb2[127:112]); t_w44 <= $signed(pre_wgb3[15:0]);

            t_bias <= pre_bias;

            row0_wdata <= {row0_old1[51:0], pre_ins0};
            row1_wdata <= {row1_old1[51:0], pre_ins1};
            row2_wdata <= {row2_old1[51:0], pre_ins2};
            row3_wdata <= {row3_old1[51:0], pre_ins3};
            row4_wdata <= {row4_old1[51:0], pre_ins4};
        end
    end

    (* use_dsp = "yes" *) wire signed [31:0] p00_w = $signed(t_r0t1) * t_w00;
    (* use_dsp = "yes" *) wire signed [31:0] p01_w = $signed(t_r0t2) * t_w01;
    (* use_dsp = "yes" *) wire signed [31:0] p02_w = $signed(t_r0t3) * t_w02;
    (* use_dsp = "yes" *) wire signed [31:0] p03_w = $signed(t_r0t4) * t_w03;
    (* use_dsp = "yes" *) wire signed [31:0] p04_w = $signed(t_i0)   * t_w04;
    (* use_dsp = "yes" *) wire signed [31:0] p10_w = $signed(t_r1t1) * t_w10;
    (* use_dsp = "yes" *) wire signed [31:0] p11_w = $signed(t_r1t2) * t_w11;
    (* use_dsp = "yes" *) wire signed [31:0] p12_w = $signed(t_r1t3) * t_w12;
    (* use_dsp = "yes" *) wire signed [31:0] p13_w = $signed(t_r1t4) * t_w13;
    (* use_dsp = "yes" *) wire signed [31:0] p14_w = $signed(t_i1)   * t_w14;
    (* use_dsp = "yes" *) wire signed [31:0] p20_w = $signed(t_r2t1) * t_w20;
    (* use_dsp = "yes" *) wire signed [31:0] p21_w = $signed(t_r2t2) * t_w21;
    (* use_dsp = "yes" *) wire signed [31:0] p22_w = $signed(t_r2t3) * t_w22;
    (* use_dsp = "yes" *) wire signed [31:0] p23_w = $signed(t_r2t4) * t_w23;
    (* use_dsp = "yes" *) wire signed [31:0] p24_w = $signed(t_i2)   * t_w24;
    (* use_dsp = "yes" *) wire signed [31:0] p30_w = $signed(t_r3t1) * t_w30;
    (* use_dsp = "yes" *) wire signed [31:0] p31_w = $signed(t_r3t2) * t_w31;
    (* use_dsp = "yes" *) wire signed [31:0] p32_w = $signed(t_r3t3) * t_w32;
    (* use_dsp = "yes" *) wire signed [31:0] p33_w = $signed(t_r3t4) * t_w33;
    (* use_dsp = "yes" *) wire signed [31:0] p34_w = $signed(t_i3)   * t_w34;
    (* use_dsp = "yes" *) wire signed [31:0] p40_w = $signed(t_r4t1) * t_w40;
    (* use_dsp = "yes" *) wire signed [31:0] p41_w = $signed(t_r4t2) * t_w41;
    (* use_dsp = "yes" *) wire signed [31:0] p42_w = $signed(t_r4t3) * t_w42;
    (* use_dsp = "yes" *) wire signed [31:0] p43_w = $signed(t_r4t4) * t_w43;
    (* use_dsp = "yes" *) wire signed [31:0] p44_w = $signed(t_i4)   * t_w44;
    
    reg        p_v, p_oe, p_last;
    reg [7:0]  p_c;
    reg [9:0]  p_pix;
    always @(posedge clk) begin
        if (!rst_n) begin
            p_v    <= 1'b0; p_oe   <= 1'b0; p_last <= 1'b0; p_c    <= 8'd0; p_pix  <= 10'd0;
        end else begin
            p_v    <= t_v; p_oe   <= t_oe; p_c    <= t_c; p_pix  <= t_pix; p_last <= t_last;
        end
    end

    reg signed [BIAS_W-1:0] p_bias;
    reg signed [31:0] p00_r,p01_r,p02_r,p03_r,p04_r;
    reg signed [31:0] p10_r,p11_r,p12_r,p13_r,p14_r;
    reg signed [31:0] p20_r,p21_r,p22_r,p23_r,p24_r;
    reg signed [31:0] p30_r,p31_r,p32_r,p33_r,p34_r;
    reg signed [31:0] p40_r,p41_r,p42_r,p43_r,p44_r;
    always @(posedge clk) begin
        if (t_v) begin
            p_bias <= t_bias;
            p00_r <= p00_w; p01_r <= p01_w; p02_r <= p02_w; p03_r <= p03_w; p04_r <= p04_w;
            p10_r <= p10_w; p11_r <= p11_w; p12_r <= p12_w; p13_r <= p13_w; p14_r <= p14_w;
            p20_r <= p20_w; p21_r <= p21_w; p22_r <= p22_w; p23_r <= p23_w; p24_r <= p24_w;
            p30_r <= p30_w; p31_r <= p31_w; p32_r <= p32_w; p33_r <= p33_w; p34_r <= p34_w;
            p40_r <= p40_w; p41_r <= p41_w; p42_r <= p42_w; p43_r <= p43_w; p44_r <= p44_w;
        end
    end

    reg        s0a_v, s0a_oe, s0a_last;
    reg [7:0]  s0a_c;
    reg [9:0]  s0a_pix;

    always @(posedge clk) begin
        if (!rst_n) begin
            s0a_v    <= 1'b0; s0a_oe   <= 1'b0; s0a_last <= 1'b0; s0a_c    <= 8'd0; s0a_pix  <= 10'd0;
        end else begin
            s0a_v    <= p_v; s0a_oe   <= p_oe; s0a_c    <= p_c; s0a_pix  <= p_pix; s0a_last <= p_last;
        end
    end

    reg signed [BIAS_W-1:0] s0a_bias;
    reg signed [ACC_W-1:0] g0_a, g0_b, g0_c;
    reg signed [ACC_W-1:0] g1_a, g1_b, g1_c;
    reg signed [ACC_W-1:0] g2_a, g2_b, g2_c;
    reg signed [ACC_W-1:0] g3_a, g3_b, g3_c;
    reg signed [ACC_W-1:0] g4_a, g4_b, g4_c;

    always @(posedge clk) begin
        if (p_v) begin
            s0a_bias <= p_bias;
            g0_a <= sext32_to_acc(p00_r) + sext32_to_acc(p01_r); g0_b <= sext32_to_acc(p02_r) + sext32_to_acc(p03_r); g0_c <= sext32_to_acc(p04_r);
            g1_a <= sext32_to_acc(p10_r) + sext32_to_acc(p11_r); g1_b <= sext32_to_acc(p12_r) + sext32_to_acc(p13_r); g1_c <= sext32_to_acc(p14_r);
            g2_a <= sext32_to_acc(p20_r) + sext32_to_acc(p21_r); g2_b <= sext32_to_acc(p22_r) + sext32_to_acc(p23_r); g2_c <= sext32_to_acc(p24_r);
            g3_a <= sext32_to_acc(p30_r) + sext32_to_acc(p31_r); g3_b <= sext32_to_acc(p32_r) + sext32_to_acc(p33_r); g3_c <= sext32_to_acc(p34_r);
            g4_a <= sext32_to_acc(p40_r) + sext32_to_acc(p41_r); g4_b <= sext32_to_acc(p42_r) + sext32_to_acc(p43_r); g4_c <= sext32_to_acc(p44_r);
        end
    end

    reg        mac0_v, mac0_oe, mac0_last;
    reg [7:0]  mac0_c;
    reg [9:0]  mac0_pix;

    always @(posedge clk) begin
        if (!rst_n) begin
            mac0_v    <= 1'b0; mac0_oe   <= 1'b0; mac0_last <= 1'b0; mac0_c    <= 8'd0; mac0_pix  <= 10'd0;
        end else begin
            mac0_v    <= s0a_v; mac0_oe   <= s0a_oe; mac0_c    <= s0a_c; mac0_pix  <= s0a_pix; mac0_last <= s0a_last;
        end
    end

    reg signed [ACC_W-1:0] mac0_s0, mac0_s1, mac0_s2, mac0_s3, mac0_s4;
    reg signed [BIAS_W-1:0] mac0_bias;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_g0 = (g0_a + g0_b) + g0_c;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_g1 = (g1_a + g1_b) + g1_c;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_g2 = (g2_a + g2_b) + g2_c;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_g3 = (g3_a + g3_b) + g3_c;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_g4 = (g4_a + g4_b) + g4_c;
    always @(posedge clk) begin
        if (s0a_v) begin
            mac0_bias <= s0a_bias;
            mac0_s0   <= sum_g0; mac0_s1   <= sum_g1; mac0_s2   <= sum_g2; mac0_s3   <= sum_g3; mac0_s4   <= sum_g4;
        end
    end

    reg        mac1a_v, mac1a_oe, mac1a_last;
    reg [7:0]  mac1a_c;  reg [9:0]  mac1a_pix;
    reg        mac1_v, mac1_oe, mac1_last;
    reg [7:0]  mac1_c;   reg [9:0]  mac1_pix;

    always @(posedge clk) begin
        if (!rst_n) begin
            mac1a_v    <= 1'b0; mac1a_oe   <= 1'b0; mac1a_last <= 1'b0; mac1a_c    <= 8'd0; mac1a_pix  <= 10'd0;
            mac1_v     <= 1'b0; mac1_oe    <= 1'b0; mac1_last  <= 1'b0; mac1_c     <= 8'd0; mac1_pix   <= 10'd0;
        end else begin
            mac1a_v    <= mac0_v; mac1a_oe   <= mac0_oe;  mac1a_last <= mac0_last; mac1a_c    <= mac0_c;  mac1a_pix  <= mac0_pix;
            mac1_v     <= mac1a_v; mac1_oe    <= mac1a_oe; mac1_last  <= mac1a_last; mac1_c     <= mac1a_c; mac1_pix   <= mac1a_pix;
        end
    end

    reg signed [ACC_W-1:0] mac1a_part;
    reg signed [ACC_W-1:0] mac1a_s4b;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] mac0_s01      = mac0_s0 + mac0_s1;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] mac0_s23      = mac0_s2 + mac0_s3;
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] mac0_s4b_base = mac0_s4 + sext_bias_to_acc(mac0_bias);
    (* use_dsp = "no" *) wire signed [ACC_W-1:0] sum_part      = mac0_s01 + mac0_s23;
    reg signed [ACC_W-1:0] mac1_sum_base;

    always @(posedge clk) begin
        if (mac0_v) begin
            mac1a_part <= sum_part;
            mac1a_s4b  <= mac0_s4b_base;
        end
        if (mac1a_v) begin
            mac1_sum_base <= mac1a_part + mac1a_s4b;
        end
    end

    reg        mac2_v, mac2_last;
    reg [7:0]  mac2_c;
    reg [9:0]  mac2_pix;
    reg signed [12:0] mac2_data;
    always @(posedge clk) begin
        if (!rst_n) begin
            mac2_v    <= 1'b0; mac2_c    <= 8'd0; mac2_pix  <= 10'd0; mac2_last <= 1'b0;
        end else begin
            mac2_v    <= mac1_v && mac1_oe;
            mac2_c    <= mac1_c; mac2_pix  <= mac1_pix; mac2_last <= mac1_last;
        end
    end

    always @(posedge clk) begin
        if (mac1_v) begin
            if ((USE_RELU != 0) && mac1_sum_base[ACC_W-1]) begin
                mac2_data <= 13'sd0;
            end else if (OUT_SHIFT != 0) begin
                mac2_data <= (mac1_sum_base + (40'sd1 <<< (OUT_SHIFT - 1))) >>> OUT_SHIFT;
            end else begin
                mac2_data <= mac1_sum_base[12:0];
            end
        end
    end

    wire gen_out = mac2_v;
    wire signed [12:0] gen_data = mac2_data;
    wire fifo_push = gen_out;
    always @(posedge clk) begin
        if (fifo_push) begin
            fifo_och[fifo_wptr]   <= mac2_c;
            fifo_pix[fifo_wptr]   <= mac2_pix;
            fifo_dat[fifo_wptr]   <= gen_data;
            fifo_lastb[fifo_wptr] <= mac2_last;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            fifo_wptr  <= {FIFO_AW{1'b0}};
            fifo_rptr  <= {FIFO_AW{1'b0}};
            fifo_count <= {FIFO_AW+1{1'b0}};
        end else begin
            case ({fifo_push, fifo_pop})
                2'b01: begin
                    if (!fifo_empty) begin
                        fifo_rptr  <= fifo_rptr + {{(FIFO_AW-1){1'b0}},1'b1};
                        fifo_count <= fifo_count - {{FIFO_AW{1'b0}},1'b1};
                    end
                end
                2'b10: begin
                    fifo_wptr  <= fifo_wptr + {{(FIFO_AW-1){1'b0}},1'b1};
                    fifo_count <= fifo_count + {{FIFO_AW{1'b0}},1'b1};
                end
                2'b11: begin
                    if (!fifo_empty) fifo_rptr <= fifo_rptr + {{(FIFO_AW-1){1'b0}},1'b1};
                    fifo_wptr <= fifo_wptr + {{(FIFO_AW-1){1'b0}},1'b1};
                end
                default: begin end
            endcase
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            inflight_out <= {FIFO_AW+1{1'b0}};
        end else begin
            case ({step_will_output, gen_out})
                2'b01: inflight_out <= inflight_out - {{FIFO_AW{1'b0}},1'b1};
                2'b10: inflight_out <= inflight_out + {{FIFO_AW{1'b0}},1'b1};
                default: inflight_out <= inflight_out;
            endcase
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            x_scan <= 6'd0; y_scan <= 6'd0; c_scan <= 8'd0;
        end else begin
            if (accept_step) begin
                if (c_scan == 8'd191) begin
                    c_scan <= 8'd0;
                    if (x_scan == (WP2-1)) begin
                        x_scan <= 6'd0;
                        if (y_scan == (HP2-1)) y_scan <= 6'd0;
                        else                   y_scan <= y_scan + 6'd1;
                    end else x_scan <= x_scan + 6'd1;
                end else c_scan <= c_scan + 8'd1;
            end
        end
    end
endmodule

module dw_wbank192_rom #(parameter MEM = "")(
    input  wire         clk,
    input  wire [7:0]   addr,
    output reg  [7:0]   addr_q,
    output reg  [511:0] dout
);
    (* rom_style = "block" *) reg [511:0] mem [0:191];
    initial begin $readmemh(MEM, mem); end
    reg [511:0] data_pipe;
    reg [7:0]   addr_pipe;
    always @(posedge clk) begin
        data_pipe <= mem[addr]; addr_pipe <= addr;
        dout      <= data_pipe; addr_q    <= addr_pipe;
    end
endmodule

module dw_bias192_i32_rom #(parameter BIAS_MEM_FILE = "")(
    input  wire        clk,
    input  wire [7:0]  addr,
    output reg  [7:0]  addr_q,
    output reg  [31:0] dout
);
    (* rom_style = "distributed" *)reg [31:0] mem [0:191];
    initial begin $readmemh(BIAS_MEM_FILE, mem); end
    reg [31:0] data_pipe;
    reg [7:0]  addr_pipe;
    always @(posedge clk) begin
        data_pipe <= mem[addr]; addr_pipe <= addr;
        dout      <= data_pipe; addr_q    <= addr_pipe;
    end
endmodule
`default_nettype wire