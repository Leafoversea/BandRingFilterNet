`timescale 1ns/1ps
`default_nettype none

module pointwise1x1_grp8_64to32_11b #(
    parameter integer ROM_LAT   = 1,
    parameter integer USE_RELU  = 0,
    parameter integer OUT_SHIFT = 15
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_pulse,
    input  wire [5:0]  in_och,
    input  wire [11:0] in_pix_idx,
    input  wire signed [10:0] in_data,

    output wire        allow_start,
    output wire        in_ready,

    output reg         out_pulse,
    output reg  [4:0]  out_och,
    output reg  [11:0] out_pix_idx,
    output reg  signed [10:0] out_data
);
    localparam integer MAC_LAT = 7;

    reg signed [15:0] xbank0 [0:15];
    reg signed [15:0] xbank1 [0:15];
    reg signed [15:0] xbank2 [0:15];
    reg signed [15:0] xbank3 [0:15];

    reg [11:0] pix_lat;
    reg [1:0] state;
    localparam [1:0] S_IDLE=2'd0, S_COLLECT=2'd1, S_RUN=2'd2;

    assign allow_start = (state == S_IDLE);
    assign in_ready    = (state == S_IDLE) || (state == S_COLLECT);

    // ============================================================
    // 前馈请求发生器 (替代旧的反馈对齐逻辑)
    // ============================================================
    reg        req_active;
    reg [4:0]  req_och;
    reg [1:0]  req_pair;
    
    // 2拍延迟线：完美匹配 ROM 固有的 2 拍 latency
    reg        vld_q1, mac_vld_in;
    reg [4:0]  och_q1, och_cur;
    reg [1:0]  pair_q1, pair_cur;
    
    // 分离组手动复制，打散庞大的 MUX 扇出，保障超高频率下的时序裕量
    (* equivalent_register_removal = "no" *) reg [1:0] pair_cur_x0;
    (* equivalent_register_removal = "no" *) reg [1:0] pair_cur_x1;
    (* equivalent_register_removal = "no" *) reg [1:0] pair_cur_x2;
    (* equivalent_register_removal = "no" *) reg [1:0] pair_cur_x3;

    reg signed [63:0] acc;

    // ============================================================
    // ROM 实例与连线
    // ============================================================
    wire [255:0] w_dout;
    // 修正：依据 mem 排布采用 {pair, och} 拼接以实现正确寻址
    wire [6:0]   w_addr_fast = {req_pair, req_och};
    wire [4:0]   b_addr      = req_och;

    pw_gbank1024x16_to256_rom u_w0(
        .clk   (clk),
        .addr  (w_addr_fast),
        .addr_q(), // 废弃回读，使用纯前馈
        .dout  (w_dout)
    );

    wire [31:0] b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;
    bias32x32_i32_rom u_b(
        .clk   (clk),
        .addr  (b_addr),
        .addr_q(),
        .dout  (b_dout_u)
    );

    // ============================================================
    // 数据分配 MUX 
    // ============================================================
    // 修正：高低 128-bit 与通道映射对齐 (高128位对应通道0-7，低128位对应通道8-15)
    wire [127:0] w_word0 = w_dout[255:128];
    wire [127:0] w_word1 = w_dout[127:0];

    wire signed [15:0] x00 = (pair_cur_x0==2'd0) ? xbank0[0]  : (pair_cur_x0==2'd1) ? xbank1[0]  : (pair_cur_x0==2'd2) ? xbank2[0]  : xbank3[0];
    wire signed [15:0] x01 = (pair_cur_x0==2'd0) ? xbank0[1]  : (pair_cur_x0==2'd1) ? xbank1[1]  : (pair_cur_x0==2'd2) ? xbank2[1]  : xbank3[1];
    wire signed [15:0] x02 = (pair_cur_x0==2'd0) ? xbank0[2]  : (pair_cur_x0==2'd1) ? xbank1[2]  : (pair_cur_x0==2'd2) ? xbank2[2]  : xbank3[2];
    wire signed [15:0] x03 = (pair_cur_x0==2'd0) ? xbank0[3]  : (pair_cur_x0==2'd1) ? xbank1[3]  : (pair_cur_x0==2'd2) ? xbank2[3]  : xbank3[3];

    wire signed [15:0] x04 = (pair_cur_x1==2'd0) ? xbank0[4]  : (pair_cur_x1==2'd1) ? xbank1[4]  : (pair_cur_x1==2'd2) ? xbank2[4]  : xbank3[4];
    wire signed [15:0] x05 = (pair_cur_x1==2'd0) ? xbank0[5]  : (pair_cur_x1==2'd1) ? xbank1[5]  : (pair_cur_x1==2'd2) ? xbank2[5]  : xbank3[5];
    wire signed [15:0] x06 = (pair_cur_x1==2'd0) ? xbank0[6]  : (pair_cur_x1==2'd1) ? xbank1[6]  : (pair_cur_x1==2'd2) ? xbank2[6]  : xbank3[6];
    wire signed [15:0] x07 = (pair_cur_x1==2'd0) ? xbank0[7]  : (pair_cur_x1==2'd1) ? xbank1[7]  : (pair_cur_x1==2'd2) ? xbank2[7]  : xbank3[7];

    wire signed [15:0] x08 = (pair_cur_x2==2'd0) ? xbank0[8]  : (pair_cur_x2==2'd1) ? xbank1[8]  : (pair_cur_x2==2'd2) ? xbank2[8]  : xbank3[8];
    wire signed [15:0] x09 = (pair_cur_x2==2'd0) ? xbank0[9]  : (pair_cur_x2==2'd1) ? xbank1[9]  : (pair_cur_x2==2'd2) ? xbank2[9]  : xbank3[9];
    wire signed [15:0] x10 = (pair_cur_x2==2'd0) ? xbank0[10] : (pair_cur_x2==2'd1) ? xbank1[10] : (pair_cur_x2==2'd2) ? xbank2[10] : xbank3[10];
    wire signed [15:0] x11 = (pair_cur_x2==2'd0) ? xbank0[11] : (pair_cur_x2==2'd1) ? xbank1[11] : (pair_cur_x2==2'd2) ? xbank2[11] : xbank3[11];

    wire signed [15:0] x12 = (pair_cur_x3==2'd0) ? xbank0[12] : (pair_cur_x3==2'd1) ? xbank1[12] : (pair_cur_x3==2'd2) ? xbank2[12] : xbank3[12];
    wire signed [15:0] x13 = (pair_cur_x3==2'd0) ? xbank0[13] : (pair_cur_x3==2'd1) ? xbank1[13] : (pair_cur_x3==2'd2) ? xbank2[13] : xbank3[13];
    wire signed [15:0] x14 = (pair_cur_x3==2'd0) ? xbank0[14] : (pair_cur_x3==2'd1) ? xbank1[14] : (pair_cur_x3==2'd2) ? xbank2[14] : xbank3[14];
    wire signed [15:0] x15 = (pair_cur_x3==2'd0) ? xbank0[15] : (pair_cur_x3==2'd1) ? xbank1[15] : (pair_cur_x3==2'd2) ? xbank2[15] : xbank3[15];

    // ============================================================
    // PIPELINE STAGE 1 & 2
    // ============================================================
    reg               pre_vld, xw_vld;
    reg signed [15:0] xp00,xp01,xp02,xp03,xp04,xp05,xp06,xp07,xp08,xp09,xp10,xp11,xp12,xp13,xp14,xp15;
    reg [127:0]       wp0, wp1;
    reg signed [15:0] xr00,xr01,xr02,xr03,xr04,xr05,xr06,xr07,xr08,xr09,xr10,xr11,xr12,xr13,xr14,xr15;
    reg signed [15:0] wr00,wr01,wr02,wr03,wr04,wr05,wr06,wr07,wr08,wr09,wr10,wr11,wr12,wr13,wr14,wr15;

    // ============================================================
    // PIPELINE STAGE 3: DSP
    // ============================================================
    reg               mul_vld;
    reg signed [31:0] pm00,pm01,pm02,pm03,pm04,pm05,pm06,pm07,pm08,pm09,pm10,pm11,pm12,pm13,pm14,pm15;

    (* use_dsp = "yes" *) wire signed [31:0] m00 = $signed(xr00) * $signed(wr00);
    (* use_dsp = "yes" *) wire signed [31:0] m01 = $signed(xr01) * $signed(wr01);
    (* use_dsp = "yes" *) wire signed [31:0] m02 = $signed(xr02) * $signed(wr02);
    (* use_dsp = "yes" *) wire signed [31:0] m03 = $signed(xr03) * $signed(wr03);
    (* use_dsp = "yes" *) wire signed [31:0] m04 = $signed(xr04) * $signed(wr04);
    (* use_dsp = "yes" *) wire signed [31:0] m05 = $signed(xr05) * $signed(wr05);
    (* use_dsp = "yes" *) wire signed [31:0] m06 = $signed(xr06) * $signed(wr06);
    (* use_dsp = "yes" *) wire signed [31:0] m07 = $signed(xr07) * $signed(wr07);
    (* use_dsp = "yes" *) wire signed [31:0] m08 = $signed(xr08) * $signed(wr08);
    (* use_dsp = "yes" *) wire signed [31:0] m09 = $signed(xr09) * $signed(wr09);
    (* use_dsp = "yes" *) wire signed [31:0] m10 = $signed(xr10) * $signed(wr10);
    (* use_dsp = "yes" *) wire signed [31:0] m11 = $signed(xr11) * $signed(wr11);
    (* use_dsp = "yes" *) wire signed [31:0] m12 = $signed(xr12) * $signed(wr12);
    (* use_dsp = "yes" *) wire signed [31:0] m13 = $signed(xr13) * $signed(wr13);
    (* use_dsp = "yes" *) wire signed [31:0] m14 = $signed(xr14) * $signed(wr14);
    (* use_dsp = "yes" *) wire signed [31:0] m15 = $signed(xr15) * $signed(wr15);

    wire signed [63:0] pp00 = {{32{pm00[31]}},pm00};
    wire signed [63:0] pp01 = {{32{pm01[31]}},pm01};
    wire signed [63:0] pp02 = {{32{pm02[31]}},pm02};
    wire signed [63:0] pp03 = {{32{pm03[31]}},pm03};
    wire signed [63:0] pp04 = {{32{pm04[31]}},pm04};
    wire signed [63:0] pp05 = {{32{pm05[31]}},pm05};
    wire signed [63:0] pp06 = {{32{pm06[31]}},pm06};
    wire signed [63:0] pp07 = {{32{pm07[31]}},pm07};
    wire signed [63:0] pp08 = {{32{pm08[31]}},pm08};
    wire signed [63:0] pp09 = {{32{pm09[31]}},pm09};
    wire signed [63:0] pp10 = {{32{pm10[31]}},pm10};
    wire signed [63:0] pp11 = {{32{pm11[31]}},pm11};
    wire signed [63:0] pp12 = {{32{pm12[31]}},pm12};
    wire signed [63:0] pp13 = {{32{pm13[31]}},pm13};
    wire signed [63:0] pp14 = {{32{pm14[31]}},pm14};
    wire signed [63:0] pp15 = {{32{pm15[31]}},pm15};

    reg signed [63:0] s1_0, s1_1, s1_2, s1_3, s1_4, s1_5, s1_6, s1_7;
    reg signed [63:0] s2_0, s2_1, s2_2, s2_3;
    reg signed [63:0] s3_0, s3_1;
    reg signed [63:0] mac_final;

    // ============================================================
    // 同步控制信号与偏置移位寄存器 (核心修复：解决错位覆盖)
    // ============================================================
    reg [MAC_LAT-1:0] mac_vld_sh;
    reg [1:0]         pair_sh [0:MAC_LAT-1];
    reg [4:0]         och_sh  [0:MAC_LAT-1];
    reg signed [31:0] bias_sh [0:MAC_LAT-1]; // 偏置随流水线逐级打拍
    
    wire              mac_vld_out = mac_vld_sh[MAC_LAT-1];
    wire [1:0]        pair_out    = pair_sh[MAC_LAT-1];
    wire [4:0]        och_out     = och_sh[MAC_LAT-1];

    integer k;
    integer i;

    function [31:0] scale_shift_trunc32;
        input signed [63:0] x;
        reg signed [63:0] rnd_add;
        reg signed [63:0] xr;
        reg signed [63:0] xs;
        begin
            if (OUT_SHIFT == 0) begin
                xs = x;
            end else begin
                rnd_add = (64'sd1 <<< (OUT_SHIFT-1));
                xr = x + rnd_add;
                xs = xr >>> OUT_SHIFT;
            end
            if (USE_RELU != 0 && xs[63]) scale_shift_trunc32 = 32'd0;
            else                         scale_shift_trunc32 = xs[31:0];
        end
    endfunction

    reg post_v0, post_v1, post_v2;
    reg signed [63:0] sum_bias_r0;
    reg [31:0]        y32_r1;
    reg signed [10:0] y11_r2;
    reg [4:0]  och_r0, och_r1, och_r2;
    reg [11:0] pix_r0, pix_r1, pix_r2;

    wire signed [63:0] acc_plus_mac  = acc + mac_final;
    // 使用流水线最后一级的偏置，确保100%严丝合缝
    wire signed [63:0] sum_bias_now  = acc_plus_mac + {{32{bias_sh[MAC_LAT-1][31]}}, bias_sh[MAC_LAT-1]};

    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE;
            pix_lat   <= 12'd0;
            
            req_active <= 1'b0;
            req_och    <= 5'd0;
            req_pair   <= 2'd0;
            
            vld_q1 <= 0; mac_vld_in <= 0;
            och_q1 <= 0; och_cur <= 0;
            pair_q1 <= 0; pair_cur <= 0;
            pair_cur_x0 <= 0; pair_cur_x1 <= 0; pair_cur_x2 <= 0; pair_cur_x3 <= 0;
            
            acc       <= 64'sd0;

            pre_vld <= 1'b0;
            xp00<=0;xp01<=0;xp02<=0;xp03<=0;xp04<=0;xp05<=0;xp06<=0;xp07<=0;
            xp08<=0;xp09<=0;xp10<=0;xp11<=0;xp12<=0;xp13<=0;xp14<=0;xp15<=0;
            wp0<=0; wp1<=0;

            xw_vld <= 1'b0;
            xr00<=0;xr01<=0;xr02<=0;xr03<=0;xr04<=0;xr05<=0;xr06<=0;xr07<=0;
            xr08<=0;xr09<=0;xr10<=0;xr11<=0;xr12<=0;xr13<=0;xr14<=0;xr15<=0;
            wr00<=0;wr01<=0;wr02<=0;wr03<=0;wr04<=0;wr05<=0;wr06<=0;wr07<=0;
            wr08<=0;wr09<=0;wr10<=0;wr11<=0;wr12<=0;wr13<=0;wr14<=0;wr15<=0;

            mul_vld <= 1'b0;
            pm00<=0;pm01<=0;pm02<=0;pm03<=0;pm04<=0;pm05<=0;pm06<=0;pm07<=0;
            pm08<=0;pm09<=0;pm10<=0;pm11<=0;pm12<=0;pm13<=0;pm14<=0;pm15<=0;

            s1_0<=0; s1_1<=0; s1_2<=0; s1_3<=0; s1_4<=0; s1_5<=0; s1_6<=0; s1_7<=0;
            s2_0<=0; s2_1<=0; s2_2<=0; s2_3<=0;
            s3_0<=0; s3_1<=0;
            mac_final<=0;

            mac_vld_sh <= {MAC_LAT{1'b0}};
            for (k=0;k<MAC_LAT;k=k+1) begin
                pair_sh[k] <= 2'd0;
                och_sh[k]  <= 5'd0;
                bias_sh[k] <= 32'sd0; 
            end

            post_v0 <= 1'b0; post_v1 <= 1'b0; post_v2 <= 1'b0;
            sum_bias_r0 <= 64'sd0;
            y32_r1 <= 32'd0; y11_r2 <= 11'sd0;
            och_r0 <= 5'd0; och_r1 <= 5'd0; och_r2 <= 5'd0;
            pix_r0 <= 12'd0; pix_r1 <= 12'd0; pix_r2 <= 12'd0;

            out_pulse   <= 1'b0;
            out_och     <= 5'd0;
            out_pix_idx <= 12'd0;
            out_data    <= 11'sd0;
            
            for (i=0;i<16;i=i+1) begin
                xbank0[i] <= 16'sd0; xbank1[i] <= 16'sd0;
                xbank2[i] <= 16'sd0; xbank3[i] <= 16'sd0;
            end

        end else begin
            out_pulse <= 1'b0;

            // ---------------------------------
            // 前馈延迟线 (填补 ROM latency)
            // ---------------------------------
            vld_q1     <= req_active;
            mac_vld_in <= vld_q1;
            
            och_q1     <= req_och;
            och_cur    <= och_q1;
            
            pair_q1    <= req_pair;
            pair_cur   <= pair_q1;
            pair_cur_x0 <= pair_q1;
            pair_cur_x1 <= pair_q1;
            pair_cur_x2 <= pair_q1;
            pair_cur_x3 <= pair_q1;

            // MUX寄存
            pre_vld <= mac_vld_in;
            if (mac_vld_in) begin
                xp00 <= x00; xp01 <= x01; xp02 <= x02; xp03 <= x03;
                xp04 <= x04; xp05 <= x05; xp06 <= x06; xp07 <= x07;
                xp08 <= x08; xp09 <= x09; xp10 <= x10; xp11 <= x11;
                xp12 <= x12; xp13 <= x13; xp14 <= x14; xp15 <= x15;
                wp0  <= w_word0;
                wp1  <= w_word1;
            end

            xw_vld <= pre_vld;
            if (pre_vld) begin
                xr00 <= xp00; xr01 <= xp01; xr02 <= xp02; xr03 <= xp03;
                xr04 <= xp04; xr05 <= xp05; xr06 <= xp06; xr07 <= xp07;
                xr08 <= xp08; xr09 <= xp09; xr10 <= xp10; xr11 <= xp11;
                xr12 <= xp12; xr13 <= xp13; xr14 <= xp14; xr15 <= xp15;

                wr00 <= wp0[ 15:  0]; wr01 <= wp0[ 31: 16];
                wr02 <= wp0[ 47: 32]; wr03 <= wp0[ 63: 48];
                wr04 <= wp0[ 79: 64]; wr05 <= wp0[ 95: 80];
                wr06 <= wp0[111: 96]; wr07 <= wp0[127:112];
                wr08 <= wp1[ 15:  0]; wr09 <= wp1[ 31: 16];
                wr10 <= wp1[ 47: 32]; wr11 <= wp1[ 63: 48];
                wr12 <= wp1[ 79: 64]; wr13 <= wp1[ 95: 80];
                wr14 <= wp1[111: 96]; wr15 <= wp1[127:112];
            end

            mul_vld <= xw_vld;
            pm00 <= m00; pm01 <= m01; pm02 <= m02; pm03 <= m03;
            pm04 <= m04; pm05 <= m05; pm06 <= m06; pm07 <= m07;
            pm08 <= m08; pm09 <= m09; pm10 <= m10; pm11 <= m11;
            pm12 <= m12; pm13 <= m13; pm14 <= m14; pm15 <= m15;

            s1_0 <= pp00 + pp01; s1_1 <= pp02 + pp03;
            s1_2 <= pp04 + pp05; s1_3 <= pp06 + pp07;
            s1_4 <= pp08 + pp09; s1_5 <= pp10 + pp11;
            s1_6 <= pp12 + pp13; s1_7 <= pp14 + pp15;

            s2_0 <= s1_0 + s1_1; s2_1 <= s1_2 + s1_3;
            s2_2 <= s1_4 + s1_5; s2_3 <= s1_6 + s1_7;

            s3_0 <= s2_0 + s2_1; s3_1 <= s2_2 + s2_3;

            mac_final <= s3_0 + s3_1;

            // ---------------------------------
            // 流水线推进 (数据、组号、通道号、偏置并排同步移动)
            // ---------------------------------
            mac_vld_sh <= {mac_vld_sh[MAC_LAT-2:0], mac_vld_in};
            pair_sh[0] <= pair_cur;
            och_sh[0]  <= och_cur;
            bias_sh[0] <= b_dout; 
            
            for (k=1;k<MAC_LAT;k=k+1) begin
                pair_sh[k] <= pair_sh[k-1];
                och_sh[k]  <= och_sh[k-1];
                bias_sh[k] <= bias_sh[k-1]; 
            end

            // 累加树
            if (mac_vld_out) begin
                if (pair_out == 2'd3) begin
                    acc <= 64'sd0; // 完成当前组后重置
                end else begin
                    acc <= acc_plus_mac; // 0, 1, 2时继续累加
                end
            end

            post_v2 <= post_v1;
            post_v1 <= post_v0;
            post_v0 <= 1'b0;

            if (mac_vld_out && (pair_out == 2'd3)) begin
                sum_bias_r0 <= sum_bias_now;
                och_r0      <= och_out; // 严丝合缝
                pix_r0      <= pix_lat;
                post_v0     <= 1'b1;
            end

            if (post_v0) begin
                y32_r1 <= scale_shift_trunc32(sum_bias_r0);
                och_r1 <= och_r0;
                pix_r1 <= pix_r0;
            end

            if (post_v1) begin
                y11_r2 <= y32_r1[10:0];
                och_r2 <= och_r1;
                pix_r2 <= pix_r1;
            end

            if (post_v2) begin
                out_pulse   <= 1'b1;
                out_och     <= och_r2;
                out_pix_idx <= pix_r2;
                out_data    <= y11_r2;
            end

            // ---------------------------------
            // FSM
            // ---------------------------------
            case (state)
                S_IDLE: begin
                    req_active <= 1'b0;
                    req_och    <= 5'd0;
                    req_pair   <= 2'd0;
                    if (in_pulse && (in_och == 6'd0)) begin
                        pix_lat <= in_pix_idx;
                        xbank0[0] <= $signed(in_data);
                        state   <= S_COLLECT;
                    end
                end

                S_COLLECT: begin
                    if (in_pulse) begin
                        case (in_och[5:4])
                            2'd0: xbank0[in_och[3:0]] <= $signed(in_data);
                            2'd1: xbank1[in_och[3:0]] <= $signed(in_data);
                            2'd2: xbank2[in_och[3:0]] <= $signed(in_data);
                            default: xbank3[in_och[3:0]] <= $signed(in_data);
                        endcase

                        if (in_och == 6'd63) begin
                            req_active <= 1'b1;
                            req_och    <= 5'd0;
                            req_pair   <= 2'd0;
                            acc        <= 64'sd0;
                            state      <= S_RUN;
                        end
                    end
                end

                S_RUN: begin
                    // 1. 无停顿生成前馈请求
                    if (req_active) begin
                        if (req_pair == 2'd3) begin
                            if (req_och == 5'd31) begin
                                req_active <= 1'b0;
                            end else begin
                                req_och  <= req_och + 5'd1;
                                req_pair <= 2'd0;
                            end
                        end else begin
                            req_pair <= req_pair + 2'd1;
                        end
                    end
                    
                    // 2. 将收尾判定与生成脱钩：只要流水线完全出空，即可回退
                    if (mac_vld_out && (pair_out == 2'd3) && (och_out == 5'd31)) begin
                        state <= S_IDLE;
                    end
                end

                default: begin
                    state <= S_IDLE;
                end
            endcase
        end
    end

endmodule

`default_nettype wire