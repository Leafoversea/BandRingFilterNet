module ifft32_xfft_axis16_ifft_sep16 #(
    parameter [9:0] SCALE_SCH10 = 10'b0000000000,
    parameter       CFG_EACH_FRAME = 1'b0,
    parameter       PY_MODE = 1'b1
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [15:0] in_re,
    input  wire [15:0] in_im,
    input  wire        in_valid,
    output wire        in_ready,
    input  wire        in_last,

    output wire [15:0] out_re,
    output wire [15:0] out_im,
    output wire        out_valid,
    input  wire        out_ready,
    output wire        out_last
);
    function [15:0] neg16;
        input [15:0] x;
        begin
            if (x == 16'h8000) neg16 = 16'h8000;
            else neg16 = (~x) + 16'h0001;
        end
    endfunction

    // ----------------------------
    // Config channel
    // ----------------------------
    reg cfg_done;
    wire [15:0] cfg_tdata  = {5'b0, SCALE_SCH10, 1'b1}; // bit0=1 => IFFT
    wire        cfg_tvalid = !cfg_done;
    wire        cfg_tready;

    // ----------------------------
    // Input prepare
    // ----------------------------
    wire [15:0] in_im_adj16   = (PY_MODE != 0) ? neg16(in_im) : in_im;
    wire [31:0] core_in_tdata = {in_im_adj16, in_re};

    wire        din_valid = in_valid && cfg_done;
    wire        din_last  = in_last  && din_valid;

    // ----------------------------
    // AXIS input register slice (1-deep, fully registered, no bypass)
    // 目的：切断 upstream reg -> IP internal fifo_wr_data_reg 的长路径/路由
    // ----------------------------
    reg         s0_valid_r;
    reg [31:0]  s0_tdata_r;
    reg         s0_tlast_r;

    wire        data_in_ready_core;     // IP 的 s_axis_data_tready
    wire        s0_ready = (~s0_valid_r) || data_in_ready_core;

    // 对上游：只有 cfg_done 且 slice 能接收时才 ready
    assign in_ready = cfg_done && s0_ready;

    always @(posedge clk) begin
        if (!rst_n) begin
            s0_valid_r <= 1'b0;
            s0_tdata_r <= 32'd0;
            s0_tlast_r <= 1'b0;
        end else if (s0_ready) begin
            // 当 slice 可写入（空 或 下游ready）时，装载新的 s_axis beat
            s0_valid_r <= din_valid;
            if (din_valid) begin
                s0_tdata_r <= core_in_tdata;
                s0_tlast_r <= din_last;
            end else begin
                s0_tlast_r <= 1'b0;
            end
        end
    end

    // ----------------------------
    // Output buffer (原逻辑保持)
    // ----------------------------
    wire [31:0] core_tdata;
    wire        core_tvalid;
    wire        core_tlast;

    reg  [15:0] out_re_r;
    reg  [15:0] out_im_r;
    reg         out_valid_r;
    reg         out_last_r;

    wire buf_ready   = (!out_valid_r) || out_ready;
    wire core_tready = buf_ready;

    wire [15:0] core_re16     = core_tdata[15:0];
    wire [15:0] core_im16     = core_tdata[31:16];
    wire [15:0] core_im_adj16 = (PY_MODE != 0) ? neg16(core_im16) : core_im16;

    always @(posedge clk) begin
        if (!rst_n) begin
            out_re_r    <= 16'd0;
            out_im_r    <= 16'd0;
            out_valid_r <= 1'b0;
            out_last_r  <= 1'b0;
        end else if (buf_ready) begin
            out_valid_r <= core_tvalid;
            if (core_tvalid) begin
                out_re_r   <= core_re16;
                out_im_r   <= core_im_adj16;
                out_last_r <= core_tlast;
            end else begin
                out_last_r <= 1'b0;
            end
        end
    end

    assign out_re    = out_re_r;
    assign out_im    = out_im_r;
    assign out_valid = out_valid_r;
    assign out_last  = out_last_r;

    // ----------------------------
    // cfg_done state machine (原逻辑保持)
    // ----------------------------
    always @(posedge clk) begin
        if (!rst_n) cfg_done <= 1'b0;
        else begin
            if (!cfg_done) begin
                if (cfg_tvalid && cfg_tready) cfg_done <= 1'b1;
            end else if (CFG_EACH_FRAME != 0) begin
                // 注意：这里用“进入 slice 的 last”来判定一帧结束更一致
                if (din_valid && in_ready && din_last) cfg_done <= 1'b0;
            end
        end
    end

    // ----------------------------
    // XFFT IP instance
    // ----------------------------
    xfft_0 u_ifft (
        .aclk(clk),
        .aresetn(rst_n),

        .s_axis_config_tdata(cfg_tdata),
        .s_axis_config_tvalid(cfg_tvalid),
        .s_axis_config_tready(cfg_tready),

        // 进 IP 的数据改为 slice 输出
        .s_axis_data_tdata(s0_tdata_r),
        .s_axis_data_tvalid(s0_valid_r),
        .s_axis_data_tready(data_in_ready_core),
        .s_axis_data_tlast(s0_tlast_r),

        .m_axis_data_tdata(core_tdata),
        .m_axis_data_tvalid(core_tvalid),
        .m_axis_data_tready(core_tready),
        .m_axis_data_tlast(core_tlast)
    );

endmodule