module proj_gbank32x16_to128_rom (
    input  wire         clk,
    input  wire [5:0]   addr,
    output reg  [5:0]   addr_q,
    output reg  [1535:0] dout
);
    localparam MEM = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/project_mem/stage1pro.mem";
    (* ram_style = "block" *) reg [1535:0] mem [0:31];
    initial begin
        $readmemh(MEM, mem);
    end

    reg [1535:0] data_pipe;
    reg [5:0]   addr_pipe;
    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule