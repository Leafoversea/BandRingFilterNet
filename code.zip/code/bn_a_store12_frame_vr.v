`timescale 1ns/1ps
`default_nettype none

module bn_a_store12_frame_vr #(
    parameter integer H  = 32,
    parameter integer W  = 32,
    parameter integer C  = 32,
    parameter integer DW = 12
)(
    input  wire          clk,
    input  wire          rst_n,

    input  wire          clr_frame,
    input  wire          allow_overwrite,

    input  wire          s_valid,
    output wire          s_ready,
    input  wire [9:0]    s_pix_idx,
    input  wire [5:0]    s_och,
    input  wire [DW-1:0] s_data,
    output reg           frame_full,

    input  wire          rd_en,
    input  wire [9:0]    rd_pix_idx,
    input  wire [5:0]    rd_och,
    output reg           rd_valid,
    output reg  [DW-1:0] rd_data,

    input  wire          rb_en,
    input  wire          rb_we,
    input  wire [9:0]    rb_pix_idx,
    input  wire [5:0]    rb_och,
    input  wire [DW-1:0] rb_wdata,
    output reg           rb_valid,
    output reg  [DW-1:0] rb_rdata
);
    localparam integer AW    = 15;
    localparam integer PIXN  = H*W;
    localparam integer DEPTH = PIXN*C;

    wire [AW-1:0] s_idx  = {s_och[4:0],  s_pix_idx};
    wire [AW-1:0] rd_idx = {rd_och[4:0], rd_pix_idx};
    wire [AW-1:0] rb_idx = {rb_och[4:0], rb_pix_idx};

    wire can_write = (!frame_full) || (allow_overwrite != 1'b0);
    assign s_ready = can_write;
    wire s_fire = s_valid && s_ready;

    // --------------------------
    // frame_full / wr_cnt control
    // --------------------------
    reg [AW:0] wr_cnt;
    always @(posedge clk) begin
        if (!rst_n) begin
            frame_full <= 1'b0;
            wr_cnt     <= {(AW+1){1'b0}};
        end else begin
            if (clr_frame) begin
                frame_full <= 1'b0;
                wr_cnt     <= {(AW+1){1'b0}};
            end else begin
                if (s_fire && !frame_full) begin
                    if (wr_cnt == (DEPTH-1)) begin
                        wr_cnt     <= wr_cnt + 1'b1;
                        frame_full <= 1'b1;
                    end else begin
                        wr_cnt <= wr_cnt + 1'b1;
                    end
                end
            end
        end
    end

    // =========================================================
    // Simplified Data Path (Zero Cache Logic)
    // =========================================================
    // 逻辑级数大幅下降，时序裕量极大改善，吞吐量保持 100% 
    
    wire a_write_req = s_fire;
    wire a_rd_req    = frame_full && rd_en && (!a_write_req);
    
    wire b_en_req    = frame_full && rb_en;
    wire b_wr_req    = b_en_req && rb_we;
    wire b_rd_req    = b_en_req && (!rb_we);

    // --------------------------------------------------------------------
    // Port access muxes
    // --------------------------------------------------------------------
    wire         a_en   = a_write_req | a_rd_req;
    wire [0:0]   a_we   = a_write_req;
    wire [AW-1:0] a_addr = a_write_req ? s_idx : rd_idx;
    wire [DW-1:0] a_din  = s_data;

    wire         b_en   = b_wr_req | b_rd_req;
    wire [0:0]   b_we   = b_wr_req;
    wire [AW-1:0] b_addr = rb_idx;
    wire [DW-1:0] b_din  = rb_wdata;

    wire [DW-1:0] douta;
    wire [DW-1:0] doutb;

    // IP instance
    ram u_mem (
        .clka  (clk),
        .ena   (a_en),
        .wea   (a_we),
        .addra (a_addr),
        .dina  (a_din),
        .douta (douta),

        .clkb  (clk),
        .enb   (b_en),
        .web   (b_we),
        .addrb (b_addr),
        .dinb  (b_din),
        .doutb (doutb)
    );

    // --------------------------------------------------------------------
    // Port A & B Output Pipelines (Constant 2-Cycle Latency)
    // --------------------------------------------------------------------
    reg a_rd_req_d1;
    reg b_rd_req_d1;

    always @(posedge clk) begin
        if (!rst_n) begin
            a_rd_req_d1 <= 1'b0;
            rd_valid    <= 1'b0;
            rd_data     <= {DW{1'b0}};
        end else if (clr_frame) begin
            a_rd_req_d1 <= 1'b0;
            rd_valid    <= 1'b0;
        end else begin
            a_rd_req_d1 <= a_rd_req;
            rd_valid    <= a_rd_req_d1;
            if (a_rd_req_d1) begin
                rd_data <= douta;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            b_rd_req_d1 <= 1'b0;
            rb_valid    <= 1'b0;
            rb_rdata    <= {DW{1'b0}};
        end else if (clr_frame) begin
            b_rd_req_d1 <= 1'b0;
            rb_valid    <= 1'b0;
        end else begin
            b_rd_req_d1 <= b_rd_req;
            rb_valid    <= b_rd_req_d1;
            if (b_rd_req_d1) begin
                rb_rdata <= doutb;
            end
        end
    end

endmodule