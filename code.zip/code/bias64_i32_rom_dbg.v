`timescale 1ns/1ps
`default_nettype none

module bias64_i32_rom_dbg #(
    parameter        MEM_FILE      = ""
)(
    input  wire               clk,
    input  wire [5:0]         addr_in,   
    output reg  [5:0]         addr_q,    
    output reg  signed [31:0] dout       
);
    (* rom_style="distributed" *) reg signed [31:0] mem [0:63];

    initial begin
        $readmemh(MEM_FILE, mem);
    end

    always @(posedge clk) begin
        addr_q <= addr_in;
        dout   <= mem[addr_in];
    end
endmodule

`default_nettype wire