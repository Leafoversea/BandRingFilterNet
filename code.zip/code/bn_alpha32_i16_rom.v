module bn_alpha32_i16_rom #(
    parameter integer LAT = 1,
    parameter MEM_FILE = "E:/Desktop/ip_ring/save_to_FPGA/stage1/ring/bn_a_alpha_i16_q11.mem"
)(
    input  wire               clk,
    input  wire               en,
    input  wire [4:0]         addr,
    output reg  [4:0]         addr_q,
    output reg  signed [15:0] dout
);
    // --- 关键修改点：
    // 1) LAT 裁剪到 [1..16]；
    // 2) 移位循环只跑到 (LAT_E-1)，避免无谓 16 级全移位。
    localparam integer LAT_RAW = (LAT < 1)  ? 1  : LAT;
    localparam integer LAT_E   = (LAT_RAW > 16) ? 16 : LAT_RAW;

    reg signed [15:0] mem [0:31];
    integer k;
    initial begin
        for (k=0; k<32; k=k+1) mem[k] = 16'sd0;
        $readmemh(MEM_FILE, mem);
    end

    reg signed [15:0] data_pipe [0:15];
    reg [4:0]         addr_pipe [0:15];
    integer t;

    always @(posedge clk) begin
        if (en) begin
            data_pipe[0] <= mem[addr];
            addr_pipe[0] <= addr;

            // 仅移位到有效深度
            for (t=1; t<LAT_E; t=t+1) begin
                data_pipe[t] <= data_pipe[t-1];
                addr_pipe[t] <= addr_pipe[t-1];
            end

            // 输出选择保持等价（LAT=1 => index 0）
            dout   <= data_pipe[LAT_E-1];
            addr_q <= addr_pipe[LAT_E-1];
        end
    end
endmodule
module bn_beta32_i16_rom #(
    parameter integer LAT = 1,
    parameter MEM_FILE = "E:/Desktop/ip_ring/save_to_FPGA/stage1/ring/bn_a_beta_i16_q8.mem"
)(
    input  wire               clk,
    input  wire               en,
    input  wire [4:0]         addr,
    output reg  [4:0]         addr_q,
    output reg  signed [15:0] dout
);
    // --- 关键修改点同 alpha ROM ---
    localparam integer LAT_RAW = (LAT < 1)  ? 1  : LAT;
    localparam integer LAT_E   = (LAT_RAW > 16) ? 16 : LAT_RAW;

    reg signed [15:0] mem [0:31];
    integer k;
    initial begin
        for (k=0; k<32; k=k+1) mem[k] = 16'sd0;
        $readmemh(MEM_FILE, mem);
    end

    reg signed [15:0] data_pipe [0:15];
    reg [4:0]         addr_pipe [0:15];
    integer t;

    always @(posedge clk) begin
        if (en) begin
            data_pipe[0] <= mem[addr];
            addr_pipe[0] <= addr;

            for (t=1; t<LAT_E; t=t+1) begin
                data_pipe[t] <= data_pipe[t-1];
                addr_pipe[t] <= addr_pipe[t-1];
            end

            dout   <= data_pipe[LAT_E-1];
            addr_q <= addr_pipe[LAT_E-1];
        end
    end
endmodule