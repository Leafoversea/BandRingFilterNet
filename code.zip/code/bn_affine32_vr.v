`default_nettype wire
module bn_affine32_vr #(
    parameter integer ROM_LAT = 1,
    parameter integer FX = 8,
    parameter integer FY = 8,
    parameter integer FA = 11,
    parameter integer USE_RELU = 0,
    parameter [8*256-1:0] ALPHA_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ring/bn_a_alpha_i16_q11.mem",
    parameter [8*256-1:0] BETA_MEM_FILE  = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ring/bn_a_beta_i16_q8.mem"
)(
    input  wire               clk,
    input  wire               rst_n,

    input  wire               in_valid,
    output wire               in_ready,
    input  wire [5:0]         in_och,
    input  wire [9:0]         in_pix_idx,
    input  wire signed [15:0] in_data,

    output wire               out_valid,
    input  wire               out_ready,
    output wire [5:0]         out_och,
    output wire [9:0]         out_pix_idx,
    output wire signed [15:0] out_data
);
    localparam integer DEL_RAW  = (ROM_LAT < 1)  ? 1  : ROM_LAT;
    localparam integer DEL      = (DEL_RAW > 16) ? 16 : DEL_RAW;
    localparam integer EXTRA_PIPE = 1;
    localparam integer PIPE_MAX   = (DEL + EXTRA_PIPE > 16) ? 16 : (DEL + EXTRA_PIPE);
    localparam integer SHIFT_DOWN = (FX + FA - FY);

    function signed [15:0] sat16s_fast;
        input signed [31:0] x;
        reg ov_pos, ov_neg;
        begin
            ov_pos = (~x[31]) & (|x[30:15]);
            ov_neg = ( x[31]) & (~&x[30:15]);
            if (ov_pos)       sat16s_fast = 16'sh7FFF;
            else if (ov_neg)  sat16s_fast = 16'sh8000;
            else              sat16s_fast = x[15:0];
        end
    endfunction

    function signed [15:0] relu_sat16s_fast;
        input signed [31:0] x;
        begin
            if (USE_RELU != 0 && x[31]) relu_sat16s_fast = 16'sd0;
            else                        relu_sat16s_fast = sat16s_fast(x);
        end
    endfunction

    function integer clog2;
        input integer v;
        integer r;
        begin
            r = 0;
            v = v - 1;
            while (v > 0) begin
                v = v >> 1;
                r = r + 1;
            end
            clog2 = (r < 1) ? 1 : r;
        end
    endfunction

    localparam integer OFIFO_DEPTH = 8;
    localparam integer OFIFO_AW    = clog2(OFIFO_DEPTH);

    reg [OFIFO_AW-1:0] rd_ptr, wr_ptr;
    reg [3:0]          ofifo_cnt;
    
    reg [5:0]         ofifo_och     [0:OFIFO_DEPTH-1];
    reg [9:0]         ofifo_pix_idx [0:OFIFO_DEPTH-1];
    reg signed [15:0] ofifo_data    [0:OFIFO_DEPTH-1];
    
    wire fifo_full  = (ofifo_cnt == 4'd8); 
    wire fifo_empty = (ofifo_cnt == 4'd0);

    // =========================================================================
    // 核心修改1：无条件 Pipeline Register Slice，绝对斩断组合逻辑时序路径
    // =========================================================================
    reg skid_valid;
    reg [5:0] skid_och;
    reg [9:0] skid_pix;
    reg signed [15:0] skid_data;

    wire obase_valid = !fifo_empty;
    // 当下游准备好，或者本级寄存器为空时，允许从FIFO中读取数据
    wire obase_ready = !skid_valid || out_ready;
    wire pop         = obase_valid && obase_ready;

    always @(posedge clk) begin
        if (!rst_n) begin
            skid_valid <= 1'b0;
            skid_och   <= 6'd0;
            skid_pix   <= 10'd0;
            skid_data  <= 16'd0;
        end else begin
            if (pop) begin
                skid_valid <= 1'b1;
                skid_och   <= ofifo_och[rd_ptr[2:0]];
                skid_pix   <= ofifo_pix_idx[rd_ptr[2:0]];
                skid_data  <= ofifo_data[rd_ptr[2:0]];
            end else if (out_ready) begin
                skid_valid <= 1'b0;
            end
        end
    end

    assign out_valid   = skid_valid;
    assign out_och     = skid_och;
    assign out_pix_idx = skid_pix;
    assign out_data    = skid_data;

    // =========================================================================

    wire can_step = !fifo_full;
    assign in_ready = can_step;
    
    wire in_fire = in_valid && in_ready;
    reg                 v_s2;

    wire push = v_s2 && can_step;
    
    reg v_pipe   [0:PIPE_MAX];
    reg [5:0] och_pipe [0:PIPE_MAX];
    reg [9:0] pix_pipe [0:PIPE_MAX];
    reg signed [15:0] x_pipe [0:PIPE_MAX];
    integer i;
    
    reg [4:0] addr_hold;
    wire [4:0] rom_addr = in_fire ? in_och[4:0] : addr_hold;
    wire [4:0] a_addr_q, b_addr_q;
    wire signed [15:0] alpha_q;
    wire signed [15:0] beta16_q;

    bn_alpha32_i16_rom #(.LAT(ROM_LAT), .MEM_FILE(ALPHA_MEM_FILE)) u_a (
        .clk(clk), .en(can_step), .addr(rom_addr), .addr_q(a_addr_q), .dout(alpha_q)
    );
    bn_beta32_i16_rom #(.LAT(ROM_LAT), .MEM_FILE(BETA_MEM_FILE)) u_b16 (
        .clk(clk), .en(can_step), .addr(rom_addr), .addr_q(b_addr_q), .dout(beta16_q)
    );
    
    wire signed [31:0] mul32 = $signed(x_pipe[DEL]) * $signed(alpha_q);
    wire signed [31:0] ra32  = (SHIFT_DOWN <= 0) ? 32'sd0 : (32'sd1 <<< (SHIFT_DOWN-1));
    wire signed [31:0] mul_r = (SHIFT_DOWN <= 0) ? mul32  : (mul32 + ra32);
    wire signed [15:0] mul_s = (SHIFT_DOWN <= 0) ? mul32[15:0] : (mul_r >>> SHIFT_DOWN);
    
    reg                 v_s1;
    reg [5:0]           och_s1;
    reg [9:0]           pix_s1;
    reg signed [15:0]   mul_s1;
    reg signed [15:0]   beta_s1;

    reg [5:0]           och_s2;
    reg [9:0]           pix_s2;
    reg signed [31:0]   y32_s2;
    wire signed [15:0] push_data = relu_sat16s_fast(y32_s2);

    always @(posedge clk) begin
        if (!rst_n) begin
            rd_ptr    <= {OFIFO_AW{1'b0}};
            wr_ptr    <= {OFIFO_AW{1'b0}};
            ofifo_cnt <= 4'd0;
        end else begin
            case ({push, pop})
                2'b10: begin
                    wr_ptr    <= wr_ptr + 1'b1;
                    ofifo_cnt <= ofifo_cnt + 4'd1;
                end
                2'b01: begin
                    rd_ptr    <= rd_ptr + 1'b1;
                    ofifo_cnt <= ofifo_cnt - 4'd1;
                end
                2'b11: begin
                    wr_ptr    <= wr_ptr + 1'b1;
                    rd_ptr    <= rd_ptr + 1'b1;
                end
                default: ;
            endcase
        end
    end

    always @(posedge clk) begin
        if (push) begin
            ofifo_och[wr_ptr[2:0]]     <= och_s2;
            ofifo_pix_idx[wr_ptr[2:0]] <= pix_s2;
            ofifo_data[wr_ptr[2:0]]    <= push_data;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            addr_hold <= 5'd0;
            for (i=0; i<=PIPE_MAX; i=i+1) begin
                v_pipe[i] <= 1'b0;
            end
            v_s1 <= 1'b0;
            v_s2 <= 1'b0;
        end else if (can_step) begin
            if (in_fire) addr_hold <= in_och[4:0];
            v_pipe[0]   <= in_fire;
            och_pipe[0] <= in_och;       
            pix_pipe[0] <= in_pix_idx;
            x_pipe[0]   <= in_data;
            for (i=1; i<=PIPE_MAX; i=i+1) begin
                v_pipe[i]   <= v_pipe[i-1];
                och_pipe[i] <= och_pipe[i-1];
                pix_pipe[i] <= pix_pipe[i-1];
                x_pipe[i]   <= x_pipe[i-1];
            end

            v_s1    <= v_pipe[DEL];
            och_s1  <= och_pipe[DEL];
            pix_s1  <= pix_pipe[DEL];
            mul_s1  <= mul_s;
            beta_s1 <= beta16_q;
            v_s2    <= v_s1;
            och_s2  <= och_s1;
            pix_s2  <= pix_s1;
            y32_s2  <= $signed(mul_s1) + $signed(beta_s1);
        end
    end
endmodule