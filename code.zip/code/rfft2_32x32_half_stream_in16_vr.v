`timescale 1ns/1ps
`default_nettype none

module rfft2_32x32_half_stream_in16_vr #(
    parameter integer H = 32,
    parameter integer W = 32,
    parameter integer C = 32,
    parameter [9:0] ROW_SCALE_SCH10 = 10'b0000000000,
    parameter [9:0] COL_SCALE_SCH10 = 10'b0000000001,
    parameter       PY_MODE = 1'b1,
    parameter integer DBG_EN  = 0,
    parameter integer DBG_MAX = 256
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clr_frame,
    input  wire        s_valid,
    output wire        s_ready,
    input  wire [9:0]  s_pix_idx,
    input  wire [5:0]  s_och,
    input  wire [15:0] s_data,
    output reg         busy,
    output wire        m_valid,
    input  wire        m_ready,
    output wire [5:0]  m_och,
    output wire [4:0]  m_ky,
    output wire [4:0]  m_kx,
    output wire [15:0] m_re,
    output wire [15:0] m_im,
    output wire        m_last
);

    function integer clog2;
        input integer value;
        integer i;
        begin
            value = value - 1;
            for (i = 0; value > 0; i = i + 1)
                value = value >> 1;
            clog2 = i;
        end
    endfunction

    localparam integer PIXN = H*W;
    localparam integer KXH  = (W/2) + 1;      
    
    localparam integer ROWBUF_DEPTH = 512;    
    localparam integer ROWBUF_AW    = 9;
    localparam integer FFTW = 16;
    localparam integer CDW  = 2*FFTW;

    (* ram_style="block" *) reg [CDW-1:0] row_mem [0:ROWBUF_DEPTH-1];
    (* ram_style="distributed" *) reg [15:0] col_nyquist_mem [0:31];

    // =========================================================================
    // 边界隔离：轻量级 Skid Buffer (完全切断跨模块布线延迟)
    // =========================================================================
    reg [1:0]  skid_st;
    reg [31:0] r0, r1;
    wire [31:0] s_in_bus = {s_och, s_pix_idx, s_data};
    
    wire int_ready; // 内部模块的真实 Ready
    
    // 对外握手信号
    assign s_ready = (skid_st != 2'd2);
    
    // 内部剥离后的纯净信号
    wire        int_valid   = (skid_st != 2'd0);
    wire [5:0]  int_och     = r0[31:26];
    wire [9:0]  int_pix_idx = r0[25:16];
    wire [15:0] int_s_data  = r0[15:0];

    always @(posedge clk) begin
        if (!rst_n) begin
            skid_st <= 2'd0;
            r0 <= 32'd0;
            r1 <= 32'd0;
        end else if (clr_frame) begin
            skid_st <= 2'd0;
        end else begin
            case (skid_st)
                2'd0: begin
                    if (s_valid) begin
                        skid_st <= 2'd1;
                        r0 <= s_in_bus;
                    end
                end
                2'd1: begin
                    if (s_valid && !int_ready) begin
                        skid_st <= 2'd2;
                        r1 <= s_in_bus;
                    end else if (!s_valid && int_ready) begin
                        skid_st <= 2'd0;
                    end else if (s_valid && int_ready) begin
                        r0 <= s_in_bus;
                    end
                end
                2'd2: begin
                    if (int_ready) begin
                        skid_st <= 2'd1;
                        r0 <= r1;
                    end
                end
                default: skid_st <= 2'd0;
            endcase
        end
    end

    // =========================================================================
    // 核心控制逻辑
    // =========================================================================
    reg [2:0]  st;
    localparam [2:0] ST_IDLE = 3'd0;
    localparam [2:0] ST_ROW  = 3'd1;
    localparam [2:0] ST_MIX  = 3'd2;
    localparam [2:0] ST_COL  = 3'd3;
    localparam [2:0] ST_DONE = 3'd4;

    reg [5:0]  och_cur;
    reg [9:0]  row_in_cnt;
    reg        row_in_done;
    reg        row_out_done;
    reg [4:0]  row_out_x;
    reg [4:0]  row_out_y;

    reg        kx_ready_valid;
    reg [4:0]  max_kx_ready;

    wire [4:0] row_in_x = row_in_cnt[4:0];
    wire       row_in_range = !row_in_done;
    
    // 此时比较器使用的是经过打拍、无布线延迟的内部寄存器
    wire       row_match    = (int_och == och_cur) && (int_pix_idx == row_in_cnt);

    wire signed [15:0] row_fft_in_re = $signed(int_s_data);
    wire signed [15:0] row_fft_in_im = 16'sd0;

    wire        row_fft_in_valid = (st == ST_ROW) && row_in_range && int_valid && row_match;
    wire        row_fft_in_ready;
    wire        row_fft_in_last  = (row_in_x == (W-1));

    wire [15:0] row_fft_out_re;
    wire [15:0] row_fft_out_im;
    wire        row_fft_out_valid;
    wire        row_fft_out_last;
    wire        row_fft_out_ready = 1'b1;

    // 反馈给 Skid Buffer 的内部 ready
    assign int_ready = (st == ST_ROW) && row_in_range && row_fft_in_ready;

    wire row_in_fire  = row_fft_in_valid && row_fft_in_ready;
    wire row_out_fire = row_fft_out_valid && row_fft_out_ready;

    fft32_xfft_axis16_fft_sep #(
        .IN_DW(16),
        .SCALE_SCH10(ROW_SCALE_SCH10),
        .CFG_EACH_FRAME(1'b0),
        .PY_MODE(PY_MODE)
    ) u_row_fft (
        .clk(clk), .rst_n(rst_n),
        .in_re(row_fft_in_re), .in_im(row_fft_in_im),
        .in_valid(row_fft_in_valid), .in_ready(row_fft_in_ready), .in_last(row_fft_in_last),
        .out_re(row_fft_out_re), .out_im(row_fft_out_im),
        .out_valid(row_fft_out_valid), .out_ready(row_fft_out_ready), .out_last(row_fft_out_last),
        .event_frame_started(), .event_tlast_unexpected(), .event_tlast_missing(),
        .event_status_channel_halt(), .event_data_in_channel_halt(), .event_data_out_channel_halt()
    );

    // ---------------- COL address generator ----------------
    reg        col_in_done;
    reg [4:0]  col_in_ky;
    reg [4:0]  col_in_kx;

    reg        col_out_done;
    reg [4:0]  col_out_ky;
    reg [4:0]  col_out_kx;

    reg [CDW-1:0] col_rd_data;
    reg [15:0]    col_nyquist_rd_data;
    reg           col_rd_is_nyquist;
    reg           col_rd_valid;
    reg           col_rd_last;

    reg [8:0] col_rd_addr_reg;
    wire [8:0] col_addr = col_rd_addr_reg;

    wire signed [15:0] col_fft_in_re = col_rd_is_nyquist ? $signed(col_nyquist_rd_data) : $signed(col_rd_data[15:0]);
    wire signed [15:0] col_fft_in_im = col_rd_is_nyquist ? 16'sd0 : $signed(col_rd_data[31:16]);
    wire        col_fft_in_ready;

    wire [15:0] col_fft_out_re;
    wire [15:0] col_fft_out_im;
    wire        col_fft_out_valid;

    wire        col_can_step = ((st == ST_MIX) || (st == ST_COL)) &&
                               ((!col_rd_valid) || (col_rd_valid && col_fft_in_ready));
    wire        col_kx_ready = kx_ready_valid && (col_in_kx <= max_kx_ready);
    wire        col_issue_en = col_can_step && !col_in_done && col_kx_ready;

    // ---------------- output buffer ----------------
    reg         m_valid_r;
    reg [5:0]   m_och_r;
    reg [4:0]   m_ky_r;
    reg [4:0]   m_kx_r;
    reg [15:0]  m_re_r;
    reg [15:0]  m_im_r;
    reg         m_last_r;

    assign m_valid = m_valid_r;
    assign m_och   = m_och_r;
    assign m_ky    = m_ky_r;
    assign m_kx    = m_kx_r;
    assign m_re    = m_re_r;
    assign m_im    = m_im_r;
    assign m_last  = m_last_r;

    wire buf_ready = (!m_valid_r) || m_ready;
    wire col_fft_out_ready = buf_ready && !col_out_done;
    wire col_out_fire = col_fft_out_valid && col_fft_out_ready;

    fft32_xfft_axis16_fft_sep #(
        .IN_DW(16), .SCALE_SCH10(COL_SCALE_SCH10), .CFG_EACH_FRAME(1'b0), .PY_MODE(PY_MODE)
    ) u_col_fft (
        .clk(clk), .rst_n(rst_n),
        .in_re(col_fft_in_re), .in_im(col_fft_in_im),
        .in_valid(col_rd_valid), .in_ready(col_fft_in_ready), .in_last(col_rd_last),
        .out_re(col_fft_out_re), .out_im(col_fft_out_im),
        .out_valid(col_fft_out_valid), .out_ready(col_fft_out_ready), .out_last(),
        .event_frame_started(), .event_tlast_unexpected(), .event_tlast_missing(),
        .event_status_channel_halt(), .event_data_in_channel_halt(), .event_data_out_channel_halt()
    );

    reg [8:0] row_wr_addr_reg;
    wire [8:0] row_wr_addr = row_wr_addr_reg;

    wire row_drain_done = row_out_done;
    wire row_col0_done_pulse = row_out_fire && (row_out_y == (H-1)) && (row_out_x == 5'd0);
    wire col_all_done = col_in_done && col_out_done && (!m_valid_r);

    always @(posedge clk) begin
        if (((st == ST_ROW) || (st == ST_MIX)) && row_out_fire) begin
            if (row_out_x < 5'd16) begin
                row_mem[row_wr_addr] <= {row_fft_out_im, row_fft_out_re};
            end else if (row_out_x == 5'd16) begin
                col_nyquist_mem[row_out_y] <= row_fft_out_re;
            end
        end
        if (col_issue_en) begin
            col_rd_data <= row_mem[col_addr];
            col_nyquist_rd_data <= col_nyquist_mem[col_in_ky];
            col_rd_is_nyquist <= (col_in_kx == 5'd16);
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            st         <= ST_IDLE;
            busy       <= 1'b0;
            och_cur    <= 6'd0;

            row_in_cnt   <= 10'd0;
            row_in_done  <= 1'b0;
            row_out_done <= 1'b0;
            row_out_x    <= 5'd0;  row_out_y   <= 5'd0;
            row_wr_addr_reg <= 9'd0; 

            kx_ready_valid <= 1'b0;
            max_kx_ready <= 5'd0;

            col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
            col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
            col_rd_addr_reg <= 9'd0;

            col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
            m_valid_r <= 1'b0; m_och_r   <= 6'd0;
            m_ky_r    <= 5'd0; m_kx_r    <= 5'd0;
            m_re_r    <= 16'd0; m_im_r    <= 16'd0; m_last_r  <= 1'b0;
        end else begin
            if (clr_frame) begin
                st         <= ST_IDLE;
                busy       <= 1'b0; och_cur    <= 6'd0;
                row_in_cnt   <= 10'd0; row_in_done  <= 1'b0;
                row_out_done <= 1'b0;
                row_out_x    <= 5'd0;  row_out_y   <= 5'd0;
                row_wr_addr_reg <= 9'd0; 
                kx_ready_valid <= 1'b0; max_kx_ready <= 5'd0;
                col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
                col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
                col_rd_addr_reg <= 9'd0;
                col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
                m_valid_r <= 1'b0; m_last_r  <= 1'b0;
            end else begin
                if (st == ST_IDLE) begin
                    busy      <= 1'b0;
                    m_valid_r <= 1'b0; m_last_r  <= 1'b0;
                    if (int_valid) begin
                        st      <= ST_ROW;
                        busy    <= 1'b1; och_cur <= int_och;
                        row_in_cnt   <= 10'd0; row_in_done  <= 1'b0;
                        row_out_done <= 1'b0;
                        row_out_x    <= 5'd0;  row_out_y   <= 5'd0;
                        row_wr_addr_reg <= 9'd0;
                        kx_ready_valid <= 1'b0; max_kx_ready <= 5'd0;
                        col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
                        col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
                        col_rd_addr_reg <= 9'd0;
                        col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
                        m_valid_r <= 1'b0; m_last_r  <= 1'b0;
                    end
                end

                if ((st == ST_ROW) || (st == ST_MIX)) begin
                    if (st == ST_ROW) begin
                        if (row_in_fire) begin
                            if (row_in_cnt == 10'd1023) begin
                                row_in_done <= 1'b1;
                                row_in_cnt  <= row_in_cnt + 10'd1;
                            end else begin
                                row_in_cnt  <= row_in_cnt + 10'd1;
                            end
                        end
                    end

                    if (row_out_fire) begin
                        if (row_out_x < 5'd16) begin
                            row_wr_addr_reg <= row_wr_addr_reg + 9'd1; 
                        end
                        if (row_out_x < KXH[4:0]) begin
                            if (row_out_y == (H-1)) begin
                                kx_ready_valid <= 1'b1;
                                max_kx_ready   <= row_out_x;
                            end
                        end
                        if (row_out_x == (W-1)) begin
                            row_out_x <= 5'd0;
                            if (row_out_y < (H-1)) row_out_y <= row_out_y + 5'd1;
                        end else begin
                            row_out_x <= row_out_x + 5'd1;
                        end
                        
                        if ((row_out_x == (W-1)) && (row_out_y == (H-1))) begin
                            row_out_done <= 1'b1;
                        end
                    end

                    if (st == ST_ROW) begin
                        if (row_col0_done_pulse) begin
                            st <= ST_MIX;
                            col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
                            col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
                            col_rd_addr_reg <= 9'd0;
                            col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
                            m_valid_r <= 1'b0; m_last_r  <= 1'b0;
                        end else if (row_in_done && row_out_done) begin
                            st <= ST_COL;
                            col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
                            col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
                            col_rd_addr_reg <= 9'd0;
                            col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
                            m_valid_r <= 1'b0; m_last_r  <= 1'b0;
                        end
                    end else begin
                        if (row_drain_done) begin
                            st <= ST_COL;
                        end
                    end
                end

                if ((st == ST_MIX) || (st == ST_COL)) begin
                    if (col_can_step) begin
                        if (col_issue_en) begin
                            col_rd_valid <= 1'b1;
                            col_rd_last  <= (col_in_ky == (H-1));
                            
                            if (col_in_ky == (H-1)) begin
                                col_in_ky <= 5'd0;
                                col_in_kx <= col_in_kx + 5'd1;
                                col_rd_addr_reg <= {4'b0, col_in_kx} + 9'd1;
                            end else begin
                                col_in_ky <= col_in_ky + 5'd1;
                                col_rd_addr_reg <= col_rd_addr_reg + 9'd16; 
                            end
                            
                            if ((col_in_ky == (H-1)) && (col_in_kx == (KXH-1))) begin
                                col_in_done <= 1'b1;
                            end
                        end else begin
                            col_rd_valid <= 1'b0;
                            col_rd_last  <= 1'b0;
                        end
                    end
                end

                if ((st == ST_MIX) || (st == ST_COL)) begin
                    if (buf_ready) begin
                        if (!col_out_done) begin
                            m_valid_r <= col_fft_out_valid;
                            if (col_fft_out_valid) begin
                                m_och_r  <= och_cur;
                                m_ky_r   <= col_out_ky;
                                m_kx_r   <= col_out_kx;
                                m_re_r   <= col_fft_out_re;
                                m_im_r   <= col_fft_out_im;
                                m_last_r <= ((och_cur == (C-1)) && (col_out_kx == (KXH-1)) && (col_out_ky == (H-1))) ? 1'b1 : 1'b0;
                            end else begin
                                m_last_r <= 1'b0;
                            end
                        end else begin
                            m_valid_r <= 1'b0;
                            m_last_r  <= 1'b0;
                        end
                    end

                    if (col_out_fire) begin
                        if (col_out_ky == (H-1)) begin
                            col_out_ky <= 5'd0;
                            col_out_kx <= col_out_kx + 5'd1;
                        end else begin
                            col_out_ky <= col_out_ky + 5'd1;
                        end
                        
                        if ((col_out_ky == (H-1)) && (col_out_kx == (KXH-1))) begin
                            col_out_done <= 1'b1;
                        end
                    end

                    if (col_all_done && row_drain_done) begin
                        if (och_cur == (C-1)) begin
                            st   <= ST_DONE;
                            busy <= 1'b0;
                        end else begin
                            och_cur <= och_cur + 6'd1;
                            st      <= ST_ROW;
                            row_in_cnt   <= 10'd0; row_in_done  <= 1'b0;
                            row_out_done <= 1'b0;
                            row_out_x    <= 5'd0;  row_out_y   <= 5'd0;
                            row_wr_addr_reg <= 9'd0;
                            kx_ready_valid <= 1'b0; max_kx_ready <= 5'd0;
                            col_in_done <= 1'b0; col_in_ky   <= 5'd0; col_in_kx   <= 5'd0;
                            col_out_done<= 1'b0; col_out_ky  <= 5'd0; col_out_kx  <= 5'd0;
                            col_rd_addr_reg <= 9'd0;
                            col_rd_valid <= 1'b0; col_rd_last  <= 1'b0;
                            m_valid_r <= 1'b0; m_last_r  <= 1'b0;
                        end
                    end
                end

                if (st == ST_DONE) begin
                    m_valid_r <= 1'b0;
                    m_last_r  <= 1'b0;
                    busy      <= 1'b0;
                end
            end
        end
    end
endmodule