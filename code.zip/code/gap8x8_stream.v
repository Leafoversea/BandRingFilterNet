`timescale 1ns / 1ps

module gap8x8_stream #(
    parameter integer C        = 64,
    parameter integer H        = 8,
    parameter integer W        = 8,
    parameter integer IN_W     = 13,
    parameter integer OUT_W    = 16,
    parameter integer PIX_W    = 6,   
    parameter integer CH_W     = 6    
)(
    input  wire                    clk,
    input  wire                    rst_n,

    input  wire                    s_valid,
    output wire                    s_ready,
    input  wire [PIX_W-1:0]        s_pix_idx,
    input  wire [CH_W-1:0]         s_och,
    input  wire signed [IN_W-1:0]  s_data,
    input  wire                    s_last,

    output reg                     m_valid,
    input  wire                    m_ready,
    output reg  [0:0]              m_pix_idx,   
    output reg  [CH_W-1:0]         m_och,
    output reg  signed [OUT_W-1:0] m_data,
    output reg                     m_last
);

    localparam integer PIXELS = H * W;
    localparam integer SUM_W  = IN_W + $clog2(PIXELS) + 1; // 20 bits
    
    // 计算移位的四舍五入常数 (移位 6，常数为 1 << 5 = 32)
    localparam signed [SUM_W-1:0] ROUND_OFFSET = 32;

    localparam [1:0]
        ST_RECV = 2'd0,
        ST_OUT  = 2'd1;

    reg [1:0] state;
    reg [CH_W-1:0] out_ch_idx;

    (* ram_style = "distributed" *) reg signed [SUM_W-1:0] sum_ch [0:C-1];

    integer i;
    initial begin
        for (i = 0; i < C; i = i + 1) begin
            // 巧用存储器初始值直接吸收四舍五入偏移量
            sum_ch[i] = ROUND_OFFSET; 
        end
    end

    // =========================================================================
    // [时序修复核心]：插入输入流水线打拍寄存器 (Input Pipeline Stage)
    // 目的：切断从上一级FIFO读出后经过长布线直达本模块加法器的关键路径
    // =========================================================================
    reg                    s_valid_r;
    reg [PIX_W-1:0]        s_pix_idx_r;
    reg [CH_W-1:0]         s_och_r;
    reg signed [IN_W-1:0]  s_data_r;
    reg                    s_last_r;

    // AXI-Stream 握手协议优化：
    // 当且仅当状态机在接收状态，且当前没有正在处理的 last 信号时，允许上游发送新数据
    assign s_ready = (state == ST_RECV) && !s_last_r;

    always @(posedge clk) begin
        if (!rst_n) begin
            s_valid_r   <= 1'b0;
            s_last_r    <= 1'b0;
            s_pix_idx_r <= {PIX_W{1'b0}};
            s_och_r     <= {CH_W{1'b0}};
            s_data_r    <= {IN_W{1'b0}};
        end else begin
            if (s_ready) begin
                s_valid_r   <= s_valid;
                s_last_r    <= s_valid & s_last; // 捕获有效的 last
                s_pix_idx_r <= s_pix_idx;
                s_och_r     <= s_och;
                s_data_r    <= s_data;
            end else if (state == ST_OUT) begin
                // 一旦进入计算输出状态，清空输入寄存器的有效标志，防止残留脏数据被运算
                s_valid_r   <= 1'b0;
                s_last_r    <= 1'b0;
            end
        end
    end

    // 纯物理硬件连线切片
    function automatic signed [OUT_W-1:0] gap_avg;
        input signed [SUM_W-1:0] x;
        reg signed [SUM_W-1:0] y;
        begin
            y = x >>> 6; 
            gap_avg = y[OUT_W-1:0];
        end
    endfunction

    // 状态机与输出逻辑
    always @(posedge clk) begin
        if (!rst_n) begin
            state      <= ST_RECV;
            out_ch_idx <= {CH_W{1'b0}};
            m_valid    <= 1'b0;
            m_pix_idx  <= 1'b0;
            m_och      <= {CH_W{1'b0}};
            m_data     <= {OUT_W{1'b0}};
            m_last     <= 1'b0;
        end else begin
            case (state)
                ST_RECV: begin
                    m_valid <= 1'b0;
                    m_last  <= 1'b0;

                    // 注意此处改为判断打拍后的 _r 信号
                    if (s_valid_r) begin
                        if (s_last_r) begin
                            out_ch_idx <= {CH_W{1'b0}};
                            state      <= ST_OUT;
                        end
                    end
                end

                ST_OUT: begin
                    if (!m_valid || (m_valid && m_ready)) begin
                        m_valid   <= 1'b1;
                        m_pix_idx <= 1'b0;
                        m_och     <= out_ch_idx;
                        m_data    <= gap_avg(sum_ch[out_ch_idx]); 
                        m_last    <= (out_ch_idx == C-1);

                        if (out_ch_idx == C-1) begin
                            out_ch_idx <= {CH_W{1'b0}};
                            state      <= ST_RECV;
                        end else begin
                            out_ch_idx <= out_ch_idx + 1'b1;
                        end
                    end
                end

                default: state <= ST_RECV;
            endcase
        end
    end

    // GAP 分布式 RAM 累加操作逻辑
    always @(posedge clk) begin
        if (state == ST_RECV) begin
            // 数据使用打拍后的 _r 信号计算
            if (s_valid_r) begin
                sum_ch[s_och_r] <= sum_ch[s_och_r] + s_data_r;
            end
        end 
        else if (state == ST_OUT) begin
            if (!m_valid || (m_valid && m_ready)) begin
                // 读取后重新刷入偏移量，免除所有加法运算
                sum_ch[out_ch_idx] <= ROUND_OFFSET; 
            end
        end
    end

endmodule