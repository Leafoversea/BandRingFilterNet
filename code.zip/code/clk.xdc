## 1. 时钟约束 (Timing Constraints)
# 定义输入时钟 board_clk 为 50MHz (周期为 20ns)
create_clock -period 20.000 -name board_clk [get_ports board_clk]

## 2. 电平标准约束 (IOSTANDARD Constraints)
# 统一将所有涉及到的 IO 设置为 LVCMOS33 (3.3V)
set_property IOSTANDARD LVCMOS33 [get_ports board_clk]
set_property IOSTANDARD LVCMOS33 [get_ports board_rst_n]
set_property IOSTANDARD LVCMOS33 [get_ports {led_out[*]}]

## 3. 物理引脚位置约束 (PACKAGE_PIN Constraints)
# 时钟与复位 [cite: 1, 2, 27]
set_property PACKAGE_PIN W19 [get_ports board_clk]
set_property PACKAGE_PIN D21 [get_ports board_rst_n]

# LED 输出接口 [cite: 1, 26, 27]
set_property PACKAGE_PIN U22 [get_ports {led_out[0]}]
set_property PACKAGE_PIN V22 [get_ports {led_out[1]}]
set_property PACKAGE_PIN W21 [get_ports {led_out[2]}]
set_property PACKAGE_PIN W22 [get_ports {led_out[3]}]
set_property PACKAGE_PIN Y21 [get_ports {led_out[4]}]
set_property PACKAGE_PIN Y22 [get_ports {led_out[5]}]
set_property PACKAGE_PIN N13 [get_ports {led_out[6]}]
set_property PACKAGE_PIN N17 [get_ports {led_out[7]}]
