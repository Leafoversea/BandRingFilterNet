module bias_param_rom #(
    parameter integer DEPTH      = 48,
    parameter integer ADDR_WIDTH = 6,
    parameter [8*256-1:0] MEM_BASE_PATH = "",
    parameter [8*64-1:0]  FILE_NAME = "/bias.mem"
)(
    input  wire                   clk,
    input  wire [ADDR_WIDTH-1:0]  addr,
    output reg  [ADDR_WIDTH-1:0]  addr_q,
    output reg  [31:0]            dout
);
    localparam [8*320-1:0] BIAS_MEM_FILE = {MEM_BASE_PATH, FILE_NAME};

    (* rom_style = "distributed" *) reg [31:0] mem [0:DEPTH-1];

    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0]           data_pipe;
    reg [ADDR_WIDTH-1:0] addr_pipe;
    integer t;

    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule


module weight_param_rom #(
    parameter integer DEPTH      = 768,
    parameter integer ADDR_WIDTH = 10,
    parameter [8*256-1:0] MEM_BASE_PATH = "",
    parameter [8*64-1:0]  FILE_NAME = "/w_all.mem"
)(
    input  wire                   clk,
    input  wire [ADDR_WIDTH-1:0]  addr,
    output reg  [ADDR_WIDTH-1:0]  addr_q,
    output reg  [127:0]           dout
);
    localparam [8*320-1:0] W_ALL_FILE = {MEM_BASE_PATH, FILE_NAME};

    (* rom_style = "distributed" *) reg [127:0] mem [0:DEPTH-1];

    initial begin
        $readmemh(W_ALL_FILE, mem);
    end
    
    always @(*) begin
        dout   = mem[addr];
        addr_q = addr;
    end

endmodule
