module proj_bias32_i32_rom (
    input  wire        clk,
    input  wire [5:0]  addr,
    output reg  [5:0]  addr_q,
    output reg  [31:0] dout
);
    localparam BIAS_MEM_FILE = "E:/Desktop/ring2/save_to_FPGA/stage1/block0/ffn/project_mem/bias32_i32.mem";
    reg [31:0] mem [0:31];
    initial begin
        $readmemh(BIAS_MEM_FILE, mem);
    end

    reg [31:0] data_pipe;
    reg [5:0]  addr_pipe;

    always @(posedge clk) begin
        data_pipe <= mem[addr];
        addr_pipe <= addr;
        dout   <= data_pipe;
        addr_q <= addr_pipe;
    end
endmodule