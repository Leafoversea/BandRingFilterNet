`timescale 1ns/1ps
`default_nettype none

module GF_top_stage3_block0 #(
    parameter PW_MEM = "E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/expand_mem/stage3exp.mem",
    parameter PW_BIAS = "E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/expand_mem/bias192_i32.mem",
    parameter DW_MEM = "E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/dw5x5_mem/stage3dw.mem",
    parameter DW_BIAS ="E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/dw5x5_mem/dw_b192_i32.mem",
    parameter PRO_MEM ="E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/project_mem/stage3pro.mem",
    parameter PRO_BIAS ="E:/Desktop/ring2/save_to_FPGA/stage3/block0/ffn/project_mem/bias64_i32.mem"
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        s_valid,
    output wire        s_ready,
    input  wire [9:0]  s_pix_idx,
    input  wire [5:0]  s_och,
    input  wire signed [12:0] s_data,
    input  wire        s_last,

    output wire        m_valid,
    input  wire        m_ready,
    output wire [9:0]  m_pix_idx,
    output wire [5:0]  m_och,
    output wire signed [12:0] m_data,
    output wire        m_last
);

    reg                ibuf_v;
    reg [9:0]          ibuf_pix_idx;
    reg [5:0]          ibuf_och;
    reg signed [12:0]  ibuf_data;
    reg                ibuf_last;
    
    wire        res_full;
    wire        res_empty;
    wire signed [12:0] res_dout;
    wire        res_push;
    wire        res_pop;
    wire        res_wr_busy;
    wire        res_rd_busy;

    reg res_wr_busy_q = 1'b1;
    reg res_rd_busy_q = 1'b1;
    always @(posedge clk) begin
        if (!rst_n) begin
            res_wr_busy_q <= 1'b1;
            res_rd_busy_q <= 1'b1;
        end else begin
            res_wr_busy_q <= res_wr_busy;
            res_rd_busy_q <= res_rd_busy;
        end
    end

    wire        pw_in_ready;
    wire        pw_in_valid;
    wire        fork_fire;
    wire        src_push;

    assign pw_in_valid = ibuf_v && !res_full && !res_wr_busy_q;
    assign fork_fire   = pw_in_valid && pw_in_ready;
    assign src_push    = s_valid && s_ready;
    assign s_ready     = !ibuf_v || fork_fire;
    assign res_push    = fork_fire;
    
    always @(posedge clk) begin
        if (!rst_n) begin
            ibuf_v       <= 1'b0;
            ibuf_pix_idx <= 10'd0;
            ibuf_och     <= 6'd0;
            ibuf_data    <= 13'sd0;
            ibuf_last    <= 1'b0;
        end else begin
            case ({src_push, fork_fire})
                2'b00: ibuf_v <= ibuf_v;
                2'b10: begin
                    ibuf_v       <= 1'b1;
                    ibuf_pix_idx <= s_pix_idx;
                    ibuf_och     <= s_och;
                    ibuf_data    <= s_data;
                    ibuf_last    <= s_last;
                end
                2'b01: ibuf_v <= 1'b0;
                2'b11: begin
                    ibuf_v       <= 1'b1;
                    ibuf_pix_idx <= s_pix_idx;
                    ibuf_och     <= s_och;
                    ibuf_data    <= s_data;
                    ibuf_last    <= s_last;
                end
            endcase
        end
    end

    xpm_fifo_sync #(
        .FIFO_MEMORY_TYPE("distributed"),
        .FIFO_READ_LATENCY(0),
        .FIFO_WRITE_DEPTH(2048),
        .READ_DATA_WIDTH(13),
        .WRITE_DATA_WIDTH(13),
        .READ_MODE("fwft"),
        .USE_ADV_FEATURES("0000")
    ) u_res_fifo (
        .rst(~rst_n),
        .wr_clk(clk),
        .wr_en(res_push),
        .din(ibuf_data),
        .full(res_full),
        .rd_en(res_pop),
        .dout(res_dout),
        .empty(res_empty),
        .wr_rst_busy(res_wr_busy),
        .rd_rst_busy(res_rd_busy),
        .sleep(1'b0),
        .injectsbiterr(1'b0),
        .injectdbiterr(1'b0)
    );

    wire        pw_valid;
    wire        pw_ready;
    wire [7:0]  pw_och;
    wire [9:0]  pw_pix;
    wire signed [12:0] pw_data;

    pointwise1x1_grp8_64to192_vr #(
        .USE_RELU(1),
        .OUT_SHIFT(15),
        .W_MEM(PW_MEM),
        .BIAS_MEM_FILE(PW_BIAS)
    ) u_pw (
        .clk(clk),
        .rst_n(rst_n),
        .in_valid(pw_in_valid),
        .in_ready(pw_in_ready),
        .in_och(ibuf_och),
        .in_pix_idx(ibuf_pix_idx),
        .in_data(ibuf_data),
        .out_valid(pw_valid),
        .out_ready(pw_ready),
        .out_och(pw_och),
        .out_pix_idx(pw_pix),
        .out_data(pw_data)
    );
    
    wire        f1_s_valid = pw_valid;
    wire        f1_s_ready;
    wire [30:0] f1_s_data  = {pw_och, pw_pix, pw_data};
    wire        f1_m_valid;
    wire        f1_m_ready;
    wire [30:0] f1_m_data;
    
    rv_fifo_showahead_block3 #(
        .WIDTH(31),
        .DEPTH(8)
    ) u_fifo_pw_dw (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f1_s_valid), .s_ready(f1_s_ready), .s_data(f1_s_data),
        .m_valid(f1_m_valid), .m_ready(f1_m_ready), .m_data(f1_m_data)
    );
    
    assign pw_ready = f1_s_ready;
    wire [7:0]  pw2dw_och  = f1_m_data[30:23];
    wire [9:0]  pw2dw_pix  = f1_m_data[22:13];
    wire signed [12:0] pw2dw_data = $signed(f1_m_data[12:0]);

    wire        dw_valid;
    wire        dw_ready;
    wire [7:0]  dw_och;
    wire [9:0]  dw_pix;
    wire signed [12:0] dw_data;
    wire        dw_last;
    
    dwconv5x5_p25_192_h8w8_bram #(
        .H(8), .W(8), .PAD(2),
        .OUT_SHIFT(10), .MEM(DW_MEM), .BIAS(DW_BIAS), .USE_RELU(1)
    ) u_dw (
        .clk(clk), .rst_n(rst_n),
        .in_valid(f1_m_valid), .in_ready(f1_m_ready),
        .in_och(pw2dw_och), .in_pix_idx(pw2dw_pix), .in_data(pw2dw_data),
        .out_valid(dw_valid), .out_ready(dw_ready),
        .out_och(dw_och), .out_pix_idx(dw_pix), .out_data(dw_data), .out_last(dw_last)
    );
    
    wire        f2_s_valid = dw_valid;
    wire        f2_s_ready;
    wire [30:0] f2_s_data  = {dw_och, dw_pix, dw_data};
    wire        f2_m_valid;
    wire        f2_m_ready;
    wire [30:0] f2_m_data;
    
    rv_fifo_showahead_block3 #(
        .WIDTH(31),
        .DEPTH(8)
    ) u_fifo_dw_pj (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f2_s_valid), .s_ready(f2_s_ready), .s_data(f2_s_data),
        .m_valid(f2_m_valid), .m_ready(f2_m_ready), .m_data(f2_m_data)
    );
    
    assign dw_ready = f2_s_ready;
    wire [7:0]  dw2pj_och  = f2_m_data[30:23];
    wire [9:0]  dw2pj_pix  = f2_m_data[22:13];
    wire signed [12:0] dw2pj_data = $signed(f2_m_data[12:0]);

    wire        pj_valid;
    wire        pj_ready;
    wire [5:0]  pj_och;
    wire [9:0]  pj_pix;
    wire signed [12:0] pj_data;

    pointwise1x1_grp8_192to64_vr #(
        .USE_RELU(0), .MEM (PRO_MEM), .BIAS(PRO_BIAS), .OUT_SHIFT(12)
    ) u_proj (
        .clk(clk), .rst_n(rst_n),
        .in_valid(f2_m_valid), .in_ready(f2_m_ready),
        .in_och(dw2pj_och), .in_pix_idx(dw2pj_pix), .in_data(dw2pj_data),
        .out_valid(pj_valid), .out_ready(pj_ready),
        .out_och(pj_och), .out_pix_idx(pj_pix), .out_data(pj_data)
    );
    
    wire        f3_s_ready;
    wire        joined_valid = pj_valid && !res_empty && !res_rd_busy_q;
    assign res_pop       = joined_valid && f3_s_ready;
    assign pj_ready      = (!res_empty && !res_rd_busy_q) && f3_s_ready;
    wire        f3_s_valid   = joined_valid;
    
    wire signed [12:0] res_dout_safe = (!res_empty && !res_rd_busy_q) ? res_dout : 13'sd0;
    wire signed [12:0] pj_data_safe  = pj_valid ? pj_data : 13'sd0;
    wire signed [12:0] final_add_data = $signed(pj_data_safe) + $signed(res_dout_safe);

    wire        pj_last_tag = (pj_pix == 10'd63) && (pj_och == 6'd63);
    wire [29:0] f3_s_data   = {pj_last_tag, pj_pix, pj_och, final_add_data};

    wire        f3_m_valid;
    wire        f3_m_ready;
    wire [29:0] f3_m_data;
    
    rv_fifo_showahead_block3 #(
        .WIDTH(30),
        .DEPTH(8)
    ) u_fifo_pj_out (
        .clk(clk), .rst_n(rst_n),
        .s_valid(f3_s_valid), .s_ready(f3_s_ready), .s_data(f3_s_data),
        .m_valid(f3_m_valid), .m_ready(f3_m_ready), .m_data(f3_m_data)
    );
    
    assign m_valid    = f3_m_valid;
    assign f3_m_ready = m_ready;

    wire out_last_tag = f3_m_data[29];
    wire [9:0] out_pix = f3_m_data[28:19];
    wire [5:0] out_och6 = f3_m_data[18:13];
    wire signed [12:0] out_data13 = $signed(f3_m_data[12:0]);

    // [新增修复]：输出端的数据掩码，彻底屏蔽因仿真器未初始 RAM 而出现的 XXXX 态
    assign m_pix_idx = m_valid ? out_pix    : 10'd0;
    assign m_och     = m_valid ? out_och6   : 6'd0;
    assign m_data    = m_valid ? out_data13 : 13'sd0;
    assign m_last    = m_valid && m_ready && out_last_tag;
    
endmodule
`default_nettype wire