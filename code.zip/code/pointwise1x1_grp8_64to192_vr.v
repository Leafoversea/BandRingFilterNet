`timescale 1ns/1ps
`default_nettype none

module pointwise1x1_grp8_64to192_vr #(
    parameter integer USE_RELU  = 1,
    parameter W_MEM = "",
    parameter BIAS_MEM_FILE = "",
    parameter integer OUT_SHIFT = 15
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        in_valid,
    output wire        in_ready,
    input  wire [5:0]  in_och,
    input  wire [9:0]  in_pix_idx,
    input  wire signed [12:0] in_data,
    output wire        out_valid,
    input  wire        out_ready,
    output wire [7:0]  out_och,
    output wire [9:0]  out_pix_idx,
    output wire signed [12:0] out_data
);
    localparam integer NUM_IC = 64;
    localparam integer ACC_W  = 48;

    wire        int_valid;
    wire        int_ready;
    reg  [7:0]  int_och;
    reg  [9:0]  int_pix_idx;
    reg  signed [12:0] int_data;

    wire [30:0] skid_in = {int_och, int_pix_idx, int_data};
    wire [30:0] skid_out;

    skid_buffer #(.WIDTH(31)) u_skid (
        .clk(clk), .rst_n(rst_n),
        .s_valid(int_valid), .s_ready(int_ready), .s_data(skid_in),
        .m_valid(out_valid), .m_ready(out_ready), .m_data(skid_out)
    );
    assign out_och     = skid_out[30:23];
    assign out_pix_idx = skid_out[22:13];
    assign out_data    = skid_out[12:0];

    wire int_fire = int_valid && int_ready;

    reg signed [12:0] xbuf [0:NUM_IC-1];
    reg [9:0] pix_lat;
    reg [3:0] state;
    localparam [3:0] S_IDLE    = 4'd0,
                     S_COLLECT = 4'd1,
                     S_W1      = 4'd2,
                     S_W2      = 4'd3,
                     S_MAC0    = 4'd4,
                     S_MAC1    = 4'd5,
                     S_TREE0   = 4'd6,
                     S_TREE1   = 4'd7,
                     S_TREE2   = 4'd8,
                     S_TREE3   = 4'd9,
                     S_FMT     = 4'd10,
                     S_OUT     = 4'd11;
                     
    reg               ibuf_v;
    reg [5:0]         ibuf_och;
    reg [9:0]         ibuf_pix;
    reg signed [12:0] ibuf_dat;
    
    wire in_ready_int = (state == S_IDLE) || (state == S_COLLECT);
    wire ibuf_pop     = ibuf_v && in_ready_int;
    assign in_ready   = (!ibuf_v) || ibuf_pop;
    wire ibuf_push    = in_valid && in_ready;
    wire [5:0]          in_och_b     = ibuf_och;
    wire [9:0]          in_pix_idx_b = ibuf_pix;
    wire signed [12:0]  in_data_b    = ibuf_dat;
    wire                in_fire      = ibuf_pop;
    
    always @(posedge clk) begin
        if (!rst_n) begin
            ibuf_v <= 0; ibuf_och <= 0; ibuf_pix <= 0; ibuf_dat <= 0;
        end else begin
            case ({ibuf_push, ibuf_pop})
                2'b10: begin ibuf_v <= 1; ibuf_och <= in_och; ibuf_pix <= in_pix_idx; ibuf_dat <= in_data; end
                2'b01: begin ibuf_v <= 0; end
                2'b11: begin ibuf_v <= 1; ibuf_och <= in_och; ibuf_pix <= in_pix_idx; ibuf_dat <= in_data; end
                default: ibuf_v <= ibuf_v;
            endcase
        end
    end

    (* max_fanout = "8" *) reg [7:0] req_och;
    reg signed [31:0] bias_lat;
    wire [7:0] w_addr = req_och; wire [7:0] b_addr = req_och;
    wire [1023:0] w_dout; wire [7:0] w_addr_q; wire [7:0] b_addr_q;
    
    pw_gbank192x16_to1024_rom #(.MEM(W_MEM)) u_w (
        .clk(clk), .addr(w_addr), .addr_q(w_addr_q), .dout(w_dout)
    );
    wire [31:0] b_dout_u; wire signed [31:0] b_dout = b_dout_u;
    bias192_i32_rom #(.BIAS_MEM_FILE(BIAS_MEM_FILE)) u_b (
        .clk(clk), .addr(b_addr), .addr_q(b_addr_q), .dout(b_dout_u)
    );
    wire rom_aligned = (w_addr_q == req_och) && (b_addr_q == req_och);

    wire signed [15:0] w_flat [0:63];
    genvar gi, gj; generate
        for (gi = 0; gi < 8; gi = gi + 1) begin : gen_w_flat
            for (gj = 0; gj < 8; gj = gj + 1) begin : gen_w_flat_inner
                assign w_flat[gi*8 + gj] = w_dout[(7-gi)*128 + gj*16 +: 16];
            end
        end
    endgenerate

    function signed [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x; begin sext32_to_acc = {{(ACC_W-32){x[31]}}, x}; end
    endfunction

    // 恢复 keep 隔离
    (* keep = "true" *) reg signed [12:0] mac_x_reg [0:31];
    (* keep = "true" *) reg signed [15:0] mac_w_reg [0:31];

    reg [3:0] nxt_state;
    always @(*) begin
        nxt_state = state;
        case (state)
            S_IDLE:    if (in_fire && in_och_b == 6'd0) nxt_state = S_COLLECT;
            S_COLLECT: if (in_fire && in_och_b == 6'd63) nxt_state = S_W1;
            S_W1:      nxt_state = S_W2;
            S_W2:      if (rom_aligned) nxt_state = S_MAC0;
            S_MAC0:    nxt_state = S_MAC1;
            S_MAC1:    nxt_state = S_TREE0;
            S_TREE0:   nxt_state = S_TREE1;
            S_TREE1:   nxt_state = S_TREE2;
            S_TREE2:   nxt_state = S_TREE3;
            S_TREE3:   nxt_state = S_FMT;
            S_FMT:     nxt_state = S_OUT;
            S_OUT:     if (int_fire) begin
                           if (req_och == 8'd191) nxt_state = S_IDLE;
                           else nxt_state = S_W1;
                       end
        endcase
    end

    (* equivalent_register_removal = "no" *) reg [3:0] state_dup [0:3];
    wire in_ready_int_dup [0:3];
    wire in_fire_dup      [0:3];
    integer k;
    always @(posedge clk) begin
        if (!rst_n) for(k=0; k<4; k=k+1) state_dup[k] <= S_IDLE;
        else        for(k=0; k<4; k=k+1) state_dup[k] <= nxt_state;
    end

    genvar xg; generate
        for (xg = 0; xg < 4; xg = xg + 1) begin : gen_xb_ctrl
            assign in_ready_int_dup[xg] = (state_dup[xg] == S_IDLE) || (state_dup[xg] == S_COLLECT);
            assign in_fire_dup[xg]      = ibuf_v && in_ready_int_dup[xg];
        end
    endgenerate

    integer i_xb;
    always @(posedge clk) begin
        for (i_xb = 0; i_xb < 64; i_xb = i_xb + 1) begin
            if (state_dup[i_xb/16] == S_COLLECT) begin
                if (in_fire_dup[i_xb/16] && in_och_b == i_xb) xbuf[i_xb] <= in_data_b;
            end else if (state_dup[i_xb/16] == S_IDLE) begin
                if (in_fire_dup[i_xb/16] && in_och_b == 0 && i_xb == 0) xbuf[0] <= in_data_b;
            end
        end
    end

    wire do_clr_acc = (state == S_W2)   && rom_aligned;
    wire do_en_mac  = (state == S_MAC0);
    (* equivalent_register_removal = "no" *) reg clr_acc_q [0:3];
    (* equivalent_register_removal = "no" *) reg en_mac_q  [0:3];
    
    always @(posedge clk) begin
        if (!rst_n) for (k=0; k<4; k=k+1) begin clr_acc_q[k] <= 0; en_mac_q[k] <= 0; end
        else        for (k=0; k<4; k=k+1) begin clr_acc_q[k] <= do_clr_acc; en_mac_q[k] <= do_en_mac; end
    end

    (* use_dsp = "yes" *) reg signed [31:0] dsp_acc [0:31];
    wire signed [29:0] mac_mult [0:31];
    genvar gm; generate for (gm = 0; gm < 32; gm = gm + 1) begin : gen_mac_dsp
        assign mac_mult[gm] = $signed(mac_x_reg[gm]) * $signed(mac_w_reg[gm]);
        always @(posedge clk) begin
            if (!rst_n)                 dsp_acc[gm] <= 32'sd0;
            else if (clr_acc_q[gm/8])   dsp_acc[gm] <= mac_mult[gm];
            else if (en_mac_q[gm/8])    dsp_acc[gm] <= dsp_acc[gm] + mac_mult[gm];
        end
    end endgenerate

    reg signed [ACC_W-1:0] bias_round_reg;
    wire signed [ACC_W-1:0] round_const = (OUT_SHIFT != 0) ? (48'sd1 <<< (OUT_SHIFT - 1)) : 48'sd0;

    // 二叉树降维打击
    (* use_dsp = "no" *) wire signed [32:0] nxt_tree_16 [0:15]; reg signed [32:0] tree_16 [0:15];
    (* use_dsp = "no" *) wire signed [33:0] nxt_tree_8 [0:7];   reg signed [33:0] tree_8 [0:7];
    (* use_dsp = "no" *) wire signed [34:0] nxt_tree_4 [0:3];   reg signed [34:0] tree_4 [0:3];
    reg signed [35:0] tree_2 [0:1];

    genvar tb16, tb8, tb4;
    generate
        for(tb16=0; tb16<16; tb16=tb16+1) begin : gen_tb16
            assign nxt_tree_16[tb16] = dsp_acc[tb16*2] + dsp_acc[tb16*2+1];
        end
        for(tb8=0; tb8<8; tb8=tb8+1) begin : gen_tb8
            assign nxt_tree_8[tb8]  = tree_16[tb8*2] + tree_16[tb8*2+1];
        end
        for(tb4=0; tb4<4; tb4=tb4+1) begin : gen_tb4
            assign nxt_tree_4[tb4]  = tree_8[tb4*2]  + tree_8[tb4*2+1];
        end
    endgenerate

    (* use_dsp = "no" *) wire signed [35:0] nxt_tree_2_0 = tree_4[0] + tree_4[1];
    (* use_dsp = "no" *) wire signed [35:0] nxt_tree_2_1 = tree_4[2] + tree_4[3];

    function signed [ACC_W-1:0] sext36_to_acc;
        input signed [35:0] x; begin sext36_to_acc = {{(ACC_W-36){x[35]}}, x}; end
    endfunction

    (* use_dsp = "no" *) wire signed [ACC_W-1:0] f_final = sext36_to_acc(tree_2[0]) + sext36_to_acc(tree_2[1]) + bias_round_reg;
    reg signed [ACC_W-1:0] acc_shifted;
    reg int_valid_reg;
    assign int_valid = int_valid_reg;

    integer i;
    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE; pix_lat <= 10'd0; req_och <= 8'd0; bias_lat <= 32'sd0;
            bias_round_reg <= 48'sd0; acc_shifted <= 48'sd0;
            int_valid_reg <= 1'b0; int_och <= 8'd0; int_pix_idx <= 10'd0; int_data <= 13'sd0;
            for (i = 0; i < 32; i = i + 1) begin mac_x_reg[i] <= 13'sd0; mac_w_reg[i] <= 16'sd0; end
            for (i = 0; i < 16; i = i + 1) tree_16[i] <= 33'sd0;
            for (i = 0; i < 8;  i = i + 1) tree_8[i]  <= 34'sd0;
            for (i = 0; i < 4;  i = i + 1) tree_4[i]  <= 35'sd0;
            tree_2[0] <= 36'sd0; tree_2[1] <= 36'sd0;
        end else begin
            case (state)
                S_IDLE: begin int_valid_reg <= 1'b0; if (in_fire && (in_och_b == 6'd0)) begin pix_lat <= in_pix_idx_b; state <= S_COLLECT; end end
                S_COLLECT: begin int_valid_reg <= 1'b0; if (in_fire && (in_och_b == 6'd63)) begin req_och <= 8'd0; state <= S_W1; end end
                S_W1: begin int_valid_reg <= 1'b0; state <= S_W2; end
                S_W2: begin
                    int_valid_reg <= 1'b0;
                    if (rom_aligned) begin
                        bias_lat <= b_dout; bias_round_reg <= sext32_to_acc(b_dout) + round_const;
                        for (i = 0; i < 32; i = i + 1) begin mac_x_reg[i] <= xbuf[i]; mac_w_reg[i] <= w_flat[i]; end
                        state <= S_MAC0;
                    end
                end
                S_MAC0: begin for (i = 0; i < 32; i = i + 1) begin mac_x_reg[i] <= xbuf[i+32]; mac_w_reg[i] <= w_flat[i+32]; end state <= S_MAC1; end
                S_MAC1: begin state <= S_TREE0; end
                S_TREE0: begin for (i = 0; i < 16; i = i + 1) tree_16[i] <= nxt_tree_16[i]; state <= S_TREE1; end
                S_TREE1: begin for (i = 0; i < 8; i = i + 1)  tree_8[i]  <= nxt_tree_8[i]; state <= S_TREE2; end
                S_TREE2: begin for (i = 0; i < 4; i = i + 1)  tree_4[i]  <= nxt_tree_4[i]; state <= S_TREE3; end
                S_TREE3: begin tree_2[0] <= nxt_tree_2_0; tree_2[1] <= nxt_tree_2_1; state <= S_FMT; end
                S_FMT: begin
                    if (OUT_SHIFT != 0) acc_shifted <= f_final >>> OUT_SHIFT;
                    else                acc_shifted <= f_final;
                    state <= S_OUT;
                end
                S_OUT: begin
                    int_valid_reg <= 1'b1; int_och <= req_och; int_pix_idx <= pix_lat;
                    if ((USE_RELU != 0) && acc_shifted[ACC_W-1]) int_data <= 13'sd0;
                    else                                         int_data <= acc_shifted[12:0];
                        
                    if (int_fire) begin
                        int_valid_reg <= 1'b0;
                        if (req_och == 8'd191) state <= S_IDLE;
                        else begin req_och <= req_och + 8'd1; state <= S_W1; end
                    end
                end
                default: begin state <= S_IDLE; int_valid_reg <= 1'b0; end
            endcase
        end
    end
endmodule

module pw_gbank192x16_to1024_rom #(parameter MEM = "")(
    input  wire          clk, input  wire [7:0]    addr, output reg  [7:0]    addr_q, output reg  [1023:0] dout
);
    (* rom_style = "block" *) reg [1023:0] mem [0:191];
    initial begin $readmemh(MEM, mem); end
    always @(posedge clk) begin dout <= mem[addr]; addr_q <= addr; end
endmodule

module bias192_i32_rom #(parameter BIAS_MEM_FILE = "")(
    input  wire        clk, input  wire [7:0]  addr, output reg  [7:0]  addr_q, output reg  [31:0] dout
);
    (* rom_style = "distributed" *)reg [31:0] mem [0:191];
    initial begin $readmemh(BIAS_MEM_FILE, mem); end
    always @(posedge clk) begin dout <= mem[addr]; addr_q <= addr; end
endmodule

`default_nettype wire