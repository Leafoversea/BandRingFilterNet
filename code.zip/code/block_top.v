`timescale 1ns / 1ps
module block_top(
    input  wire        board_clk,
    input  wire        board_rst_n,

    output wire [7:0]  led_out
    );

wire clk,rst_n,locked;

clk_wiz_0 clksrc( 
    .clk_out1(clk),     // output clk_out1
    .locked(locked),       // output locked
    .clk_in1(board_clk)      // input clk_in1
);
reg rst_sync_d0 = 1'b0; // 赋初值0，确保上电默认处于复位状态
reg rst_sync_d1 = 1'b0;

always @(posedge clk) begin
    // 将外部异步按钮和 PLL locked 信号合并后，在 clk 域下打两拍
    rst_sync_d0 <= board_rst_n & locked; 
    rst_sync_d1 <= rst_sync_d0;
end

assign rst_n = rst_sync_d1; // 输出干净、完全同步的复位信号

wire        stem_pulse;
wire [4:0]  stem_och;
wire [11:0] stem_pix_idx;
wire [10:0] stem_data;

stem_top stem_top(
    .clk                (clk),
    .rst_n              (rst_n),
    .stem_pulse         (stem_pulse),
    .stem_och           (stem_och),
    .stem_pix_idx       (stem_pix_idx),
    .stem_data          (stem_data)
);
wire        ring_valid;
wire        ring_ready;
wire [9:0]  ring_pix_idx;
wire [5:0]  ring_och;
wire [11:0] ring_data;
wire        ring_last;
ringgf_rfft_mul_irfft2_top_vr ringgf(
    .clk(clk),
    .rst_n(rst_n),
    .s_valid(stem_pulse),
    .s_ready(),
    .s_pix_idx(stem_pix_idx[9:0]),
    .s_och({1'b0,stem_och}),
    .s_data({stem_data[10],stem_data}),
    .m_valid(ring_valid),
    .m_ready(ring_ready),
    .m_pix_idx(ring_pix_idx),
    .m_och(ring_och),
    .m_data(ring_data),
    .m_last(ring_last)
);

wire        m_valid;
wire        m_ready;
wire [9:0]  m_pix_idx;
wire [5:0]  m_och;
wire [12:0] m_data;
wire        m_last;

GF_top gf(
    .clk(clk),
    .rst_n(rst_n),
    .s_valid(ring_valid),
    .s_ready(ring_ready),
    .s_pix_idx(ring_pix_idx),
    .s_och(ring_och),
    .s_data({ring_data[11],ring_data}),
    .s_last(ring_last),
    .m_valid(m_valid),
    .m_ready(m_ready),
    .m_pix_idx(m_pix_idx),
    .m_och(m_och),
    .m_data(m_data),
    .m_last(m_last)
);
wire        down1_valid;
wire        down1_ready;
wire [9:0]  down1_pix_idx;
wire [5:0]  down1_och;
wire [12:0] down1_data;
wire        down1_last;

down2x2s2_grp_param_vr #(
    .W(32),  // 新增：图像宽度
    .IC(32),  // 输入通道
    .OC(48),  // 输出通道
    .ROM_LAT(1),
    .USE_RELU(0),
    .OUT_SHIFT(15),
    .MEM_BASE_PATH("E:/Desktop/ring2/save_to_FPGA/down")
 )down1(
    .clk(clk),
    .rst_n(rst_n),

    .in_valid(m_valid),
    .in_ready(m_ready),
    .in_och(m_och[4:0]),
    .in_pix_idx(m_pix_idx),
    .in_data(m_data),
    .out_valid(down1_valid),
    .out_ready(down1_ready),
    .out_och(down1_och),
    .out_pix_idx(down1_pix_idx),
    .out_data(down1_data),
    .out_last(down1_last)
);

wire        stage2_valid;
wire        stage2_ready;
wire [7:0]  stage2_pix_idx;
wire [5:0]  stage2_och;
wire [12:0] stage2_data;
wire        stage2_last;

GF_stage2 #(
    .PW_SHIFT(15),
    .PW_MEM ("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/expand_mem/stage3b0pw.mem"),
    .PW_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/expand_mem/bias144_i32.mem"),
    .DW_SHIFT(11),
    .DW_MEM("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/dw5x5_mem/stage2b0dw.mem"),
    .DW_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/dw5x5_mem/dw_b144_i32.mem"),
    .PRO_SHIFT(14),
    .PRO_MEM ("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/project_mem/stage2b0pro.mem"),
    .PRO_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block0/ffn/project_mem/bias48_i32.mem")
)b0(
    .clk(clk),
    .rst_n(rst_n),
    .s_valid(down1_valid),
    .s_ready(down1_ready),
    .s_pix_idx(down1_pix_idx[7:0]),  
    .s_och(down1_och),
    .s_data(down1_data),
    .s_last(down1_last),
    .m_valid(stage2_valid),
    .m_ready(stage2_ready),
    .m_pix_idx(stage2_pix_idx),  
    .m_och(stage2_och),
    .m_data(stage2_data),
    .m_last(stage2_last)
);

// =========================================================================
// [Top-Level Register Slice] Skid Buffer 彻底隔离 b0 和 b1 的物理走线
// =========================================================================
wire [27:0] stage2_data_in = {stage2_last, stage2_pix_idx, stage2_och, stage2_data};

reg         pipe_valid_reg;
reg [27:0]  pipe_data_reg;
reg         pipe_ready_skid;
reg [27:0]  pipe_data_skid;

wire        bridge_ready; // 来自 b1 的反压信号

always @(posedge clk) begin
    if (!rst_n) begin
        pipe_valid_reg  <= 1'b0;
        pipe_data_reg   <= 28'd0;
        pipe_ready_skid <= 1'b0;
        pipe_data_skid  <= 28'd0;
    end else begin
        // 弹出逻辑 (下游 b1 可以接收)
        if (bridge_ready) begin
            if (pipe_ready_skid) begin
                pipe_valid_reg  <= 1'b1;
                pipe_data_reg   <= pipe_data_skid;
                pipe_ready_skid <= 1'b0;
            end else begin
                pipe_valid_reg  <= 1'b0;
            end
        end
        
        // 压入逻辑 (上游 b0 有数据)
        if (stage2_valid && (!pipe_ready_skid)) begin
            if (bridge_ready || !pipe_valid_reg) begin
                pipe_valid_reg  <= 1'b1;
                pipe_data_reg   <= stage2_data_in;
            end else begin
                // 下游阻塞，缓存溢出到 Skid 寄存器
                pipe_ready_skid <= 1'b1;
                pipe_data_skid  <= stage2_data_in;
            end
        end
    end
end

// 反向隔离：阻断 b1 的 ready 组合逻辑穿透到 b0
assign stage2_ready = !pipe_ready_skid; 

// 前向隔离：送给 b1 的纯寄存器输出
wire        bridge_valid   = pipe_valid_reg;
wire        bridge_last    = pipe_data_reg[27];
wire [7:0]  bridge_pix_idx = pipe_data_reg[26:19];
wire [5:0]  bridge_och     = pipe_data_reg[18:13];
wire [12:0] bridge_data    = pipe_data_reg[12:0];
// =========================================================================

wire        st2_d_valid;
wire        st2_d_ready;
wire [7:0]  st2_d_pix_idx;  // 10-bit -> 8-bit
wire [5:0]  st2_d_och;
wire [12:0] st2_d_data;

GF_stage2 #(
    .PW_SHIFT(15),
    .PW_MEM ("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/expand_mem/stage2b1pw.mem"),
    .PW_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/expand_mem/bias144_i32.mem"),
    .DW_SHIFT(12),
    .DW_MEM("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/dw5x5_mem/stage2b1dw.mem"),
    .DW_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/dw5x5_mem/dw_b144_i32.mem"),
    .PRO_SHIFT(14),
    .PRO_MEM ("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/project_mem/stage2b1pro.mem"),
    .PRO_BIAS("E:/Desktop/ring2/save_to_FPGA/stage2/block1/ffn/project_mem/bias48_i32.mem")
)b1(
    .clk(clk),
    .rst_n(rst_n),
    // 接入隔离后的 bridge 信号
    .s_valid(bridge_valid),
    .s_ready(bridge_ready),
    .s_pix_idx(bridge_pix_idx),  
    .s_och(bridge_och),
    .s_data(bridge_data),
    .s_last(bridge_last),
    
    .m_valid(st2_d_valid),
    .m_ready(st2_d_ready),
    .m_pix_idx(st2_d_pix_idx),  
    .m_och(st2_d_och),
    .m_data(st2_d_data),
    .m_last()
);

wire        d_st3_valid;
wire        d_st3_ready;
wire [9:0]  d_st3_pix_idx;  // 10-bit -> 8-bit
wire [5:0]  d_st3_och;
wire [12:0] d_st3_data;
wire        d_st3_last;

down2x2s2_grp_param_vr #(
    .W(16),  // 新增：图像宽度
    .IC(48),  // 输入通道
    .OC(64),  // 输出通道
    .ROM_LAT(1),
    .USE_RELU(0),
    .OUT_SHIFT(15),
    .MEM_BASE_PATH("E:/Desktop/ring2/save_to_FPGA/down")
 )down2(
    .clk(clk),
    .rst_n(rst_n),
    .in_valid(st2_d_valid),
    .in_ready(st2_d_ready),
    .in_och(st2_d_och),
    .in_pix_idx({2'b0,st2_d_pix_idx}),
    .in_data(st2_d_data),
    .out_valid(d_st3_valid),
    .out_ready(d_st3_ready),
    .out_och(d_st3_och),
    .out_pix_idx(d_st3_pix_idx),
    .out_data(d_st3_data),
    .out_last(d_st3_last)
);

wire        st3_tail_valid;
wire        st3_tail_ready;
wire [9:0]  st3_tail_pix_idx;
wire [5:0]  st3_tail_och;
wire [12:0] st3_tail_data;
wire        st3_tail_last;

GF_top_stage3_block0 stage3(
    .clk(clk),
    .rst_n(rst_n),
    .s_valid(d_st3_valid),
    .s_ready(d_st3_ready),
    .s_pix_idx(d_st3_pix_idx),
    .s_och(d_st3_och),
    .s_data(d_st3_data),
    .s_last(d_st3_last),
    .m_valid(   st3_tail_valid ),
    .m_ready(   st3_tail_ready),
    .m_pix_idx( st3_tail_pix_idx),
    .m_och(     st3_tail_och),
    .m_data(    st3_tail_data),
    .m_last(    st3_tail_last)
);

stage3_post_top a(
    .clk(clk),
    .rst_n(rst_n),

    .s_valid(   st3_tail_valid ),
    .s_ready(   st3_tail_ready ),
    .s_pix_idx( st3_tail_pix_idx),
    .s_och(     st3_tail_och),
    .s_data(    st3_tail_data),
    .s_last(    st3_tail_last),

    .m_valid(),
    .led_out(led_out)
);

endmodule