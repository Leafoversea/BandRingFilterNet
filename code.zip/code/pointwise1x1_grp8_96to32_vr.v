`timescale 1ns/1ps
`default_nettype none

module pointwise1x1_grp8_96to32_vr #(
    parameter integer USE_RELU  = 0,
    parameter integer OUT_SHIFT = 15
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        in_valid,
    output wire        in_ready,
    input  wire [6:0]  in_och,
    input  wire [9:0]  in_pix_idx,
    input  wire signed [12:0] in_data,

    output reg         out_valid,
    input  wire        out_ready,
    output reg  [5:0]  out_och,
    output reg  [9:0]  out_pix_idx,
    output reg  signed [12:0] out_data
);

    localparam integer NUM_IC = 96;

    // ---- width tuning ----
    localparam integer ACC_W   = 37;
    localparam integer GSUM_W  = 32;
    localparam integer DELTA_W = 34;
    localparam integer ACCI_W  = ACC_W + 1;

    // ---------------- internal buffers ----------------
    reg signed [12:0] xbuf [0:NUM_IC-1];
    reg [9:0] pix_lat;

    // ---------------- state machine ----------------
    reg [3:0] state;
    localparam [3:0] S_IDLE    = 4'd0,
                     S_COLLECT = 4'd1,
                     S_WAIT    = 4'd2,
                     S_RUN     = 4'd3,
                     S_CPA     = 4'd4,
                     S_BIAS    = 4'd5,
                     S_FMT_1   = 4'd6,
                     S_FMT_2   = 4'd7,
                     S_OUT     = 4'd8;

    // ============================================================
    // Input skid buffer (1-deep)
    // ============================================================
    reg               ibuf_v;
    reg [6:0]         ibuf_och;
    reg [9:0]         ibuf_pix;
    reg signed [12:0] ibuf_dat;

    wire in_ready_int = (state == S_IDLE) || (state == S_COLLECT);
    wire ibuf_pop  = ibuf_v && in_ready_int;
    assign in_ready = (!ibuf_v) || ibuf_pop;
    wire ibuf_push = in_valid && in_ready;

    wire [6:0]         in_och_b      = ibuf_och;
    wire [9:0]         in_pix_idx_b  = ibuf_pix;
    wire signed [12:0] in_data_b     = ibuf_dat;
    wire               in_fire       = ibuf_pop;

    always @(posedge clk) begin
        if (!rst_n) begin
            ibuf_v   <= 1'b0;
            ibuf_och <= 7'd0;
            ibuf_pix <= 10'd0;
            // 解除数据路径复位，节约资源
        end else begin
            case ({ibuf_push, ibuf_pop})
                2'b10: begin
                    ibuf_v   <= 1'b1;
                    ibuf_och <= in_och;
                    ibuf_pix <= in_pix_idx;
                    ibuf_dat <= in_data;
                end
                2'b01: ibuf_v <= 1'b0;
                2'b11: begin
                    ibuf_v   <= 1'b1;
                    ibuf_och <= in_och;
                    ibuf_pix <= in_pix_idx;
                    ibuf_dat <= in_data;
                end
                default: ibuf_v <= ibuf_v;
            endcase
        end
    end

    wire out_fire = out_valid && out_ready;

    // ---------------- main accumulators / addresses ----------------
    reg [5:0]  och_cur;
    reg signed [ACC_W-1:0] acc;
    reg signed [ACCI_W-1:0] acc_sum;
    reg signed [ACCI_W-1:0] acc_carry;

    reg signed [31:0] bias_lat;
    reg  [5:0] w_addr;
    reg  [5:0] b_addr;

    wire [127:0] wgb00, wgb01, wgb02, wgb03, wgb04, wgb05, wgb06, wgb07, wgb08, wgb09, wgb10, wgb11;
    wire [5:0]   w0_addr_q;
    wire [5:0]   b_addr_q;

    proj_gbank32x16_to128_rom  u_w(
        .clk   (clk),
        .addr  (w_addr),
        .addr_q(w0_addr_q),
        .dout  ({wgb00, wgb01, wgb02, wgb03, wgb04, wgb05, wgb06, wgb07, wgb08, wgb09, wgb10, wgb11})
    );

    wire [31:0]        b_dout_u;
    wire signed [31:0] b_dout = b_dout_u;

    proj_bias32_i32_rom u_b(
        .clk   (clk),
        .addr  (b_addr),
        .addr_q(b_addr_q),
        .dout  (b_dout_u)
    );

    wire rom_aligned = (w0_addr_q == w_addr) && (b_addr_q == b_addr);

    // ---------------- pipeline controls ----------------
    reg [1:0]  run_idx;
    reg        issue_done;

    reg pipe_v, pipe_last;
    reg prod_v, prod_last;
    reg add1_v, add1_last;
    reg add2_v, add2_last;
    reg add3_v, add3_last;  // ADDED: S3 balanced pipelining control
    reg delta_v, delta_last;
    reg done_pending;

    // ---------------- PIPE regs ----------------
    reg [127:0] w_word0_pipe, w_word1_pipe, w_word2_pipe;

    reg signed [12:0] x_op0_pipe [0:7];
    reg signed [12:0] x_op1_pipe [0:7];
    reg signed [12:0] x_op2_pipe [0:7];

    // ---------------- DSP products ----------------
    (* use_dsp = "yes" *) wire signed [31:0] p0_0_w = $signed(x_op0_pipe[0]) * $signed(w_word0_pipe[15:0]);
    (* use_dsp = "yes" *) wire signed [31:0] p1_0_w = $signed(x_op0_pipe[1]) * $signed(w_word0_pipe[31:16]);
    (* use_dsp = "yes" *) wire signed [31:0] p2_0_w = $signed(x_op0_pipe[2]) * $signed(w_word0_pipe[47:32]);
    (* use_dsp = "yes" *) wire signed [31:0] p3_0_w = $signed(x_op0_pipe[3]) * $signed(w_word0_pipe[63:48]);
    (* use_dsp = "yes" *) wire signed [31:0] p4_0_w = $signed(x_op0_pipe[4]) * $signed(w_word0_pipe[79:64]);
    (* use_dsp = "yes" *) wire signed [31:0] p5_0_w = $signed(x_op0_pipe[5]) * $signed(w_word0_pipe[95:80]);
    (* use_dsp = "yes" *) wire signed [31:0] p6_0_w = $signed(x_op0_pipe[6]) * $signed(w_word0_pipe[111:96]);
    (* use_dsp = "yes" *) wire signed [31:0] p7_0_w = $signed(x_op0_pipe[7]) * $signed(w_word0_pipe[127:112]);

    (* use_dsp = "yes" *) wire signed [31:0] p0_1_w = $signed(x_op1_pipe[0]) * $signed(w_word1_pipe[15:0]);
    (* use_dsp = "yes" *) wire signed [31:0] p1_1_w = $signed(x_op1_pipe[1]) * $signed(w_word1_pipe[31:16]);
    (* use_dsp = "yes" *) wire signed [31:0] p2_1_w = $signed(x_op1_pipe[2]) * $signed(w_word1_pipe[47:32]);
    (* use_dsp = "yes" *) wire signed [31:0] p3_1_w = $signed(x_op1_pipe[3]) * $signed(w_word1_pipe[63:48]);
    (* use_dsp = "yes" *) wire signed [31:0] p4_1_w = $signed(x_op1_pipe[4]) * $signed(w_word1_pipe[79:64]);
    (* use_dsp = "yes" *) wire signed [31:0] p5_1_w = $signed(x_op1_pipe[5]) * $signed(w_word1_pipe[95:80]);
    (* use_dsp = "yes" *) wire signed [31:0] p6_1_w = $signed(x_op1_pipe[6]) * $signed(w_word1_pipe[111:96]);
    (* use_dsp = "yes" *) wire signed [31:0] p7_1_w = $signed(x_op1_pipe[7]) * $signed(w_word1_pipe[127:112]);

    (* use_dsp = "yes" *) wire signed [31:0] p0_2_w = $signed(x_op2_pipe[0]) * $signed(w_word2_pipe[15:0]);
    (* use_dsp = "yes" *) wire signed [31:0] p1_2_w = $signed(x_op2_pipe[1]) * $signed(w_word2_pipe[31:16]);
    (* use_dsp = "yes" *) wire signed [31:0] p2_2_w = $signed(x_op2_pipe[2]) * $signed(w_word2_pipe[47:32]);
    (* use_dsp = "yes" *) wire signed [31:0] p3_2_w = $signed(x_op2_pipe[3]) * $signed(w_word2_pipe[63:48]);
    (* use_dsp = "yes" *) wire signed [31:0] p4_2_w = $signed(x_op2_pipe[4]) * $signed(w_word2_pipe[79:64]);
    (* use_dsp = "yes" *) wire signed [31:0] p5_2_w = $signed(x_op2_pipe[5]) * $signed(w_word2_pipe[95:80]);
    (* use_dsp = "yes" *) wire signed [31:0] p6_2_w = $signed(x_op2_pipe[6]) * $signed(w_word2_pipe[111:96]);
    (* use_dsp = "yes" *) wire signed [31:0] p7_2_w = $signed(x_op2_pipe[7]) * $signed(w_word2_pipe[127:112]);

    // ---------------- PROD & ADD regs ----------------
    reg signed [31:0] p0_0_r,p1_0_r,p2_0_r,p3_0_r,p4_0_r,p5_0_r,p6_0_r,p7_0_r;
    reg signed [31:0] p0_1_r,p1_1_r,p2_1_r,p3_1_r,p4_1_r,p5_1_r,p6_1_r,p7_1_r;
    reg signed [31:0] p0_2_r,p1_2_r,p2_2_r,p3_2_r,p4_2_r,p5_2_r,p6_2_r,p7_2_r;

    reg signed [GSUM_W-1:0] s1_0_0_r, s1_0_1_r, s1_0_2_r, s1_0_3_r;
    reg signed [GSUM_W-1:0] s1_1_0_r, s1_1_1_r, s1_1_2_r, s1_1_3_r;
    reg signed [GSUM_W-1:0] s1_2_0_r, s1_2_1_r, s1_2_2_r, s1_2_3_r;

    reg signed [GSUM_W-1:0] s2_0_0_r, s2_0_1_r;
    reg signed [GSUM_W-1:0] s2_1_0_r, s2_1_1_r;
    reg signed [GSUM_W-1:0] s2_2_0_r, s2_2_1_r;

    reg signed [DELTA_W-1:0] s3_0_r, s3_1_r; // ADDED: S3 balanced pipeline registers
    reg signed [DELTA_W-1:0] delta_r;

    // ---------------- output regs ----------------
    reg signed [ACC_W-1:0] acc_bias_pipe;
    reg signed [ACC_W-1:0] acc_shifted_pipe;
    reg [5:0] out_och_pipe;
    reg [9:0] out_pix_pipe;

    // ---------------- helper functions ----------------
    function signed [ACC_W-1:0] sext32_to_acc;
        input signed [31:0] x;
        begin sext32_to_acc = x; end
    endfunction

    function signed [GSUM_W-1:0] sext32_to_gsum;
        input signed [31:0] x;
        begin sext32_to_gsum = x; end
    endfunction

    function signed [DELTA_W-1:0] sext_gsum_to_delta;
        input signed [GSUM_W-1:0] x;
        begin sext_gsum_to_delta = x; end
    endfunction

    function signed [ACCI_W-1:0] sext_delta_to_acci;
        input signed [DELTA_W-1:0] x;
        begin sext_delta_to_acci = x; end
    endfunction

    wire last_och = (och_cur == 6'd31);
    wire [5:0] och_inc = och_cur + 6'd1;

    wire signed [ACC_W-1:0] round_pos_w = (OUT_SHIFT == 0) ?
        {ACC_W{1'b0}} : ($signed({{(ACC_W-1){1'b0}}, 1'b1}) <<< (OUT_SHIFT-1));
    wire signed [ACC_W-1:0] round_neg_w = (OUT_SHIFT == 0) ?
        {ACC_W{1'b0}} : (round_pos_w - $signed({{(ACC_W-1){1'b0}}, 1'b1}));

    wire is_tie_w = (OUT_SHIFT == 0) ? 1'b0 : (OUT_SHIFT == 1) ?
        acc_bias_pipe[0] : (acc_bias_pipe[OUT_SHIFT-1] && (~(|acc_bias_pipe[OUT_SHIFT-2:0])));

    wire issue_v    = (!issue_done);
    wire issue_last = (run_idx == 2'd3);

    integer i;

    // ============================================================
    // Adders
    // ============================================================
    wire signed [GSUM_W-1:0] w_s1_0_0 = sext32_to_gsum(p0_0_r) + sext32_to_gsum(p1_0_r);
    wire signed [GSUM_W-1:0] w_s1_0_1 = sext32_to_gsum(p2_0_r) + sext32_to_gsum(p3_0_r);
    wire signed [GSUM_W-1:0] w_s1_0_2 = sext32_to_gsum(p4_0_r) + sext32_to_gsum(p5_0_r);
    wire signed [GSUM_W-1:0] w_s1_0_3 = sext32_to_gsum(p6_0_r) + sext32_to_gsum(p7_0_r);

    wire signed [GSUM_W-1:0] w_s1_1_0 = sext32_to_gsum(p0_1_r) + sext32_to_gsum(p1_1_r);
    wire signed [GSUM_W-1:0] w_s1_1_1 = sext32_to_gsum(p2_1_r) + sext32_to_gsum(p3_1_r);
    wire signed [GSUM_W-1:0] w_s1_1_2 = sext32_to_gsum(p4_1_r) + sext32_to_gsum(p5_1_r);
    wire signed [GSUM_W-1:0] w_s1_1_3 = sext32_to_gsum(p6_1_r) + sext32_to_gsum(p7_1_r);

    wire signed [GSUM_W-1:0] w_s1_2_0 = sext32_to_gsum(p0_2_r) + sext32_to_gsum(p1_2_r);
    wire signed [GSUM_W-1:0] w_s1_2_1 = sext32_to_gsum(p2_2_r) + sext32_to_gsum(p3_2_r);
    wire signed [GSUM_W-1:0] w_s1_2_2 = sext32_to_gsum(p4_2_r) + sext32_to_gsum(p5_2_r);
    wire signed [GSUM_W-1:0] w_s1_2_3 = sext32_to_gsum(p6_2_r) + sext32_to_gsum(p7_2_r);

    wire signed [GSUM_W-1:0] w_s2_0_0 = s1_0_0_r + s1_0_1_r;
    wire signed [GSUM_W-1:0] w_s2_0_1 = s1_0_2_r + s1_0_3_r;
    wire signed [GSUM_W-1:0] w_s2_1_0 = s1_1_0_r + s1_1_1_r;
    wire signed [GSUM_W-1:0] w_s2_1_1 = s1_1_2_r + s1_1_3_r;
    wire signed [GSUM_W-1:0] w_s2_2_0 = s1_2_0_r + s1_2_1_r;
    wire signed [GSUM_W-1:0] w_s2_2_1 = s1_2_2_r + s1_2_3_r;

    // MODIFIED: Timing Fix - Final w_delta merges only the 2 S3 results. 
    wire signed [DELTA_W-1:0] w_delta = s3_0_r + s3_1_r;

    // --- TIMING FIX 1: Bitwise overflow logic ---
    wire is_pos_ovf = (acc_shifted_pipe[ACC_W-1] == 1'b0) && (|acc_shifted_pipe[ACC_W-2:12]);
    wire is_neg_ovf = (acc_shifted_pipe[ACC_W-1] == 1'b1) && (~&acc_shifted_pipe[ACC_W-2:12]);

    // ============================================================
    // Main sequential FSM
    // ============================================================
    // --- TIMING FIX 2: 移除数据流水线寄存器的异步复位，以确保其被打包入 DSP/SRL ---
    always @(posedge clk) begin
        if (!rst_n) begin
            // 仅保留关键状态机和控制信号的复位
            state   <= S_IDLE;
            pix_lat <= 10'd0;
            och_cur <= 6'd0;
            w_addr    <= 6'd0;
            b_addr    <= 6'd0;
            out_valid   <= 1'b0;
            out_och     <= 6'd0;
            out_pix_idx <= 10'd0;
            run_idx     <= 2'd0;
            issue_done  <= 1'b0;
            pipe_v   <= 1'b0;  pipe_last  <= 1'b0;
            prod_v   <= 1'b0;  prod_last  <= 1'b0;
            add1_v   <= 1'b0;  add1_last  <= 1'b0;
            add2_v   <= 1'b0;  add2_last  <= 1'b0;
            add3_v   <= 1'b0;  add3_last  <= 1'b0; // ADDED
            delta_v  <= 1'b0;  delta_last <= 1'b0;
            done_pending <= 1'b0;
            // 注意：xbuf, acc*, x_op*, w_word*, p*, s*, delta* 和 out_data 等数据已被移除出复位名单！
        end else begin
            case (state)
                S_IDLE: begin
                    out_valid <= 1'b0;
                    if (in_fire && (in_och_b == 7'd0)) begin
                        pix_lat <= in_pix_idx_b;
                        xbuf[0] <= in_data_b;
                        state   <= S_COLLECT;
                    end
                end

                S_COLLECT: begin
                    out_valid <= 1'b0;
                    if (in_fire) begin
                        if (in_och_b < 7'd96) xbuf[in_och_b] <= in_data_b;
                        if (in_och_b == 7'd94) begin
                            w_addr <= 6'd0;
                            b_addr <= 6'd0;
                        end
                        if (in_och_b == 7'd95) begin
                            och_cur <= 6'd0;
                            // 移除 acc <= {ACC_W{1'b0}}; 节约布线！
                            acc_sum <= {ACCI_W{1'b0}};
                            acc_carry <= {ACCI_W{1'b0}};
                            w_addr  <= 6'd0;
                            b_addr  <= 6'd0;
                            state   <= S_WAIT;
                        end
                    end
                end

                S_WAIT: begin
                    out_valid <= 1'b0;
                    if (rom_aligned) begin
                        bias_lat <= b_dout;
                        acc_sum   <= {ACCI_W{1'b0}};
                        acc_carry <= {ACCI_W{1'b0}};
                        // 移除 acc <= {ACC_W{1'b0}}; 
                        run_idx    <= 2'd0;
                        issue_done <= 1'b0;
                        // ... pipe 归零保持不变 ...
                        state <= S_RUN;
                    end
                end

                S_RUN: begin
                    out_valid <= 1'b0;
                    if (done_pending) begin
                        done_pending <= 1'b0;
                        out_och_pipe <= och_cur;
                        out_pix_pipe <= pix_lat;

                        pipe_v   <= 1'b0; pipe_last  <= 1'b0;
                        prod_v   <= 1'b0; prod_last  <= 1'b0;
                        add1_v   <= 1'b0; add1_last  <= 1'b0;
                        add2_v   <= 1'b0; add2_last  <= 1'b0;
                        add3_v   <= 1'b0; add3_last  <= 1'b0; // ADDED
                        delta_v  <= 1'b0; delta_last <= 1'b0;
                        issue_done <= 1'b1;

                        state <= S_CPA;
                    end else begin
                        pipe_v    <= issue_v;
                        pipe_last <= issue_last;

                        if (issue_v) begin
                            case (run_idx)
                                2'd0: begin
                                    w_word0_pipe <= wgb00; w_word1_pipe <= wgb01; w_word2_pipe <= wgb02;
                                    for(i=0; i<8; i=i+1) begin
                                        x_op0_pipe[i] <= xbuf[0  + i];
                                        x_op1_pipe[i] <= xbuf[8  + i];
                                        x_op2_pipe[i] <= xbuf[16 + i];
                                    end
                                end
                                2'd1: begin
                                    w_word0_pipe <= wgb03; w_word1_pipe <= wgb04; w_word2_pipe <= wgb05;
                                    for(i=0; i<8; i=i+1) begin
                                        x_op0_pipe[i] <= xbuf[24 + i];
                                        x_op1_pipe[i] <= xbuf[32 + i];
                                        x_op2_pipe[i] <= xbuf[40 + i];
                                    end
                                end
                                2'd2: begin
                                    w_word0_pipe <= wgb06; w_word1_pipe <= wgb07; w_word2_pipe <= wgb08;
                                    for(i=0; i<8; i=i+1) begin
                                        x_op0_pipe[i] <= xbuf[48 + i];
                                        x_op1_pipe[i] <= xbuf[56 + i];
                                        x_op2_pipe[i] <= xbuf[64 + i];
                                    end
                                end
                                2'd3: begin
                                    w_word0_pipe <= wgb09; w_word1_pipe <= wgb10; w_word2_pipe <= wgb11;
                                    for(i=0; i<8; i=i+1) begin
                                        x_op0_pipe[i] <= xbuf[72 + i];
                                        x_op1_pipe[i] <= xbuf[80 + i];
                                        x_op2_pipe[i] <= xbuf[88 + i];
                                    end
                                end
                            endcase

                            if (issue_last) begin
                                issue_done <= 1'b1;
                                if (!last_och) begin
                                    w_addr <= och_inc;
                                    b_addr <= och_inc;
                                end
                            end else begin
                                run_idx <= run_idx + 2'd1;
                            end
                        end

                        prod_v    <= pipe_v;
                        prod_last <= pipe_last;

                        if (pipe_v) begin
                            p0_0_r <= p0_0_w; p1_0_r <= p1_0_w; p2_0_r <= p2_0_w; p3_0_r <= p3_0_w;
                            p4_0_r <= p4_0_w; p5_0_r <= p5_0_w; p6_0_r <= p6_0_w; p7_0_r <= p7_0_w;
                            
                            p0_1_r <= p0_1_w; p1_1_r <= p1_1_w; p2_1_r <= p2_1_w; p3_1_r <= p3_1_w;
                            p4_1_r <= p4_1_w; p5_1_r <= p5_1_w; p6_1_r <= p6_1_w; p7_1_r <= p7_1_w;
                            
                            p0_2_r <= p0_2_w; p1_2_r <= p1_2_w; p2_2_r <= p2_2_w; p3_2_r <= p3_2_w;
                            p4_2_r <= p4_2_w; p5_2_r <= p5_2_w; p6_2_r <= p6_2_w; p7_2_r <= p7_2_w;
                        end

                        add1_v    <= prod_v;
                        add1_last <= prod_last;

                        if (prod_v) begin
                            s1_0_0_r <= w_s1_0_0; s1_0_1_r <= w_s1_0_1; s1_0_2_r <= w_s1_0_2; s1_0_3_r <= w_s1_0_3;
                            s1_1_0_r <= w_s1_1_0; s1_1_1_r <= w_s1_1_1; s1_1_2_r <= w_s1_1_2; s1_1_3_r <= w_s1_1_3;
                            s1_2_0_r <= w_s1_2_0; s1_2_1_r <= w_s1_2_1; s1_2_2_r <= w_s1_2_2; s1_2_3_r <= w_s1_2_3;
                        end

                        add2_v    <= add1_v;
                        add2_last <= add1_last;

                        if (add1_v) begin
                            s2_0_0_r <= w_s2_0_0; s2_0_1_r <= w_s2_0_1;
                            s2_1_0_r <= w_s2_1_0; s2_1_1_r <= w_s2_1_1;
                            s2_2_0_r <= w_s2_2_0; s2_2_1_r <= w_s2_2_1;
                        end

                        // MODIFIED: Injecting Stage 3 for Adder Tree Balancing
                        add3_v    <= add2_v;
                        add3_last <= add2_last;

                        if (add2_v) begin
                            s3_0_r <= sext_gsum_to_delta(s2_0_0_r) + sext_gsum_to_delta(s2_0_1_r) + sext_gsum_to_delta(s2_1_0_r);
                            s3_1_r <= sext_gsum_to_delta(s2_1_1_r) + sext_gsum_to_delta(s2_2_0_r) + sext_gsum_to_delta(s2_2_1_r);
                        end

                        delta_v    <= add3_v;
                        delta_last <= add3_last;

                        if (add3_v) begin
                            delta_r <= w_delta;
                        end

                        if (delta_v) begin
                            begin : CSA_ACCUM
                                reg signed [ACCI_W-1:0] a, b, c, sum_n, carry_n, carry_raw;
                                a = acc_sum;
                                b = acc_carry;
                                c = sext_delta_to_acci(delta_r);

                                sum_n     = a ^ b ^ c;
                                carry_raw = (a & b) | (a & c) | (b & c);
                                carry_n   = carry_raw <<< 1;
                                acc_sum   <= sum_n;
                                acc_carry <= carry_n;
                            end

                            if (delta_last) begin
                                done_pending <= 1'b1;
                            end
                        end
                    end
                end

                S_CPA: begin
                    out_valid <= 1'b0;
                    acc <= $signed(acc_sum + acc_carry);
                    state <= S_BIAS;
                end

                S_BIAS: begin
                    out_valid <= 1'b0;
                    acc_bias_pipe <= acc + sext32_to_acc(bias_lat);
                    state <= S_FMT_1;
                end

                S_FMT_1: begin
                    if (OUT_SHIFT != 0) begin
                        if (acc_bias_pipe[ACC_W-1] == 1'b0) begin
                            acc_shifted_pipe <= (acc_bias_pipe + round_pos_w) >>> OUT_SHIFT;
                        end else begin
                            if (is_tie_w)
                                acc_shifted_pipe <= (acc_bias_pipe + round_pos_w) >>> OUT_SHIFT;
                            else
                                acc_shifted_pipe <= (acc_bias_pipe + round_neg_w) >>> OUT_SHIFT;
                        end
                    end else begin
                        acc_shifted_pipe <= acc_bias_pipe;
                    end
                    state <= S_FMT_2;
                end

                S_FMT_2: begin
                    out_valid   <= 1'b1;
                    out_och     <= out_och_pipe;
                    out_pix_idx <= out_pix_pipe;

                    // --- 融合逻辑判断，逻辑层级从 7 级缩至极低 ---
                    if ((USE_RELU != 0) && acc_shifted_pipe[ACC_W-1])
                        out_data <= 13'sd0;
                    else if (is_pos_ovf)
                        out_data <= 13'sd4095;
                    else if (is_neg_ovf)
                        out_data <= -13'sd4096;
                    else
                        out_data <= acc_shifted_pipe[12:0];
                    state <= S_OUT;
                end

                S_OUT: begin
                    if (out_fire) begin
                        out_valid <= 1'b0;
                        if (last_och) begin
                            state <= S_IDLE;
                        end else begin
                            och_cur <= w_addr;
                            
                            // 关键修改：w_addr 在 S_RUN 就更新了，到达 S_OUT 已过去 5 拍
                            // ROM 绝对已对齐，强行去掉 if (rom_aligned) 的组合逻辑链！
                            bias_lat <= b_dout;
                            acc_sum   <= {ACCI_W{1'b0}};
                            acc_carry <= {ACCI_W{1'b0}};
                            // 移除 acc <= {ACC_W{1'b0}};
                            
                            run_idx    <= 2'd0;
                            issue_done <= 1'b0;
                            
                            pipe_v   <= 1'b0; pipe_last  <= 1'b0;
                            prod_v   <= 1'b0; prod_last  <= 1'b0;
                            add1_v   <= 1'b0; add1_last  <= 1'b0;
                            add2_v   <= 1'b0; add2_last  <= 1'b0;
                            add3_v   <= 1'b0; add3_last  <= 1'b0;
                            delta_v  <= 1'b0; delta_last <= 1'b0;

                            done_pending <= 1'b0;
                            state <= S_RUN;
                        end
                    end else begin
                        out_valid <= 1'b1;
                    end
                end

                default: begin
                    state <= S_IDLE;
                    out_valid <= 1'b0;
                end
            endcase
        end
    end

endmodule
`default_nettype wire