`timescale 1ns/1ps
`default_nettype none

module tb_pw_dw_proj_full;

    localparam integer CIN   = 32;
    localparam integer H     = 32;
    localparam integer W     = 32;
    localparam integer PIXN  = H*W;
    localparam integer DEPTH = CIN*PIXN;

    localparam MEM_PATH = "E:/Desktop/ring2/gold/stage1/block0/04_add_a.mem";

    // --- dump paths (match your python expectation) ---
    localparam PW_DUMP_PATH  = "E:/region/python/coe/05_expand_relu_hw130.txt";
    localparam DW_DUMP_PATH  = "E:/region/python/coe/06_dw_relu_hw130.txt";
    localparam PJ_DUMP_PATH  = "E:/region/python/coe/11_project_hw130.txt";

    integer pw_fp;
    integer dw_fp;
    integer pj_fp;

    reg clk;
    reg rst_n;

    reg         s_valid;
    wire        s_ready;
    reg  [9:0]  s_pix_idx;
    reg  [5:0]  s_och;
    reg  [12:0] s_data;
    reg         s_last;

    wire        m_valid;
    reg         m_ready;
    wire [9:0]  m_pix_idx;
    wire [5:0]  m_och;
    wire [12:0] m_data;
    wire        m_last;

    // DUT
    GF_top dut (
        .clk(clk),
        .rst_n(rst_n),

        .s_valid(s_valid),
        .s_ready(s_ready),
        .s_pix_idx(s_pix_idx),
        .s_och(s_och),
        .s_data(s_data),
        .s_last(s_last),

        .m_valid(m_valid),
        .m_ready(m_ready),
        .m_pix_idx(m_pix_idx),
        .m_och(m_och),
        .m_data(m_data),
        .m_last(m_last)
    );

    // input mem
    reg [15:0] mem [0:DEPTH-1];
    integer in_ptr;
    integer out_cnt;

    // clock
    initial begin
        clk = 1'b0;
        forever #1 clk = ~clk;
    end

    initial begin
        $readmemh(MEM_PATH, mem);
    end

    // open files + headers
    initial begin
        pw_fp = $fopen(PW_DUMP_PATH, "w");
        if (pw_fp == 0) begin $display("ERROR: cannot open %s", PW_DUMP_PATH); $finish; end
        $fwrite(pw_fp, "dtype=int16 N=1 C=96 H=32 W=32 F=8\n");
        $fwrite(pw_fp, "pix_idx och val_hex val_dec\n");

        dw_fp = $fopen(DW_DUMP_PATH, "w");
        if (dw_fp == 0) begin $display("ERROR: cannot open %s", DW_DUMP_PATH); $finish; end
        $fwrite(dw_fp, "dtype=int16 N=1 C=96 H=32 W=32 F=8\n");
        $fwrite(dw_fp, "pix_idx och val_hex val_dec\n");

        pj_fp = $fopen(PJ_DUMP_PATH, "w");
        if (pj_fp == 0) begin $display("ERROR: cannot open %s", PJ_DUMP_PATH); $finish; end
        $fwrite(pj_fp, "dtype=int16 N=1 C=32 H=32 W=32 F=8\n");
        $fwrite(pj_fp, "pix_idx och val_hex val_dec\n");
    end

    // reset/init
    initial begin
        rst_n     = 1'b0;
        s_valid   = 1'b0;
        s_pix_idx = 10'd0;
        s_och     = 6'd0;
        s_data    = 16'd0;
        s_last    = 1'b0;

        m_ready = 1'b1;   // keep final ready always 1 (proj itself will backpressure DW)

        in_ptr  = 0;
        out_cnt = 0;

        #10;
        rst_n = 1'b1;
    end

    // drive input stream: pix-major then channel
    // drive input stream: pix-major then channel
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s_valid   <= 1'b0;
            in_ptr    <= 0;
            s_last    <= 1'b0;
            s_pix_idx <= 10'd0;
            s_och     <= 6'd0;
            s_data    <= 13'd0;
        end else begin
            // 只要指针还没有越过总数据量，就持续发送
            if (in_ptr < DEPTH) begin
                s_valid   <= 1'b1;
                s_data    <= {mem[in_ptr][11], mem[in_ptr][11:0]};
                s_pix_idx <= in_ptr / CIN;
                s_och     <= in_ptr % CIN; // 使用 % 简化通道索引计算
                s_last    <= (in_ptr == (DEPTH - 1));

                // 核心：如果当前发出的数据被成功握手接收
                if (s_valid && s_ready) begin
                    in_ptr <= in_ptr + 1; // 指针坚决往前走
                    
                    // 提前判定：如果刚刚吃掉的是最后一个数据
                    if (in_ptr == DEPTH - 1) begin
                        s_valid <= 1'b0; // 下一拍立刻断开 valid
                        s_last  <= 1'b0;
                    end else begin
                        // 否则，为了流水线无缝衔接，提前把下一个数据拍到总线上
                        s_data    <= {mem[in_ptr+1][11], mem[in_ptr+1][11:0]};
                        s_pix_idx <= (in_ptr + 1) / CIN;
                        s_och     <= (in_ptr + 1) % CIN;
                        s_last    <= ((in_ptr + 1) == (DEPTH - 1));
                    end
                end
            end else begin
                // 发送完毕后，将 valid 永久死锁在 0
                s_valid <= 1'b0;
                s_last  <= 1'b0;
            end
        end
    end

    // dump PW (samples that DW actually accepted)
    always @(posedge clk) begin
        if (rst_n && dut.pw_valid && dut.pw_ready) begin
            $fwrite(pw_fp, "%0d %0d 0x%04h %0d\n",
                    dut.pw_pix, dut.pw_och, dut.pw_data, $signed(dut.pw_data));
        end
    end

    // dump DW (samples that PROJ actually accepted)
    always @(posedge clk) begin
        if (rst_n && dut.dw_valid && dut.dw_ready) begin
            $fwrite(dw_fp, "%0d %0d 0x%04h %0d\n",
                    dut.dw_pix, dut.dw_och, dut.dw_data, $signed(dut.dw_data));
        end
    end

    // dump PROJ + stop on last
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_cnt <= 0;
        end else begin
            if (m_valid && m_ready) begin
                out_cnt <= out_cnt + 1;

                $fwrite(pj_fp, "%0d %0d 0x%04h %0d\n",
                        m_pix_idx, m_och, m_data, $signed(m_data));

                if (m_last) begin
                    $display("DONE: proj_out_cnt=%0d", out_cnt+1);
                    $fclose(pw_fp);
                    $fclose(dw_fp);
                    $fclose(pj_fp);
                    #5;
                    $finish;
                end
            end
        end
    end

endmodule

`default_nettype wire
